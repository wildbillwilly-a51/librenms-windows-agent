<?php

$data = is_array($app->data ?? null) ? $app->data : [];
$agent = $data['agent'] ?? [];
$windows_os = $data['windows_os'] ?? [];
$roles = $data['roles'] ?? [];
$ad_summary = $data['ad_summary'] ?? [];
$ad_replication = $data['ad_replication'] ?? [];
$ad_dfsr = $data['ad_dfsr'] ?? [];
$ad_fsmo = $data['ad_fsmo'] ?? [];
$ad_dc_health_summary = $data['ad_dc_health_summary'] ?? [];
$ad_dc_services = $data['ad_dc_services'] ?? [];
$ad_dc_dns = $data['ad_dc_dns'] ?? [];
$ad_dc_time = $data['ad_dc_time'] ?? [];
$ad_dc_shares = $data['ad_dc_shares'] ?? [];
$ad_dc_security_events = $data['ad_dc_security_events'] ?? [];
$logged_on_users = $data['logged_on_users'] ?? [];
$pending_reboot = $data['pending_reboot'] ?? [];
$windows_update = $data['windows_update'] ?? [];
$watched_services = $data['watched_services'] ?? [];
$classified_service_groups = $data['classified_service_groups'] ?? [];
$service_group_summaries = $data['service_group_summaries'] ?? [];
$excluded_services = $data['excluded_services'] ?? [];
$event_logs = $data['event_logs'] ?? [];
$event_log_high_value_summary = $data['event_log_high_value_summary'] ?? [];
$event_log_high_value = $data['event_log_high_value'] ?? [];
$watched_processes = $data['watched_processes'] ?? [];
$watched_tcp_ports = $data['watched_tcp_ports'] ?? [];
$agent_performance = $data['agent_performance'] ?? [];
$collector_timings = $data['collector_timings'] ?? [];
$cpu_details = $data['cpu'] ?? [];
$memory = $data['memory'] ?? [];
$disks = $data['disks'] ?? [];
$vm_resource_summary = $data['vm_resource_summary'] ?? [];
$performance_summary = $data['performance_summary'] ?? [];
$performance_disks = $data['performance_disks'] ?? [];
$performance_network = $data['performance_network'] ?? [];
$performance_processes = $data['performance_processes'] ?? [];
$sql_server_summary = $data['sql_server_summary'] ?? [];
$sql_server_instances = $data['sql_server_instances'] ?? [];
$sql_server_components = $data['sql_server_components'] ?? [];
$sql_server_performance = $data['sql_server_performance'] ?? [];
$iis_summary = $data['iis_summary'] ?? [];
$iis_sites = $data['iis_sites'] ?? [];
$iis_app_pools = $data['iis_app_pools'] ?? [];
$iis_bindings = $data['iis_bindings'] ?? [];
$horizon_summary = $data['horizon_summary'] ?? [];
$horizon_services = $data['horizon_services'] ?? [];
$horizon_processes = $data['horizon_processes'] ?? [];
$horizon_ports = $data['horizon_ports'] ?? [];
$horizon_certificates = $data['horizon_certificates'] ?? [];
$horizon_runtime_summary = $data['horizon_runtime_summary'] ?? [];
$horizon_runtime_processes = $data['horizon_runtime_processes'] ?? [];
$horizon_api_summary = $data['horizon_api_summary'] ?? [];
$horizon_api_session_protocols = $data['horizon_api_session_protocols'] ?? [];
$horizon_pod_summary = $data['horizon_pod_summary'] ?? [];
$horizon_pod_members = $data['horizon_pod_members'] ?? [];
$horizon_configuration_replications = $data['horizon_configuration_replications'] ?? [];
$horizon_directory_summary = $data['horizon_directory_summary'] ?? [];
$horizon_directory_domains = $data['horizon_directory_domains'] ?? [];
$horizon_directory_member_status = $data['horizon_directory_member_status'] ?? [];
$horizon_gateways = $data['horizon_gateways'] ?? [];
$horizon_pools_summary = $data['horizon_pools_summary'] ?? [];
$horizon_pools = $data['horizon_pools'] ?? [];
$horizon_pool_machine_states = $data['horizon_pool_machine_states'] ?? [];
$horizon_pool_machines = $data['horizon_pool_machines'] ?? [];
$horizon_pool_machine_issues = $data['horizon_pool_machine_issues'] ?? [];
$horizon_health_summary = $data['horizon_health_summary'] ?? [];
$horizon_vendor_metrics = $data['horizon_vendor_metrics'] ?? [];
$horizon_conditions = $data['horizon_conditions'] ?? [];
$horizon_observations = $data['horizon_observations'] ?? [];
$horizon_condition_history = $data['horizon_condition_history'] ?? [];
$horizon_central_meta = $data['horizon_central_meta'] ?? [];
$factorytalk_summary = $data['factorytalk_summary'] ?? [];
$factorytalk_products = $data['factorytalk_products'] ?? [];
$factorytalk_services = $data['factorytalk_services'] ?? [];
$factorytalk_processes = $data['factorytalk_processes'] ?? [];
$factorytalk_ports = $data['factorytalk_ports'] ?? [];
$factorytalk_runtime_summary = $data['factorytalk_runtime_summary'] ?? [];
$factorytalk_runtime_processes = $data['factorytalk_runtime_processes'] ?? [];
$factorytalk_native_summary = $data['factorytalk_native_summary'] ?? [];
$factorytalk_linx_connections = $data['factorytalk_linx_connections'] ?? [];
$factorytalk_linx_backplane = $data['factorytalk_linx_backplane'] ?? [];
$factorytalk_linx_transactions = $data['factorytalk_linx_transactions'] ?? [];
$factorytalk_livedata = $data['factorytalk_livedata'] ?? [];
$tls_certificates_summary = $data['tls_certificates_summary'] ?? [];
$tls_certificates = $data['tls_certificates'] ?? [];
$backup_storage_summary = $data['backup_storage_summary'] ?? [];
$vss_writers = $data['vss_writers'] ?? [];
$backup_services = $data['backup_services'] ?? [];
$datto_backup_summary = $data['datto_backup_summary'] ?? [];
$datto_backup_services = $data['datto_backup_services'] ?? [];
$datto_backup_processes = $data['datto_backup_processes'] ?? [];
$datto_backup_evidence = $data['datto_backup_evidence'] ?? [];
$app_id = is_array($app) ? ($app['app_id'] ?? 0) : ($app->app_id ?? 0);

$esc = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$format_bytes = static function ($value): string {
    $bytes = (float) $value;
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $index = 0;
    while ($bytes >= 1024 && $index < count($units) - 1) {
        $bytes /= 1024;
        $index++;
    }

    return number_format($bytes, $index === 0 ? 0 : 2) . ' ' . $units[$index];
};
$format_percent = static function ($value): string {
    return number_format((float) $value, 2) . '%';
};

$sum_field = static function (array $rows, string $field): int {
    $total = 0;
    foreach ($rows as $row) {
        $total += (int) ($row[$field] ?? 0);
    }

    return $total;
};

$section_state = static function ($raw, int $issues = 0) use ($esc): array {
    $state = strtolower(trim((string) $raw));
    if ($state === '') {
        $state = $issues > 0 ? 'warning' : 'ok';
    }

    if ($issues > 0 && in_array($state, ['ok', 'running', 'stable', 'healthy'], true)) {
        $state = 'warning';
    }

    $labels = [
        'ok' => ['OK', 'success'],
        'running' => ['Running', 'success'],
        'stable' => ['Stable', 'success'],
        'healthy' => ['Healthy', 'success'],
        'warning' => ['Warning', 'warning'],
        'critical' => ['Critical', 'danger'],
        'error' => ['Error', 'danger'],
        'failed' => ['Failed', 'danger'],
        'not_detected' => ['Not detected', 'default'],
        'not_applicable' => ['Not applicable', 'default'],
        'disabled' => ['Disabled', 'default'],
        'unsupported' => ['Unsupported', 'default'],
        'unknown' => ['Unknown', 'default'],
        '1' => ['OK', 'success'],
        '0' => ['Issue', 'danger'],
    ];
    $label = $labels[$state] ?? [ucwords(str_replace('_', ' ', $state)), $issues > 0 ? 'warning' : 'default'];

    return [
        'key' => $state,
        'text' => $label[0],
        'class' => $label[1],
        'html' => '<span class="label label-' . $label[1] . '">' . $esc($label[0]) . '</span>',
    ];
};

$state_label = static function ($value, array $healthy = ['running', 'ok', '1', 'true']) use ($esc): string {
    $text = (string) $value;
    $class = in_array(strtolower($text), $healthy, true) ? 'label-success' : 'label-danger';

    return '<span class="label ' . $class . '">' . $esc($text === '' ? 'unknown' : $text) . '</span>';
};

$has_role_details = static function (array $summary, array $rows): bool {
    $state = strtolower((string) ($summary['state'] ?? ''));
    if (in_array($state, ['not_detected', 'disabled', 'unsupported', 'not_applicable'], true)) {
        return false;
    }

    return ! empty($rows);
};

$table = static function (array $headers, array $rows, callable $row_renderer) use ($esc): string {
    if (empty($rows)) {
        return '';
    }

    $html = '<div class="table-responsive"><table class="table table-condensed table-striped windows-agent-data-table">';
    $html .= '<tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . $esc($header) . '</th>';
    }
    $html .= '</tr>';
    foreach ($rows as $row) {
        $html .= '<tr>' . $row_renderer($row) . '</tr>';
    }
    $html .= '</table></div>';

    return $html;
};

$issue_first = static function (array $rows, callable $score, string $tie_field = 'name'): array {
    usort($rows, static function (array $left, array $right) use ($score, $tie_field): int {
        $left_score = (int) $score($left);
        $right_score = (int) $score($right);
        if ($left_score !== $right_score) {
            return $right_score <=> $left_score;
        }

        return strcasecmp((string) ($left[$tie_field] ?? ''), (string) ($right[$tie_field] ?? ''));
    });

    return $rows;
};

$kv_table = static function (array $rows) use ($esc): string {
    $html = '<div class="table-responsive"><table class="table table-condensed table-striped">';
    foreach ($rows as $label => $value) {
        $html .= '<tr><th>' . $esc($label) . '</th><td>' . $value . '</td></tr>';
    }
    $html .= '</table></div>';

    return $html;
};

$render_graph_html = static function (string $key) use ($app_id): string {
    $graph_type = $key;
    $graph_array = [];
    $graph_array['height'] = '100';
    $graph_array['width'] = '215';
    $graph_array['to'] = \App\Facades\LibrenmsConfig::get('time.now');
    $graph_array['id'] = $app_id;
    $graph_array['type'] = 'application_' . $key;

    ob_start();
    include 'includes/html/print-graphrow.inc.php';
    $html = (string) ob_get_clean();
    // Core owns lazy loading and the escaping of images inside tooltip attributes.
    return $html;
};

$state_has_issue = static function (array $state): bool {
    return in_array($state['class'] ?? '', ['warning', 'danger'], true);
};

$render_section_summary = static function (string $id, string $title, array $state, string $summary, string $details = '', array $graphs = [], string $details_label = 'Details', string $graphs_label = 'Graphs') use ($esc, $render_graph_html): string {
    if (in_array($state['key'] ?? '', ['not_detected', 'disabled', 'unsupported', 'not_applicable'], true)) {
        $graphs = [];
    }

    $arrow = '<span class="windows-agent-collapse-arrow windows-agent-collapse-arrow-down glyphicon glyphicon-chevron-down" aria-hidden="true"></span><span class="windows-agent-collapse-arrow windows-agent-collapse-arrow-up glyphicon glyphicon-chevron-up" aria-hidden="true"></span>';
    $html = '<div class="panel panel-default windows-agent-section" id="windows-agent-section-' . $esc($id) . '">';
    $html .= '<div class="panel-heading">';
    $html .= '<div class="row">';
    $html .= '<div class="col-md-3"><strong>' . $esc($title) . '</strong> ' . $state['html'] . '</div>';
    $html .= '<div class="col-md-6">' . $summary . '</div>';
    $html .= '<div class="col-md-3 text-right">';
    if ($details !== '') {
        $html .= '<a class="btn btn-xs btn-default collapsed windows-agent-collapse-toggle" data-toggle="collapse" href="#windows-agent-details-' . $esc($id) . '" aria-expanded="false">' . $esc($details_label) . ' ' . $arrow . '</a> ';
    }
    if (! empty($graphs)) {
        $html .= '<a class="btn btn-xs btn-default collapsed windows-agent-collapse-toggle" data-toggle="collapse" href="#windows-agent-graphs-' . $esc($id) . '" aria-expanded="false">' . $esc($graphs_label) . ' ' . $arrow . '</a>';
    }
    $html .= '</div></div></div>';
    if ($details !== '' || ! empty($graphs)) {
        $html .= '<div class="panel-body">';
        if ($details !== '') {
            $html .= '<div id="windows-agent-details-' . $esc($id) . '" class="collapse windows-agent-details-collapse">' . $details . '</div>';
        }
        if (! empty($graphs)) {
            $html .= '<div id="windows-agent-graphs-' . $esc($id) . '" class="collapse windows-agent-graph-collapse">';
            $secondary_graph_html = '';
            foreach ($graphs as $graph) {
                $graph_key = $graph['key'] ?? '';
                if ($graph_key === '') {
                    continue;
                }

                $graph_html = '<div class="windows-agent-graph-view">';
                $graph_html .= '<h4>' . $esc($graph['label'] ?? 'Graph') . '</h4>';
                $graph_html .= $render_graph_html($graph_key);
                $graph_html .= '</div>';
                if ((bool) ($graph['secondary'] ?? false)) {
                    $secondary_graph_html .= $graph_html;
                } else {
                    $html .= $graph_html;
                }
            }
            if ($secondary_graph_html !== '') {
                $secondary_id = 'windows-agent-secondary-graphs-' . $esc($id);
                $html .= '<div class="windows-agent-subsection">';
                $html .= '<a class="btn btn-sm btn-default collapsed windows-agent-collapse-toggle" data-toggle="collapse" href="#' . $secondary_id . '" aria-expanded="false">Additional graphs ' . $arrow . '</a>';
                $html .= '<div id="' . $secondary_id . '" class="collapse windows-agent-subsection-body">' . $secondary_graph_html . '</div></div>';
            }
            $html .= '</div>';
        }
        $html .= '</div>';
    }
    $html .= '</div>';

    return $html;
};

$render_tab = static function (string $id, bool $active, string $body) use ($esc): void {
    echo '<div role="tabpanel" class="tab-pane' . ($active ? ' active' : '') . '" id="' . $esc($id) . '">';
    echo $body;
    echo '</div>';
};

// Shared tab summary: the uniform header every tab leads with — a status strip
// (state, plain-language verdict, next action, collected-at), up to six decision-
// grade stat tiles, and an attention list rendered only when something is wrong.
// It reuses the role-dashboard vocabulary that Horizon, FactoryTalk, and AD
// already use, so every tab reads as one system. Detailed evidence and trends
// follow this header in each tab and are not part of it.
$render_tab_summary = static function (array $summary) use ($esc): string {
    $state = is_array($summary['state'] ?? null) ? $summary['state'] : [];
    $class = ['success' => 'success', 'warning' => 'warning', 'danger' => 'danger'][$state['class'] ?? ''] ?? 'info';
    $verdict = trim((string) ($summary['verdict'] ?? ''));
    $next = trim((string) ($summary['next'] ?? ''));
    $collected = trim((string) ($summary['collected'] ?? ''));
    $tiles = array_slice(is_array($summary['tiles'] ?? null) ? $summary['tiles'] : [], 0, 6);
    $attention = is_array($summary['attention'] ?? null) ? $summary['attention'] : [];

    $html = '<div class="windows-agent-role-dashboard windows-agent-tab-summary">';
    $html .= '<div class="windows-agent-role-status windows-agent-role-status-' . $esc($class) . '">';
    $html .= '<span class="label label-' . $esc($class) . '">' . $esc($state['text'] ?? 'Unknown') . '</span> ';
    $html .= '<strong>' . $esc($verdict === '' ? ($state['text'] ?? 'Unknown') : $verdict) . '</strong>';
    if ($next !== '') {
        $html .= ' <span class="windows-agent-role-action"><strong>Next:</strong> ' . $esc($next) . '</span>';
    }
    if ($collected !== '') {
        $html .= '<span class="text-muted windows-agent-role-collected">Collected ' . $esc($collected) . '</span>';
    }
    if (($summary['coverage'] ?? '') !== '') {
        $html .= '<div class="windows-agent-role-coverage text-muted">' . $esc($summary['coverage']) . '</div>';
    }
    $html .= '</div>';

    if (! empty($tiles)) {
        $html .= '<div class="row windows-agent-role-stats">';
        foreach ($tiles as $tile) {
            $label = (string) ($tile[0] ?? '');
            $value = (string) ($tile[1] ?? '');
            $detail = (string) ($tile[2] ?? '');
            $html .= '<div class="col-sm-4 col-lg-2 windows-agent-role-stat"><div class="text-muted windows-agent-role-stat-label">' . $esc($label) . '</div><div class="windows-agent-role-stat-value">' . $esc($value) . '</div><div class="text-muted windows-agent-role-stat-detail">' . $esc($detail) . '</div></div>';
        }
        $html .= '</div>';
    }

    if (! empty($attention)) {
        $html .= '<div class="windows-agent-role-attention"><h4>Needs attention <small>' . count($attention) . '</small></h4><ul>';
        foreach ($attention as $item) {
            $html .= '<li><strong>';
            if (isset($item['href'])) $html .= '<a data-sql-evidence-link href="' . $esc($item['href']) . '">';
            $html .= $esc((string) ($item['title'] ?? 'Issue'));
            if (isset($item['href'])) $html .= '</a>';
            $html .= '</strong> ';
            $html .= '<span class="text-muted">' . $esc((string) ($item['detail'] ?? '')) . '</span>';
            if (($item['action'] ?? '') !== '') {
                $html .= '<div class="text-muted windows-agent-role-attention-action"><strong>Next:</strong> ' . $esc((string) $item['action']) . '</div>';
            }
            $html .= '</li>';
        }
        $html .= '</ul></div>';
    }

    $html .= '</div>';

    return $html;
};

// Worst of a set of section states, for a tab whose summary spans several sections.
$worst_section_state = static function (array $states) use ($section_state): array {
    $rank = ['success' => 0, 'default' => 1, 'info' => 1, 'warning' => 2, 'danger' => 3];
    $worst = null;
    $worstRank = -1;
    foreach ($states as $state) {
        if (! is_array($state)) {
            continue;
        }
        $r = $rank[$state['class'] ?? 'default'] ?? 1;
        if ($r > $worstRank) {
            $worstRank = $r;
            $worst = $state;
        }
    }

    return $worst ?? $section_state('ok');
};

$metric = static function (string $label, $value) use ($esc): string {
    return '<span class="text-muted">' . $esc($label) . ':</span> <strong>' . $esc($value) . '</strong>';
};

$format_duration = static function ($value): string {
    $seconds = max(0, (int) $value);
    $days = intdiv($seconds, 86400);
    $hours = intdiv($seconds % 86400, 3600);
    $minutes = intdiv($seconds % 3600, 60);

    if ($days > 0) {
        return $days . 'd ' . $hours . 'h';
    }
    if ($hours > 0) {
        return $hours . 'h ' . $minutes . 'm';
    }

    return $minutes . 'm';
};

$render_disclosure = static function (string $id, string $label, string $body, string $summary = '') use ($esc): string {
    if ($body === '') {
        return '';
    }

    $arrow = '<span class="windows-agent-collapse-arrow windows-agent-collapse-arrow-down glyphicon glyphicon-chevron-down" aria-hidden="true"></span><span class="windows-agent-collapse-arrow windows-agent-collapse-arrow-up glyphicon glyphicon-chevron-up" aria-hidden="true"></span>';
    $html = '<div class="windows-agent-subsection">';
    $html .= '<a class="btn btn-sm btn-default collapsed windows-agent-collapse-toggle" data-toggle="collapse" href="#' . $esc($id) . '" aria-expanded="false">' . $esc($label) . ' ' . $arrow . '</a>';
    if ($summary !== '') {
        $html .= ' <span class="text-muted windows-agent-disclosure-summary">' . $esc($summary) . '</span>';
    }
    $html .= '<div id="' . $esc($id) . '" class="collapse windows-agent-subsection-body">' . $body . '</div></div>';

    return $html;
};

$humanize_horizon_reason = static function ($value): string {
    $value = trim(strtolower((string) $value));
    $labels = [
        // Pool capacity. Exhaustion and failure are deliberately worded so they
        // cannot be mistaken for each other.
        'spare_capacity_critical' => 'Fewer than two spares, with machines unavailable',
        'low_spare_capacity' => 'Fewer than two spare machines available',
        'multiple_machines_unavailable' => 'More than one machine unavailable',
        'one_machine_unavailable' => 'One machine unavailable',
        'no_placement_capacity' => 'Fully in use; no free capacity',
        'ready_spares_faulted' => 'No ready spares; remaining spares are faulted',
        'multiple_faulted_spares' => 'Multiple faulted spares',
        'faulted_spare_capacity_remains' => 'One faulted spare; capacity remains',
        'spares_pending_only' => 'Spares are still becoming ready',
        'spares_held_only' => 'Remaining spares are intentionally withheld',
        'spare_readiness_undetermined' => 'Spare readiness could not be determined',
        'within_threshold' => 'Capacity available',
        'capacity_available' => 'Capacity available',
        'inventory_incomplete' => 'Inventory incomplete',
        'pool_disabled' => 'Pool disabled',
        'pool_capacity_healthy' => 'Pool capacity healthy',
        'pool_capacity_faulted' => 'Pool capacity has faulted machines',
        'pool_capacity_exhausted' => 'Pool capacity fully in use',
        'pool_capacity_degraded' => 'Pool capacity degraded',
        'pool_capacity_observation' => 'Pool capacity observation',
        'pool_inventory_incomplete' => 'Pool inventory incomplete',
        // Connection Server member states.
        'active_certificate_invalid' => 'Active certificate is invalid',
        'connection_server_health_degraded' => 'Connection Server health degraded',
        'connection_server_service_degraded' => 'Connection Server service degraded',
        'connection_server_redundancy_degraded' => 'Connection Server redundancy degraded',
        'domain_access_degraded' => 'Directory (domain) access degraded',
        // Standalone gateway states.
        'gateway_contact_degraded' => 'Gateway not contacted (stale)',
        'gateway_unhealthy' => 'Gateway reporting a problem',
        'gateway_health_degraded' => 'Gateway health degraded',
        'gateway_health_transient' => 'Gateway health degraded (transient)',
        // Machine states.
        'machine_healthy' => 'Ready for placement',
        'machine_in_use' => 'Serving a user session',
        'machine_session_disconnected' => 'Session disconnected; user can reconnect',
        'session_disconnected_stuck' => 'Disconnected too long; unavailable to other users',
        'machine_withheld' => 'Intentionally withheld',
        'machine_transitional' => 'Becoming ready',
        'machine_transitional_too_long' => 'Stuck becoming ready',
        'machine_state_unknown' => 'State reported as unknown',
        'machine_state_unrecognized' => 'State not recognized by this overlay',
        'machine_unavailable' => 'Machine unavailable',
        'machine_already_used' => 'Machine already used and not recycled',
        'maintenance_mode' => 'Maintenance mode',
        'agent_unreachable' => 'Agent unreachable',
        'agent_config_error' => 'Agent configuration error',
        'agent_startup_in_progress' => 'Agent startup in progress',
        'agent_disabled' => 'Agent disabled',
        'agent_invalid_ip' => 'Agent reported an invalid address',
        'agent_needs_reboot' => 'Agent requires a reboot',
        'agent_protocol_failure' => 'Agent protocol failure',
        'agent_domain_failure' => 'Agent domain failure',
        'customizing_error' => 'Customization error',
        'provisioning_error' => 'Provisioning error',
        'machine_state_error' => 'Machine state error',
        'machine_disabled' => 'Machine disabled',
        'crl_prefetch_not_running' => 'CRL Prefetch is not running',
    ];

    return $labels[$value] ?? ucwords(str_replace('_', ' ', $value === '' ? 'unknown' : $value));
};

// Reason-aware next action for a Horizon condition. Keeps the generic guidance
// as the fallback but points cert and gateway conditions at the real remedy.
$horizon_condition_next = static function (string $scope, string $reasonCode): string {
    if ($scope === 'collector') {
        return 'Review collector reliability and endpoint evidence.';
    }
    if ($reasonCode === 'active_certificate_invalid') {
        return 'Renew or rebind the Horizon server certificate on this Connection Server.';
    }
    if (strpos($reasonCode, 'gateway_') === 0) {
        return 'Review the gateway status and last contact in the Gateways table below.';
    }

    return 'Open the related evidence and review the affected Horizon component.';
};

$format_horizon_age = static function ($seconds): string {
    $seconds = (int) $seconds;
    if ($seconds < 0) return 'unknown';
    if ($seconds < 60) return $seconds . ' sec ago';
    if ($seconds < 3600) return intdiv($seconds, 60) . ' min ago';

    return number_format($seconds / 3600, 1) . ' hr ago';
};

$render_horizon_range_graph = static function (int $appId) use ($esc): string {
    $ranges = [
        '24h' => 86400,
        '7d' => 604800,
        '30d' => 2592000,
    ];
    $html = '<div class="windows-agent-horizon-trend">';
    $html .= '<div class="windows-agent-horizon-trend-header"><h4>Sessions and headroom</h4><div class="btn-group btn-group-xs" role="group" aria-label="Trend range">';
    foreach ($ranges as $label => $seconds) {
        $active = $label === '30d';
        $html .= '<button type="button" class="btn btn-default windows-agent-horizon-range' . ($active ? ' active' : '') . '" data-range="' . $esc($label) . '" aria-pressed="' . ($active ? 'true' : 'false') . '">' . $esc($label) . '</button>';
    }
    $html .= '</div></div>';
    foreach ($ranges as $label => $seconds) {
        $query = http_build_query([
            'type' => 'application_windows-agent_horizon_demand_headroom',
            'id' => $appId,
            'from' => time() - $seconds,
            'to' => time(),
            'width' => 1200,
            'height' => 220,
            'legend' => 'yes',
        ]);
        $html .= '<div class="windows-agent-horizon-range-panel' . ($label === '30d' ? ' active' : '') . '" data-range-panel="' . $esc($label) . '"' . ($label === '30d' ? '' : ' hidden') . '>';
        $html .= '<img class="img-responsive windows-agent-horizon-trend-image" src="graph.php?' . $esc($query) . '" alt="' . $esc($label) . ' connected sessions and ready-capacity trend">';
        $html .= '</div>';
    }
    $html .= '</div>';

    return $html;
};

$agent_issues = (int) ($agent_performance['collectors_failed'] ?? 0) + (int) ($agent_performance['collectors_timed_out'] ?? 0);
$agent_resource_cpu_percent = (float) ($agent_performance['process_cpu_percent'] ?? 0);
$agent_resource_io_bytes = (float) ($agent_performance['process_io_bytes'] ?? 0);
$agent_resource_memory_bytes = (float) ($agent_performance['process_working_set_bytes'] ?? 0);
$agent_resource_duration_ms = (int) ($agent_performance['collect_duration_ms'] ?? 0);
$agent_resource_known = array_key_exists('process_cpu_percent', $agent_performance) || array_key_exists('process_io_bytes', $agent_performance);
$agent_resource_impact_key = 'unknown';
if ($agent_resource_known) {
    $agent_resource_impact_key = 'low';
    if (
        $agent_resource_cpu_percent > 15
        || $agent_resource_memory_bytes > 262144000
        || $agent_resource_io_bytes > 104857600
        || $agent_resource_duration_ms > 30000
    ) {
        $agent_resource_impact_key = 'high';
    } elseif (
        $agent_resource_cpu_percent > 5
        || $agent_resource_memory_bytes > 104857600
        || $agent_resource_io_bytes > 10485760
        || $agent_resource_duration_ms > 10000
    ) {
        $agent_resource_impact_key = 'moderate';
    }
}
$agent_resource_states = [
    'low' => ['key' => 'low', 'text' => 'Low', 'class' => 'success', 'html' => '<span class="label label-success">Low</span>'],
    'moderate' => ['key' => 'moderate', 'text' => 'Moderate', 'class' => 'default', 'html' => '<span class="label label-default">Moderate</span>'],
    'high' => ['key' => 'high', 'text' => 'High', 'class' => 'warning', 'html' => '<span class="label label-warning">High</span>'],
    'unknown' => ['key' => 'unknown', 'text' => 'Unknown', 'class' => 'default', 'html' => '<span class="label label-default">Unknown</span>'],
];
$agent_resource_state = $agent_resource_states[$agent_resource_impact_key] ?? $agent_resource_states['unknown'];
$agent_resource_assessment = [
    'low' => 'No meaningful host impact detected.',
    'moderate' => 'Collector load is noticeable but still within expected bounds.',
    'high' => 'Collector load may be slowing the host; review details and collector timings.',
    'unknown' => 'Upgrade the Windows agent to report collector resource impact.',
][$agent_resource_impact_key] ?? 'Collector resource impact is unknown.';
$vm_state = empty($vm_resource_summary) ? $section_state('unknown') : $section_state('ok');
$classified_services_stopped = $sum_field($service_group_summaries, 'not_running');
$watched_service_issues = 0;
foreach ($watched_services as $service) {
    if (($service['state'] ?? '') !== 'Running') {
        $watched_service_issues++;
    }
}
$event_evidence_count = $sum_field($event_logs, 'critical_count') + $sum_field($event_logs, 'error_count');
$backup_health_issues = (int) ($backup_storage_summary['vss_writers_failed'] ?? 0);
$backup_summary_state = strtolower((string) ($backup_storage_summary['state'] ?? 'not_detected'));
$backup_state_key = in_array($backup_summary_state, ['not_detected', 'disabled', 'unsupported', 'not_applicable'], true)
    ? $backup_summary_state
    : ($backup_health_issues > 0 ? 'warning' : 'ok');
$tls_certificate_count = (int) ($tls_certificates_summary['certificate_count'] ?? 0);
$tls_unhealthy_count = (int) ($tls_certificates_summary['unhealthy_count'] ?? 0);
$tls_summary_state = strtolower((string) ($tls_certificates_summary['state'] ?? 'not_detected'));
$tls_graphs = ($tls_certificate_count > 0 || $tls_unhealthy_count > 0) ? [
    ['label' => 'TLS Health Issues', 'key' => 'windows-agent_tls_health'],
] : [];
$process_issues = 0;
foreach ($watched_processes as $process) {
    if ((int) ($process['matched_count'] ?? 0) === 0) {
        $process_issues++;
    }
}
$tcp_issues = 0;
foreach ($watched_tcp_ports as $tcp_port) {
    if ((int) ($tcp_port['listening'] ?? 0) === 0) {
        $tcp_issues++;
    }
}
$logged_on_user_sessions = [];
foreach ($logged_on_users as $row) {
    if (empty($row['user'])) {
        continue;
    }

    $row['session_name'] = $row['session_name'] ?? ($row['session'] ?? '');
    $row['session_id'] = $row['session_id'] ?? ($row['id'] ?? '');
    $row['idle_time'] = $row['idle_time'] ?? ($row['idle'] ?? '');
    $row['logon_time'] = $row['logon_time'] ?? ($row['logon'] ?? '');
    $logged_on_user_sessions[] = $row;
}

$horizon_detected = (int) ($horizon_summary['detected'] ?? 0) === 1;
$horizon_client_only = ! $horizon_detected && ((int) ($horizon_summary['client_detected'] ?? 0) === 1 || strtolower((string) ($horizon_summary['state'] ?? '')) === 'client_only');
$horizon_health_issue_count = (int) ($horizon_summary['health_issues'] ?? 0);
$horizon_reported_next_action = trim((string) ($horizon_summary['next_action'] ?? ''));
$horizon_runtime_state = strtolower((string) ($horizon_runtime_summary['state'] ?? 'disabled'));
$horizon_runtime_available = $horizon_runtime_state === 'ok';
$horizon_api_state = strtolower((string) ($horizon_api_summary['state'] ?? 'disabled'));
$horizon_api_enabled = ! in_array($horizon_api_state, ['', 'disabled'], true);
$horizon_api_available = in_array($horizon_api_state, ['ok', 'partial', 'stale'], true);
$horizon_api_health_state = strtolower((string) ($horizon_api_summary['health_state'] ?? $horizon_api_state));
$horizon_api_stale = $horizon_api_state === 'stale' || (int) ($horizon_central_meta['stale'] ?? 0) === 1;
if ($horizon_api_stale) {
    $horizon_api_health_state = 'warning';
}
$horizon_api_issue_count = (int) ($horizon_api_summary['connection_servers_unhealthy'] ?? 0)
    + (int) ($horizon_directory_summary['member_links_unhealthy'] ?? 0)
    + (int) ($horizon_pod_summary['gateways_unhealthy'] ?? 0)
    + (int) ($horizon_pools_summary['pools_warning'] ?? 0)
    + (int) ($horizon_pools_summary['pools_critical'] ?? 0);
$horizon_attention = [];

if ($horizon_detected && $horizon_health_issue_count > 0) {
    foreach ($horizon_services as $service) {
        $start_mode = strtolower((string) ($service['start_mode'] ?? ''));
        $serviceSeverity = strtolower((string) ($service['severity'] ?? ''));
        if ($serviceSeverity !== '') {
            if (! in_array($serviceSeverity, ['warning', 'critical', 'incomplete'], true)) continue;
        } elseif (in_array($start_mode, ['disabled', 'manual'], true) || strtolower((string) ($service['state'] ?? '')) === 'running') {
            continue;
        }

        $horizon_attention[] = [
            'state' => $serviceSeverity !== '' ? $serviceSeverity : 'critical',
            'title' => 'Required service is not running: ' . (string) ($service['display'] ?? $service['name'] ?? 'unknown'),
            'detail' => 'Current state: ' . (string) ($service['state'] ?? 'unknown') . '; startup: ' . (string) ($service['start_mode'] ?? 'unknown') . '; reason: ' . (string) ($service['reason'] ?? 'service_not_running'),
            'action' => 'Check the service and related Horizon components.',
        ];
    }

    foreach ($horizon_ports as $port) {
        if ((int) ($port['port'] ?? 0) !== 443 || (int) ($port['listening'] ?? 0) === 1) {
            continue;
        }

        $horizon_attention[] = [
            'state' => 'critical',
            'title' => 'Required HTTPS listener is unavailable',
            'detail' => 'TCP 443 is not listening on this Connection Server.',
            'action' => $horizon_reported_next_action !== '' ? $horizon_reported_next_action : 'Check the Connection Server listener and Windows firewall.',
        ];
    }

    foreach ($horizon_certificates as $certificate) {
        $certificateSeverity = strtolower((string) ($certificate['severity'] ?? ''));
        $expired = (int) ($certificate['expired'] ?? 0) === 1;
        $critical = (int) ($certificate['expiring_critical'] ?? 0) === 1;
        if ($certificateSeverity !== '') {
            if (! in_array($certificateSeverity, ['warning', 'critical', 'incomplete'], true)) continue;
        } elseif (! $expired && ! $critical) {
            continue;
        }

        $horizon_attention[] = [
            'state' => $certificateSeverity !== '' ? $certificateSeverity : ($expired ? 'critical' : 'warning'),
            'title' => $expired ? 'Horizon server certificate is expired' : 'Horizon server certificate expires soon',
            'detail' => (string) ($certificate['subject'] ?? 'Unknown certificate') . '; ' . (string) ($certificate['days_remaining'] ?? 'unknown') . ' day(s) remaining',
            'action' => 'Review the Horizon server certificate and its binding.',
        ];
    }

    if (empty($horizon_attention)) {
        $horizon_attention[] = [
            'state' => 'warning',
            'title' => 'Horizon health issues were reported',
            'detail' => $horizon_health_issue_count . ' issue(s) were reported by the Horizon health collector.',
            'action' => $horizon_reported_next_action !== '' ? $horizon_reported_next_action : 'Review Horizon service, listener, and certificate evidence.',
        ];
    }
}

$horizon_section_state = $section_state($horizon_summary['state'] ?? 'not_detected', $horizon_health_issue_count);
$horizon_api_is_critical = $horizon_api_available && $horizon_api_health_state === 'critical';
$horizon_api_is_warning = $horizon_api_available && in_array($horizon_api_health_state, ['warning', 'partial', 'incomplete'], true);
if ($horizon_api_is_critical) {
    $horizon_section_state = $section_state('critical');
} elseif ($horizon_api_is_warning && ($horizon_section_state['class'] ?? '') !== 'danger') {
    $horizon_section_state = $section_state('warning');
}
$horizon_section_summary = $horizon_detected
    ? $metric('Local issues', $horizon_health_issue_count) . ' ' . $metric('Pod', $horizon_api_available ? ucwords((string) ($horizon_pod_summary['state'] ?? 'unknown')) : 'N/A') . ' ' . $metric('Pool issues', $horizon_api_available ? ((int) ($horizon_pools_summary['pools_warning'] ?? 0) + (int) ($horizon_pools_summary['pools_critical'] ?? 0)) : 'N/A') . ' ' . $metric('Ready spares', $horizon_api_available ? ($horizon_pools_summary['spare_ready'] ?? '0') : 'N/A')
    : ($horizon_client_only
        ? $metric('Mode', 'Client only') . ' ' . $metric('Services', $horizon_summary['services_total'] ?? '0') . ' ' . $metric('Processes', $horizon_summary['processes_total'] ?? '0')
        : $metric('Detected', '0'));

$factorytalk_detected = (int) ($factorytalk_summary['detected'] ?? 0) === 1;
$factorytalk_active_connections = $sum_field($factorytalk_linx_connections, 'active');
$factorytalk_transactions_in_use = $sum_field($factorytalk_linx_transactions, 'in_use');
$factorytalk_transaction_pool_size = $sum_field($factorytalk_linx_transactions, 'pool_size');
$factorytalk_transaction_utilization = $factorytalk_transaction_pool_size > 0
    ? round(($factorytalk_transactions_in_use / $factorytalk_transaction_pool_size) * 100, 1)
    : null;
$factorytalk_attention = [];
$factorytalk_reported_health_issues = (int) ($factorytalk_summary['health_issues'] ?? 0);
$factorytalk_core_services_not_running = (int) ($factorytalk_summary['core_services_not_running'] ?? 0);
$factorytalk_reported_next_action = trim((string) ($factorytalk_summary['next_action'] ?? ''));

foreach ($factorytalk_services as $service) {
    if ((int) ($service['core'] ?? 0) !== 1 || strtolower((string) ($service['state'] ?? '')) === 'running') {
        continue;
    }

    $factorytalk_attention[] = [
        'title' => 'Core service is not running: ' . (string) ($service['display'] ?? $service['name'] ?? 'unknown'),
        'detail' => 'Current state: ' . (string) ($service['state'] ?? 'unknown') . '; startup: ' . (string) ($service['start_mode'] ?? 'unknown'),
        'action' => $factorytalk_reported_next_action !== '' ? $factorytalk_reported_next_action : 'Check the service and its FactoryTalk dependencies.',
    ];
}

$factorytalk_health_issue_count = max($factorytalk_reported_health_issues, $factorytalk_core_services_not_running, count($factorytalk_attention));
if ($factorytalk_health_issue_count > 0 && empty($factorytalk_attention)) {
    $factorytalk_attention[] = [
        'title' => 'FactoryTalk health issues were reported',
        'detail' => $factorytalk_health_issue_count . ' issue(s) were reported by the FactoryTalk health collector.',
        'action' => $factorytalk_reported_next_action !== '' ? $factorytalk_reported_next_action : 'Review the service inventory for the reported condition.',
    ];
}

$factorytalk_section_state = $section_state($factorytalk_summary['state'] ?? ($factorytalk_detected ? 'unknown' : 'not_detected'), $factorytalk_health_issue_count);
$factorytalk_section_summary = $factorytalk_detected
    ? $metric('Health issues', $factorytalk_health_issue_count) . ' ' . $metric('Core down', $factorytalk_core_services_not_running) . ' ' . $metric('Runtime CPU', empty($factorytalk_runtime_summary) ? 'N/A' : $format_percent($factorytalk_runtime_summary['cpu_percent'] ?? 0)) . ' ' . $metric('Active connections', $factorytalk_active_connections)
    : $metric('Detected', '0') . ' ' . $metric('Products', $factorytalk_summary['products_total'] ?? '0');

// Counter pressure is shown beside the service inventory, but only once counters were
// actually readable: an instance that published none must not read as "0 blocked".
$sql_view = require __DIR__ . '/windows-agent/sql-server-model.inc.php';
$sql_promoted = $sql_view['detected'];
$sql_section_summary = $sql_view['failure'] !== ''
    ? 'SQL collection failed; state not evaluated.'
    : $metric('Instances', $sql_view['total']) . ' ' . $metric('Conditions', count($sql_view['issues'])) . ' ' . $metric('Counters', count($sql_view['counterNames']) . '/' . $sql_view['runningCount'] . ' running instances');

$sections = [
    'agent' => [
        'title' => 'Agent',
        'state' => $section_state($agent_issues > 0 ? 'warning' : 'ok', $agent_issues),
        'summary' => $metric('Version', $agent['version'] ?? 'unknown') . ' ' . $metric('Host', $agent['host'] ?? 'unknown') . ' ' . $metric('Collector issues', $agent_issues),
    ],
    'collector_impact' => [
        'title' => 'Collector Impact',
        'state' => $agent_resource_state,
        'summary' => $metric('CPU', $format_percent($agent_resource_cpu_percent)) . ' ' . $metric('Memory', $format_bytes($agent_resource_memory_bytes)) . ' ' . $metric('Disk I/O', $format_bytes($agent_resource_io_bytes)) . ' ' . $metric('Duration', $agent_resource_duration_ms . ' ms'),
    ],
    'vm' => [
        'title' => 'VM Resources',
        'state' => $vm_state,
        'summary' => $metric('CPU', ($vm_resource_summary['cpu_load_percent'] ?? '0') . '%') . ' ' . $metric('Memory', ($vm_resource_summary['memory_used_percent'] ?? '0') . '%') . ' ' . $metric('Max disk', ($vm_resource_summary['disk_used_percent_max'] ?? '0') . '%'),
    ],
    'performance' => [
        'title' => 'Performance',
        'state' => $section_state($performance_summary['state'] ?? 'not_detected', (int) ($performance_summary['pressure_issues'] ?? 0)),
        'summary' => $metric('Pressure issues', $performance_summary['pressure_issues'] ?? '0') . ' ' . $metric('CPU queue', $performance_summary['cpu_queue_length'] ?? '0') . ' ' . $metric('Committed', ($performance_summary['memory_committed_percent'] ?? '0') . '%'),
    ],
    'ad_dc' => [
        'title' => 'AD/DC',
        'state' => $section_state($ad_dc_health_summary['state'] ?? 'not_applicable', (int) ($ad_dc_health_summary['health_issues'] ?? 0)),
        'summary' => $metric('Issues', $ad_dc_health_summary['health_issues'] ?? '0') . ' ' . $metric('Core down', $ad_dc_health_summary['core_services_not_running'] ?? '0') . ' ' . $metric('Shares missing', $ad_dc_health_summary['shares_missing'] ?? '0'),
    ],
    'sql' => [
        'title' => 'SQL',
        'state' => $section_state($sql_view['state']),
        'summary' => $sql_section_summary,
    ],
    'iis' => [
        'title' => 'IIS',
        'state' => $section_state($iis_summary['state'] ?? 'not_detected', (int) ($iis_summary['sites_stopped'] ?? 0) + (int) ($iis_summary['app_pools_stopped'] ?? 0)),
        'summary' => $metric('Sites', $iis_summary['sites_total'] ?? '0') . ' ' . $metric('Pools', $iis_summary['app_pools_total'] ?? '0') . ' ' . $metric('Stopped', ((int) ($iis_summary['sites_stopped'] ?? 0) + (int) ($iis_summary['app_pools_stopped'] ?? 0))),
    ],
    'horizon' => [
        'title' => 'Horizon',
        'state' => $horizon_section_state,
        'summary' => $horizon_section_summary,
    ],
    'factorytalk' => [
        'title' => 'FactoryTalk',
        'state' => $factorytalk_section_state,
        'summary' => $factorytalk_section_summary,
    ],
    'tls' => [
        'title' => 'TLS',
        'state' => $section_state($tls_certificates_summary['state'] ?? 'not_detected', $tls_unhealthy_count),
        'summary' => $metric('Stores', $tls_certificates_summary['store_count'] ?? '0') . ' ' . $metric('Certs', $tls_certificates_summary['certificate_count'] ?? '0') . ' ' . $metric('Expired', $tls_certificates_summary['expired_count'] ?? '0') . ' ' . $metric('Unhealthy', $tls_certificates_summary['unhealthy_count'] ?? '0'),
    ],
    'backup' => [
        'title' => 'Backup',
        'state' => $section_state($backup_state_key, $backup_health_issues),
        'summary' => $metric('VSS failed', $backup_storage_summary['vss_writers_failed'] ?? '0') . ' ' . $metric('Services down', $backup_storage_summary['backup_services_not_running'] ?? '0'),
    ],
    'datto' => [
        'title' => 'Datto',
        'state' => $section_state($datto_backup_summary['state'] ?? 'not_detected', (int) ($datto_backup_summary['health_issues'] ?? 0)),
        'summary' => $metric('Detected', $datto_backup_summary['detected'] ?? '0') . ' ' . $metric('Service running', $datto_backup_summary['service_running'] ?? '0') . ' ' . $metric('Issues', $datto_backup_summary['health_issues'] ?? '0'),
    ],
    'services' => [
        'title' => 'Services',
        'state' => $section_state($watched_service_issues > 0 ? 'warning' : 'ok', $watched_service_issues),
        'summary' => $metric('Watched down', $watched_service_issues) . ' ' . $metric('Classified stopped', $classified_services_stopped) . ' ' . $metric('Groups', count($classified_service_groups)),
    ],
    'events' => [
        'title' => 'Events',
        'state' => $section_state('ok'),
        'summary' => $metric('Logs', count($event_logs)) . ' ' . $metric('Critical/errors', $event_evidence_count) . ' ' . $metric('High-value groups', $event_log_high_value_summary['signatures_total'] ?? '0'),
    ],
    'processes' => [
        'title' => 'Processes',
        'state' => $section_state($process_issues > 0 ? 'warning' : 'ok', $process_issues),
        'summary' => $metric('Watched', count($watched_processes)) . ' ' . $metric('Missing', $process_issues),
    ],
    'tcp' => [
        'title' => 'TCP Ports',
        'state' => $section_state($tcp_issues > 0 ? 'warning' : 'ok', $tcp_issues),
        'summary' => $metric('Watched', count($watched_tcp_ports)) . ' ' . $metric('Not listening', $tcp_issues),
    ],
];

$overview = '<div class="panel panel-default windows-agent-overview-panel"><div class="panel-body"><h3 class="windows-agent-overview-title">Health Overview</h3>';
$overview .= '<div class="table-responsive"><table class="table table-condensed table-striped windows-agent-data-table">';
$overview .= '<tr><th>Section</th><th>State</th><th>Summary</th></tr>';
foreach ($sections as $section) {
    $overview .= '<tr><td><strong>' . $esc($section['title']) . '</strong></td><td>' . $section['state']['html'] . '</td><td>' . $section['summary'] . '</td></tr>';
}
$overview .= '</table></div></div></div>';

$agent_details = $kv_table([
    'Agent version' => $esc($agent['version'] ?? 'unknown'),
    'Agent host' => $esc($agent['host'] ?? 'unknown'),
    'Last agent UTC' => $esc($data['last_agent_utc'] ?? ''),
    'Config path' => $esc($agent['config'] ?? ''),
    'Windows OS' => $esc($windows_os['caption'] ?? 'unknown'),
    'Version' => $esc($windows_os['version'] ?? ''),
    'Build' => $esc($windows_os['build'] ?? ''),
    'Architecture' => $esc($windows_os['architecture'] ?? ''),
]);

$collector_details = $table(['Collector', 'State', 'Duration', 'Sections', 'Lines'], $issue_first($collector_timings, static fn (array $row): int => (strtolower((string) ($row['state'] ?? '')) === 'ok' ? 0 : 100000) + (int) ($row['duration_ms'] ?? 0), 'collector'), static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['collector'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown', ['ok']) . '</td><td>' . $esc($row['duration_ms'] ?? '0') . ' ms</td><td>' . $esc($row['section_count'] ?? '0') . '</td><td>' . $esc($row['line_count'] ?? '0') . '</td>';
});

$agent_resource_details = $kv_table([
    'Impact' => $agent_resource_state['html'],
    'Assessment' => $esc($agent_resource_assessment),
    'CPU used during collection' => $esc($format_percent($agent_resource_cpu_percent)) . ' / ' . $esc($agent_performance['process_cpu_ms'] ?? '0') . ' ms',
    'Memory footprint' => $esc($format_bytes($agent_resource_memory_bytes)),
    'Disk I/O during collection' => $esc($format_bytes($agent_resource_io_bytes)),
    'Disk I/O read/write' => $esc($format_bytes($agent_performance['process_io_read_bytes'] ?? 0)) . ' / ' . $esc($format_bytes($agent_performance['process_io_write_bytes'] ?? 0)),
    'Collection duration' => $esc($agent_resource_duration_ms) . ' ms',
]);

$agent_perf_details = $kv_table([
    'Collection duration' => $esc($agent_performance['collect_duration_ms'] ?? '0') . ' ms',
    'Collectors run' => $esc($agent_performance['collectors_run'] ?? '0'),
    'Failed / timed out' => $esc($agent_performance['collectors_failed'] ?? '0') . ' / ' . $esc($agent_performance['collectors_timed_out'] ?? '0'),
    'Payload size' => $esc($format_bytes($agent_performance['payload_bytes'] ?? 0)),
    'Process working set' => $esc($format_bytes($agent_performance['process_working_set_bytes'] ?? 0)),
    'Process private bytes' => $esc($format_bytes($agent_performance['process_private_bytes'] ?? 0)),
]) . $collector_details;

$vm_details = $kv_table([
    'CPU load' => $esc($vm_resource_summary['cpu_load_percent'] ?? '0') . '%',
    'Memory used' => $esc($vm_resource_summary['memory_used_percent'] ?? '0') . '%',
    'Physical memory used/free' => $esc($format_bytes($memory['used_bytes'] ?? 0)) . ' / ' . $esc($format_bytes($memory['physical_free_bytes'] ?? 0)),
    'Max disk used' => $esc($vm_resource_summary['disk_used_percent_max'] ?? '0') . '%',
    'Minimum disk free' => $esc($format_bytes($vm_resource_summary['disk_free_bytes_min'] ?? 0)),
]);
$vm_details .= $table(['CPU', 'Cores', 'Logical', 'Load', 'Max clock'], $cpu_details, static function ($row) use ($esc): string {
    return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['cores'] ?? '') . '</td><td>' . $esc($row['logical_processors'] ?? '') . '</td><td>' . $esc($row['load_percent'] ?? '0') . '%</td><td>' . $esc($row['max_clock_mhz'] ?? '') . ' MHz</td>';
});
$vm_details .= $table(['Disk', 'Volume', 'Filesystem', 'Used', 'Free', 'Used %', 'Free %'], $disks, static function ($row) use ($esc, $format_bytes): string {
    return '<td>' . $esc($row['device'] ?? '') . '</td><td>' . $esc($row['volume'] ?? '') . '</td><td>' . $esc($row['filesystem'] ?? '') . '</td><td>' . $esc($format_bytes($row['used_bytes'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['free_bytes'] ?? 0)) . '</td><td>' . $esc($row['used_percent'] ?? '0') . '%</td><td>' . $esc($row['free_percent'] ?? '0') . '%</td>';
});

$perf_details = $kv_table([
    'Pressure issues' => $esc($performance_summary['pressure_issues'] ?? '0'),
    'CPU queue / pressure' => $esc($performance_summary['cpu_queue_length'] ?? '0') . ' / ' . $esc($performance_summary['cpu_pressure'] ?? '0'),
    'Memory available / committed' => $esc($performance_summary['memory_available_mb'] ?? '0') . ' MB / ' . $esc($performance_summary['memory_committed_percent'] ?? '0') . '%',
    'Paging' => $esc($performance_summary['pages_per_sec'] ?? '0') . ' pages/sec / pressure=' . $esc($performance_summary['paging_pressure'] ?? '0'),
    'Disk read/write max' => $esc($performance_summary['disk_read_ms_max'] ?? '0') . ' / ' . $esc($performance_summary['disk_write_ms_max'] ?? '0') . ' ms',
    'Network throughput / errors' => $esc($format_bytes($performance_summary['network_bytes_per_sec_total'] ?? 0)) . '/s / ' . $esc($performance_summary['network_errors_total'] ?? '0'),
]);
if ($has_role_details($performance_summary, $performance_disks)) {
    $perf_details .= $table(['Disk', 'Read ms', 'Write ms', 'Queue', 'Bytes/sec'], $issue_first($performance_disks, static fn (array $row): int => (int) ($row['avg_read_ms'] ?? 0) + (int) ($row['avg_write_ms'] ?? 0) + ((int) ($row['current_queue_length'] ?? 0) * 10)), static function ($row) use ($esc, $format_bytes): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['avg_read_ms'] ?? '0') . '</td><td>' . $esc($row['avg_write_ms'] ?? '0') . '</td><td>' . $esc($row['current_queue_length'] ?? '0') . '</td><td>' . $esc($format_bytes($row['disk_bytes_per_sec'] ?? 0)) . '/s</td>';
    });
}
if ($has_role_details($performance_summary, $performance_network)) {
    $perf_details .= $table(['Interface', 'Bytes/sec', 'Packets/sec', 'Errors/sec', 'Discards/sec'], $issue_first($performance_network, static fn (array $row): int => (int) ($row['errors_per_sec'] ?? 0) + (int) ($row['discards_per_sec'] ?? 0)), static function ($row) use ($esc, $format_bytes): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($format_bytes($row['bytes_per_sec'] ?? 0)) . '/s</td><td>' . $esc($row['packets_per_sec'] ?? '0') . '</td><td>' . $esc($row['errors_per_sec'] ?? '0') . '</td><td>' . $esc($row['discards_per_sec'] ?? '0') . '</td>';
    });
}
if ($has_role_details($performance_summary, $performance_processes)) {
    $perf_details .= $table(['Process', 'PID', 'Rank', 'CPU %', 'Working set', 'Private bytes', 'Handles', 'Threads'], $performance_processes, static function ($row) use ($esc, $format_bytes): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['pid'] ?? '') . '</td><td>' . $esc($row['rank_source'] ?? '') . '</td><td>' . $esc($row['cpu_percent'] ?? '0') . '</td><td>' . $esc($format_bytes($row['working_set_bytes'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['private_bytes'] ?? 0)) . '</td><td>' . $esc($row['handle_count'] ?? '0') . '</td><td>' . $esc($row['thread_count'] ?? '0') . '</td>';
    });
}

// Higher scores sort first; a stopped engine outranks a stopped SQL Agent.
$sql_component_details = $table(['Component', 'Service', 'Instance', 'State', 'Start mode', 'Expected', 'Reason'], $issue_first($sql_server_components, static fn (array $row): int => in_array(strtolower((string) ($row['severity'] ?? 'ok')), ['warning', 'critical'], true) ? 1 : 0, 'name'), static function (array $row) use ($esc): string {
    return '<td>' . $esc($row['component'] ?? '') . '</td><td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['instance'] ?? 'Shared') . '</td><td>' . $esc($row['state'] ?? 'Not reported') . '</td><td>' . $esc($row['start_mode'] ?? 'Not reported') . '</td><td>' . $esc(array_key_exists('expected', $row) ? ((int) $row['expected'] === 1 ? 'yes' : 'no') : 'Not reported') . '</td><td>' . $esc($row['reason'] ?? 'Not reported') . '</td>';
});

$iis_details = '';
$iis_rows = [];
if ($has_role_details($iis_summary, $iis_sites)) {
    foreach ($iis_sites as $row) {
        $iis_rows[] = [
            'type' => 'Site',
            'name' => $row['name'] ?? '',
            'state' => $row['state'] ?? 'unknown',
            'detail' => 'ID ' . ($row['id'] ?? '') . ', bindings ' . ($row['bindings_count'] ?? ''),
            'path' => $row['physical_path'] ?? '',
            'score' => in_array(strtolower((string) ($row['state'] ?? '')), ['started', 'running'], true) ? 10 : 0,
        ];
    }
}
if ($has_role_details($iis_summary, $iis_app_pools)) {
    foreach ($iis_app_pools as $row) {
        $iis_rows[] = [
            'type' => 'App pool',
            'name' => $row['name'] ?? '',
            'state' => $row['state'] ?? 'unknown',
            'detail' => trim(($row['runtime_version'] ?? '') . ' ' . ($row['pipeline_mode'] ?? '')),
            'path' => $row['identity_type'] ?? '',
            'score' => in_array(strtolower((string) ($row['state'] ?? '')), ['started', 'running'], true) ? 10 : 0,
        ];
    }
}
if ($has_role_details($iis_summary, $iis_bindings)) {
    foreach ($iis_bindings as $row) {
        $binding = trim(($row['protocol'] ?? '') . ' ' . ($row['binding_information'] ?? ''));
        $target = trim(($row['hostname'] ?? '') . ':' . ($row['port'] ?? ''), ':');
        $iis_rows[] = [
            'type' => 'Binding',
            'name' => $row['site'] ?? '',
            'state' => 'inventory',
            'detail' => $binding . ($target === '' ? '' : ' (' . $target . ')'),
            'path' => $row['certificate_thumbprint'] ?? '',
            'score' => 20,
        ];
    }
}
if (! empty($iis_rows)) {
    $iis_details .= $table(['Type', 'Name', 'State', 'Detail', 'Path / Certificate'], $issue_first($iis_rows, static fn (array $row): int => (int) ($row['score'] ?? 0), 'name'), static function ($row) use ($esc, $state_label): string {
        $state = strtolower((string) ($row['state'] ?? ''));
        $state_html = $state === 'inventory'
            ? '<span class="label label-default">Inventory</span>'
            : $state_label($row['state'] ?? 'unknown', ['started', 'running']);

        return '<td>' . $esc($row['type'] ?? '') . '</td><td>' . $esc($row['name'] ?? '') . '</td><td>' . $state_html . '</td><td>' . $esc($row['detail'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td>';
    });
}

$render_horizon_local_diagnostics = static function () use (
    $esc,
    $format_bytes,
    $format_percent,
    $has_role_details,
    $horizon_api_session_protocols,
    $horizon_certificates,
    $horizon_ports,
    $horizon_processes,
    $horizon_runtime_processes,
    $horizon_services,
    $horizon_summary,
    $state_label,
    $table
): string {
    $details = '';
    if ($has_role_details($horizon_summary, $horizon_services)) {
        $details .= '<h4>Local Service Inventory</h4>' . $table(['Service', 'Display', 'Role', 'State', 'Start mode', 'Path'], $horizon_services, static function ($row) use ($esc, $state_label): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td>';
        });
    }
    if ($has_role_details($horizon_summary, $horizon_processes)) {
        $details .= '<h4>Local Process Inventory</h4>' . $table(['Process', 'PID', 'Role', 'Path'], $horizon_processes, static function ($row) use ($esc): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['pid'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td>';
        });
    }
    if (! empty($horizon_runtime_processes)) {
        $details .= '<h4>Process Runtime</h4>' . $table(['Process', 'Role', 'CPU', 'Working set', 'Private bytes', 'Handles', 'Threads', 'Read/s', 'Write/s', 'Uptime (s)'], $horizon_runtime_processes, static function ($row) use ($esc, $format_bytes, $format_percent): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($format_percent($row['cpu_percent'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['working_set_bytes'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['private_bytes'] ?? 0)) . '</td><td>' . $esc($row['handle_count'] ?? 0) . '</td><td>' . $esc($row['thread_count'] ?? 0) . '</td><td>' . $esc($format_bytes($row['io_read_bytes_per_sec'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['io_write_bytes_per_sec'] ?? 0)) . '</td><td>' . $esc($row['uptime_seconds'] ?? 0) . '</td>';
        });
    }
    if (! empty($horizon_api_session_protocols)) {
        $details .= '<h4>Session Protocol Aggregates</h4>' . $table(['Protocol', 'Sessions'], $horizon_api_session_protocols, static function ($row) use ($esc): string {
            return '<td>' . $esc(strtoupper((string) ($row['protocol'] ?? ''))) . '</td><td>' . $esc($row['sessions'] ?? 0) . '</td>';
        });
    }
    if ($has_role_details($horizon_summary, $horizon_ports)) {
        $details .= '<h4>Listener Inventory</h4>' . $table(['Port', 'Required for health', 'Listening', 'Addresses'], $horizon_ports, static function ($row) use ($esc, $state_label): string {
            return '<td>' . $esc($row['port'] ?? '') . '</td><td>' . ((int) ($row['port'] ?? 0) === 443 ? 'Yes' : 'No') . '</td><td>' . $state_label($row['listening'] ?? 0) . '</td><td>' . $esc($row['addresses'] ?? '') . '</td>';
        });
    }
    if ($has_role_details($horizon_summary, $horizon_certificates)) {
        $details .= '<h4>Host Certificates</h4>' . $table(['Store', 'Subject', 'Issuer', 'Expires UTC', 'Days', 'Expired', 'Thumbprint'], $horizon_certificates, static function ($row) use ($esc, $state_label): string {
            return '<td>' . $esc($row['store'] ?? '') . '</td><td>' . $esc($row['subject'] ?? '') . '</td><td>' . $esc($row['issuer'] ?? '') . '</td><td>' . $esc($row['not_after_utc'] ?? '') . '</td><td>' . $esc($row['days_remaining'] ?? '') . '</td><td>' . $state_label($row['expired'] ?? 0, ['0']) . '</td><td>' . $esc($row['thumbprint'] ?? '') . '</td>';
        });
    }

    return $details;
};

$horizon_details = '';
$horizon_surface_available = $horizon_detected || $horizon_client_only || $horizon_api_enabled;
if ($horizon_surface_available) {
    $horizon_details .= '<div class="windows-agent-horizon-operations">';
    $horizon_details .= '<div class="windows-agent-horizon-title-row"><div><h3>Horizon Operations</h3><p class="text-muted">VMware Horizon <span aria-hidden="true">•</span> Pod ' . $esc($horizon_pod_summary['pod_name'] ?? $horizon_pod_summary['cluster_name'] ?? 'unknown') . '</p></div>';
    $freshness = $format_horizon_age($horizon_central_meta['snapshot_age_seconds'] ?? -1);
    $coverageComplete = array_key_exists('snapshot_inventory_complete', $horizon_central_meta)
        ? (int) $horizon_central_meta['snapshot_inventory_complete'] === 1
        : (array_key_exists('inventory_complete', $horizon_central_meta)
        ? (int) $horizon_central_meta['inventory_complete'] === 1
        : ((int) ($horizon_api_summary['sessions_truncated'] ?? 0) === 0
            && (int) ($horizon_api_summary['machines_truncated'] ?? 0) === 0
            && (int) ($horizon_api_summary['machine_details_truncated'] ?? 0) === 0
            && (int) ($horizon_api_summary['machine_issues_truncated'] ?? 0) === 0
            && (int) ($horizon_api_summary['service_details_truncated'] ?? 0) === 0));
    $coverage = $coverageComplete ? 'Complete snapshot' : 'Inventory incomplete';
    $horizon_source = trim((string) ($horizon_central_meta['source_endpoint'] ?? ''));
    $horizon_source_html = $horizon_source !== '' ? ' <span aria-hidden="true">•</span> via ' . $esc($horizon_source) : '';
    $horizon_details .= '<div class="windows-agent-horizon-freshness">Collected ' . $esc($freshness) . ' <span aria-hidden="true">•</span> ' . $esc($coverage) . $horizon_source_html . '</div></div>';
    $healthScopes = [
        'Overall' => $horizon_health_summary['overall_health_state'] ?? $horizon_api_summary['overall_health_state'] ?? $horizon_api_summary['health_state'] ?? 'incomplete',
        'Platform' => $horizon_health_summary['platform_health_state'] ?? $horizon_api_summary['platform_health_state'] ?? $horizon_pod_summary['state'] ?? 'incomplete',
        'Dependencies' => $horizon_health_summary['dependency_health_state'] ?? $horizon_api_summary['dependency_health_state'] ?? $horizon_directory_summary['state'] ?? 'incomplete',
        'Capacity' => $horizon_health_summary['capacity_health_state'] ?? $horizon_api_summary['capacity_health_state'] ?? $horizon_pools_summary['state'] ?? 'incomplete',
        'Collector' => $horizon_health_summary['collector_health_state'] ?? $horizon_api_summary['collector_health_state'] ?? ($horizon_api_stale ? 'warning' : 'ok'),
    ];
    $horizon_details .= '<section class="windows-agent-horizon-health-scopes" aria-label="Horizon health by scope">';
    foreach ($healthScopes as $label => $state) {
        $normalized = strtolower((string) $state);
        $horizon_details .= '<div class="windows-agent-horizon-health-scope windows-agent-horizon-health-scope-' . $esc($normalized) . '"><span>' . $esc($label) . '</span><strong>' . $esc($normalized === 'ok' ? 'OK' : ucfirst($normalized)) . '</strong></div>';
    }
    $horizon_details .= '</section>';
    if ($horizon_health_issue_count > 0) {
        $horizon_details .= '<p class="sr-only">' . $esc($horizon_health_issue_count) . ' Horizon issue(s) need review.</p>';
    }

    $conditions = [];
    if ($horizon_api_stale) {
        $conditions[] = [
            'severity' => 35,
            'state' => 'warning',
            'object' => 'Central collector',
            'reason' => 'Horizon API collection is stale; last good snapshot retained',
            'evidence' => 'Last success ' . (string) ($horizon_central_meta['last_success_utc'] ?? 'unknown') . ' • reason ' . (string) ($horizon_central_meta['reason'] ?? 'unknown'),
            'next' => 'Review collector reliability and endpoint evidence.',
            'target' => '#windows-agent-horizon-collector-trend',
            'action' => 'disclosure',
        ];
    }
    foreach ($horizon_pools as $pool) {
        $state = strtolower((string) ($pool['health_state'] ?? 'incomplete'));
        if ($state === 'ok' || $state === 'disabled') continue;
        $reason = (string) ($pool['health_reason'] ?? 'inventory_incomplete');
        $severity = ['critical' => 40, 'warning' => 30, 'incomplete' => 25, 'info' => 10][$state] ?? 20;
        $next = match ($reason) {
            'spare_capacity_critical' => 'Recover the unavailable machines to restore spare capacity.',
            'low_spare_capacity' => 'Spare capacity is low; add capacity or free machines.',
            'multiple_machines_unavailable' => 'Review the unavailable machines.',
            'one_machine_unavailable' => 'Review the unavailable machine when convenient.',
            'no_placement_capacity' => 'Add capacity or end idle sessions. Nothing is faulted.',
            'ready_spares_faulted' => 'Recover the faulted machines; no ready spare remains.',
            'multiple_faulted_spares' => 'Review the faulted machines.',
            'faulted_spare_capacity_remains' => 'Review the faulted machine when convenient.',
            'spares_pending_only' => 'Wait for the pending machines to finish becoming ready.',
            'spares_held_only' => 'Confirm the withheld machines are intentional and restore capacity.',
            'spare_readiness_undetermined' => 'Spare readiness could not be determined; check the machine inventory.',
            default => 'Review pool inventory completeness.',
        };
        $conditions[] = [
            'severity' => $severity,
            'state' => $state,
            'object' => (string) ($pool['display_name'] ?? $pool['name'] ?? 'Unknown pool'),
            'reason' => $humanize_horizon_reason($reason),
            'evidence' => (string) ($pool['machines_with_sessions'] ?? 0) . ' of ' . (string) ($pool['machines_total'] ?? 0) . ' in session • ' . (string) ($pool['spare_ready'] ?? 0) . ' ready • ' . (string) ($pool['spare_unready'] ?? 0) . ' unavailable',
            'next' => $next,
            'action' => 'pool',
            'ref' => substr(hash('sha256', (string) ($pool['id'] ?? $pool['name'] ?? '')), 0, 12),
            'filter' => (int) ($pool['spare_unready'] ?? 0) > 0 ? 'unavailable' : 'all',
        ];
    }
    foreach ($horizon_pod_members as $member) {
        foreach (is_array($member['unhealthy_services'] ?? null) ? $member['unhealthy_services'] : [] as $service) {
            $conditions[] = [
                'severity' => 30,
                'state' => 'warning',
                'object' => (string) ($member['name'] ?? 'Connection Server'),
                'reason' => (string) ($service['name'] ?? 'Unknown service') . ' unhealthy',
                'evidence' => 'Service status ' . (string) ($service['status'] ?? 'UNKNOWN'),
                'next' => 'Review the service and related Horizon components.',
                'action' => 'member',
                'ref' => substr(hash('sha256', strtolower((string) ($member['name'] ?? 'Connection Server'))), 0, 12),
            ];
        }
    }
    foreach ($horizon_attention as $attention) {
        $attentionState = strtolower((string) ($attention['state'] ?? 'warning'));
        $conditions[] = [
            'severity' => ['critical' => 40, 'warning' => 30, 'incomplete' => 25][$attentionState] ?? 20,
            'state' => $attentionState,
            'object' => 'Local Connection Server',
            'reason' => (string) ($attention['title'] ?? 'Horizon health issue'),
            'evidence' => (string) ($attention['detail'] ?? ''),
            'next' => (string) ($attention['action'] ?? 'Review Horizon diagnostics.'),
            'target' => '#windows-agent-horizon-raw',
            'action' => 'disclosure',
        ];
    }
    if ($horizon_conditions !== []) {
        $conditions = [];
        foreach ($horizon_conditions as $condition) {
            if (! is_array($condition)) continue;
            $state = strtolower((string) ($condition['severity'] ?? $condition['state'] ?? 'incomplete'));
            $scope = strtolower((string) ($condition['scope'] ?? 'pod'));
            $reasonCode = (string) ($condition['reason_code'] ?? 'health_condition');
            // Ref (id) drives the drawer/pool linkage hash; label is what the operator
            // sees. A pool's id is an opaque hash, so never show it as the label.
            $objectRef = (string) ($condition['object_ref'] ?? ucfirst($scope));
            $object = (string) ($condition['object_name'] ?? $objectRef);
            $action = 'disclosure';
            $target = '#windows-agent-horizon-pod-details';
            $ref = '';
            $filter = 'all';
            if ($scope === 'server') {
                $action = 'member';
                $ref = substr(hash('sha256', strtolower($objectRef)), 0, 12);
            } elseif ($scope === 'pool') {
                $action = 'pool';
                $ref = substr(hash('sha256', $objectRef), 0, 12);
                $filter = 'unavailable';
            } elseif ($scope === 'collector') {
                $target = '#windows-agent-horizon-collector-trend';
            } elseif ($scope === 'dependency') {
                $target = '#windows-agent-horizon-pod-details';
            }
            $conditions[] = [
                'severity' => ['critical' => 40, 'warning' => 30, 'incomplete' => 25][$state] ?? 20,
                'state' => $state,
                'object' => $object,
                'reason' => $humanize_horizon_reason($reasonCode),
                'evidence' => (string) ($condition['evidence'] ?? ''),
                'next' => $horizon_condition_next($scope, $reasonCode),
                'action' => $action,
                'target' => $target,
                'ref' => $ref,
                'filter' => $filter,
            ];
        }
    }
    usort($conditions, static fn (array $left, array $right): int => ($right['severity'] <=> $left['severity']) ?: strcasecmp((string) $left['object'], (string) $right['object']));

    $horizon_details .= '<section class="windows-agent-horizon-section windows-agent-horizon-conditions"><div class="windows-agent-horizon-section-heading"><h4>Conditions requiring attention</h4><span class="text-muted">' . count($conditions) . ' current</span></div>';
    if ($conditions === []) {
        $horizon_details .= '<div class="windows-agent-horizon-condition windows-agent-horizon-condition-ok"><span class="glyphicon glyphicon-ok-sign" aria-hidden="true"></span><div><strong>No actionable Horizon conditions</strong><div class="text-muted">Platform, pool capacity, and collection evidence are healthy.</div></div></div>';
    } else {
        foreach ($conditions as $condition) {
            $state = (string) $condition['state'];
            $label = $state === 'info' ? 'Informational' : ($state === 'incomplete' ? 'Incomplete' : ucfirst($state));
            $icon = $state === 'critical' ? 'glyphicon-remove-sign' : ($state === 'info' ? 'glyphicon-info-sign' : 'glyphicon-exclamation-sign');
            $horizon_details .= '<div class="windows-agent-horizon-condition windows-agent-horizon-condition-' . $esc($state) . '"><span class="glyphicon ' . $icon . '" aria-hidden="true"></span>';
            $horizon_details .= '<div class="windows-agent-horizon-condition-severity"><strong>' . $esc($label) . '</strong></div><div>';
            if (($condition['action'] ?? '') === 'member') {
                $horizon_details .= '<button type="button" class="windows-agent-horizon-condition-target" data-member-drawer="' . $esc($condition['ref'] ?? '') . '"><strong>' . $esc($condition['object']) . '</strong><span class="sr-only"> details</span></button>';
            } elseif (($condition['action'] ?? '') === 'pool') {
                $horizon_details .= '<button type="button" class="windows-agent-horizon-condition-target" data-pool-open-filter="' . $esc($condition['filter'] ?? 'all') . '" data-pool="' . $esc($condition['ref'] ?? '') . '"><strong>' . $esc($condition['object']) . '</strong><span class="sr-only"> pool details</span></button>';
            } else {
                $horizon_details .= '<a class="windows-agent-horizon-condition-target" href="' . $esc($condition['target'] ?? '#windows-agent-horizon-pool-workspace') . '"><strong>' . $esc($condition['object']) . '</strong></a>';
            }
            $horizon_details .= '</div>';
            $horizon_details .= '<div><strong>' . $esc($condition['reason']) . '</strong><div class="text-muted">' . $esc($condition['evidence']) . '</div></div><div><span class="text-muted">Next:</span> ' . $esc($condition['next']) . '</div></div>';
        }
    }
    $horizon_details .= '</section>';
    if ($horizon_observations !== []) {
        $horizon_details .= '<section class="windows-agent-horizon-section windows-agent-horizon-observations"><div class="windows-agent-horizon-section-heading"><h4>Informational observations</h4><span class="text-muted">' . count($horizon_observations) . ' grouped</span></div>';
        foreach ($horizon_observations as $observation) {
            if (! is_array($observation)) continue;
            $objects = is_array($observation['objects'] ?? null) ? $observation['objects'] : [];
            $horizon_details .= '<div class="windows-agent-horizon-observation"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span><div><strong>' . $esc($humanize_horizon_reason($observation['reason_code'] ?? 'observation')) . '</strong><div class="text-muted">' . $esc($observation['component'] ?? '') . ' • ' . $esc(count($objects)) . ' member(s): ' . $esc(implode(', ', $objects)) . '</div></div></div>';
        }
        $horizon_details .= '</section>';
    }

    foreach ($horizon_pod_members as $member) {
        $memberName = (string) ($member['name'] ?? 'Connection Server');
        $memberRef = substr(hash('sha256', strtolower($memberName)), 0, 12);
        $memberServices = is_array($member['unhealthy_services'] ?? null) ? $member['unhealthy_services'] : [];
        $memberState = strtolower((string) ($member['health_state'] ?? ''));
        $memberHealthy = $memberState !== ''
            ? in_array($memberState, ['ok', 'info'], true)
            : ($memberServices === [] && (int) ($member['configuration_replications_unhealthy'] ?? 0) === 0 && (int) ($member['certificate_valid'] ?? 1) === 1);
        $horizon_details .= '<aside id="windows-agent-horizon-member-drawer-' . $esc($memberRef) . '" class="windows-agent-horizon-detail-drawer" data-horizon-drawer-panel="' . $esc($memberRef) . '" hidden><div class="windows-agent-horizon-drawer-header"><h4>Connection Server details</h4><button type="button" class="close" data-horizon-drawer-close aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
        $memberCertInvalid = (int) ($member['certificate_valid'] ?? 1) === 0;
        $horizon_details .= '<h3>' . $esc($memberName) . '</h3><p class="' . ($memberHealthy ? 'text-success' : 'text-warning') . '"><span class="glyphicon ' . ($memberHealthy ? 'glyphicon-ok-sign' : 'glyphicon-exclamation-sign') . '" aria-hidden="true"></span> ' . ($memberHealthy ? 'Healthy' : 'Attention required') . '</p><dl>';
        foreach ([
            'Horizon status' => $member['status'] ?? 'unknown',
            'Type' => str_replace('_', ' ', (string) ($member['server_type'] ?? 'connection_server')),
            'Version' => $member['version'] ?? 'unknown',
            'Connections' => $member['connections'] ?? 0,
            'API role' => ((int) ($member['local_api_target'] ?? 0) === 1) ? 'Current API target' : 'Peer',
            'Certificate' => $memberCertInvalid ? 'Invalid' : 'Valid',
            'Replication issues' => $member['configuration_replications_unhealthy'] ?? 0,
        ] as $label => $value) {
            $ddInvalid = $label === 'Certificate' && $memberCertInvalid;
            $horizon_details .= '<dt>' . $esc($label) . '</dt><dd>'
                . ($ddInvalid ? '<span class="text-danger"><strong>' . $esc($value) . '</strong></span>' : $esc($value))
                . '</dd>';
        }
        $horizon_details .= '</dl><div class="windows-agent-horizon-drawer-evidence"><h4>Unhealthy services</h4>';
        if ($memberServices === []) {
            $horizon_details .= '<p class="text-success">No unhealthy services reported.</p>';
        } else {
            $horizon_details .= '<ul class="windows-agent-horizon-service-list">';
            foreach ($memberServices as $service) {
                $horizon_details .= '<li><strong>' . $esc($service['name'] ?? 'Unknown service') . '</strong><span class="text-warning">' . $esc($service['status'] ?? 'UNKNOWN') . '</span></li>';
            }
            $horizon_details .= '</ul>';
        }
        if ((int) ($member['unhealthy_services_truncated'] ?? 0) === 1) {
            $horizon_details .= '<p class="text-warning">Additional unhealthy services were truncated.</p>';
        }
        $memberNext = $memberHealthy
            ? 'No action required.'
            : ($memberCertInvalid
                ? 'The active certificate is invalid. Renew or rebind the Horizon server certificate on this Connection Server.'
                : 'Review the listed Horizon service and related Connection Server components.');
        $horizon_details .= '</div><div class="windows-agent-horizon-drawer-next"><h4>Next action</h4><p>' . $esc($memberNext) . '</p></div></aside>';
    }
    $horizon_details .= '<button type="button" class="windows-agent-horizon-drawer-backdrop" data-horizon-drawer-backdrop hidden aria-label="Close details"></button>';

    if ($horizon_api_available) {
        $machinesByPool = [];
        foreach ($horizon_pool_machines as $machine) {
            $poolKey = (string) ($machine['pool_id'] ?? $machine['pool'] ?? '');
            $machinesByPool[$poolKey][] = $machine;
        }
        if ($machinesByPool === []) {
            foreach ($horizon_pool_machine_issues as $machine) {
                $poolKey = (string) ($machine['pool_id'] ?? $machine['pool'] ?? '');
                $machinesByPool[$poolKey][] = $machine;
            }
        }
        $sortedPools = $issue_first($horizon_pools, static function (array $row): int {
            return ['critical' => 50, 'warning' => 40, 'incomplete' => 30, 'info' => 20, 'disabled' => 10, 'ok' => 0][strtolower((string) ($row['health_state'] ?? 'incomplete'))] ?? 30;
        }, 'name');
        $horizon_details .= '<section class="windows-agent-horizon-section" id="windows-agent-horizon-pool-workspace"><div class="windows-agent-horizon-section-heading"><h4>Pool capacity</h4><span class="windows-agent-horizon-policy"><i class="windows-agent-horizon-dot windows-agent-horizon-dot-info"></i> 1 unavailable = info <i class="windows-agent-horizon-dot windows-agent-horizon-dot-warning"></i> 2+ unavailable, or low spare = warning <i class="windows-agent-horizon-dot windows-agent-horizon-dot-critical"></i> low spare + machines down = critical</span></div>';
        $horizon_details .= '<div class="windows-agent-horizon-pool-head" aria-hidden="true"><span>Pool</span><span>State</span><span>Machines</span><span>In session</span><span>Available</span><span>Unavailable</span><span>Placement headroom</span><span>Demand</span></div>';
        foreach ($sortedPools as $pool) {
            $poolKey = (string) ($pool['id'] ?? $pool['name'] ?? '');
            $poolMachines = $machinesByPool[$poolKey] ?? $machinesByPool[(string) ($pool['name'] ?? '')] ?? [];
            $poolRef = substr(hash('sha256', $poolKey), 0, 12);
            $state = strtolower((string) ($pool['health_state'] ?? 'incomplete'));
            $machines = max(0, (int) ($pool['machines_total'] ?? 0));
            $sessions = max(0, (int) ($pool['machines_with_sessions'] ?? 0));
            $headroom = array_key_exists('placement_headroom_percent', $pool)
                ? max(0, min(100, (float) $pool['placement_headroom_percent']))
                : ($machines > 0 ? max(0, min(100, ((int) ($pool['spare_ready'] ?? 0) / $machines) * 100)) : 0);
            $occupancy = $machines > 0 ? ($sessions / $machines) * 100 : 0;
            $demand = $headroom <= 0 ? 'High' : ($occupancy >= 75 ? 'Moderate' : 'Low');
            $horizon_details .= '<div class="windows-agent-horizon-pool windows-agent-horizon-pool-' . $esc($state) . '">';
            $stateLabel = $state === 'info' ? 'Capacity available' : ucfirst($state);
            $horizon_details .= '<div class="windows-agent-horizon-pool-summary">';
            $horizon_details .= '<button type="button" class="windows-agent-horizon-pool-toggle" aria-expanded="false" aria-controls="windows-agent-horizon-pool-' . $esc($poolRef) . '" data-pool-toggle="' . $esc($poolRef) . '"><span class="glyphicon glyphicon-chevron-right windows-agent-horizon-pool-chevron" aria-hidden="true"></span><span class="windows-agent-horizon-pool-name"><strong>' . $esc($pool['display_name'] ?? $pool['name'] ?? 'Unknown pool') . '</strong><small>' . $esc($humanize_horizon_reason($pool['health_reason'] ?? 'unknown')) . '</small></span></button>';
            $horizon_details .= '<span class="windows-agent-horizon-pool-state" data-metric-label="State"><strong>' . $esc($stateLabel) . '</strong></span>';
            foreach ([
                'all' => ['value' => $machines, 'label' => 'all machines', 'metric' => 'Machines'],
                'sessions' => ['value' => $sessions, 'label' => 'in-session machines', 'metric' => 'In session'],
                'ready' => ['value' => (int) ($pool['spare_ready'] ?? 0), 'label' => 'available machines', 'metric' => 'Available'],
                'unavailable' => ['value' => (int) ($pool['spare_unready'] ?? 0), 'label' => 'unavailable machines', 'metric' => 'Unavailable'],
            ] as $filter => $count) {
                $horizon_details .= '<button type="button" class="windows-agent-horizon-pool-count" data-metric-label="' . $esc($count['metric']) . '" data-pool-open-filter="' . $esc($filter) . '" data-pool="' . $esc($poolRef) . '" aria-label="Show ' . $esc($count['value']) . ' ' . $esc($count['label']) . '">' . $esc($count['value']) . '</button>';
            }
            $horizon_details .= '<span class="windows-agent-horizon-headroom" data-metric-label="Headroom"><strong>' . $esc(number_format($headroom, 1)) . '%</strong><i><b style="width:' . $esc($headroom) . '%"></b></i></span><span class="windows-agent-horizon-demand" data-metric-label="Demand">' . $esc($demand) . '</span></div>';
            $horizon_details .= '<div id="windows-agent-horizon-pool-' . $esc($poolRef) . '" class="windows-agent-horizon-machine-region" data-pool-region="' . $esc($poolRef) . '" hidden>';
            $horizon_details .= '<div class="windows-agent-horizon-machine-toolbar"><div><strong>Machine inventory</strong><span class="text-muted"> ' . $esc($pool['display_name'] ?? $pool['name'] ?? 'pool') . '</span></div><div class="btn-group btn-group-xs" role="group" aria-label="Machine filter">';
            $filters = [
                'all' => 'All ' . $machines,
                'sessions' => 'In session ' . $sessions,
                'ready' => 'Available ' . (int) ($pool['spare_ready'] ?? 0),
                'unavailable' => 'Unavailable ' . (int) ($pool['spare_unready'] ?? 0),
            ];
            foreach ($filters as $filter => $label) {
                $active = $filter === 'all';
                $horizon_details .= '<button type="button" class="btn btn-default windows-agent-horizon-machine-filter' . ($active ? ' active' : '') . '" data-machine-filter="' . $esc($filter) . '" data-pool="' . $esc($poolRef) . '" aria-pressed="' . ($active ? 'true' : 'false') . '">' . $esc($label) . '</button>';
            }
            $horizon_details .= '</div></div>';
            $horizon_details .= '<div class="windows-agent-horizon-machine-head"><span>Machine</span><span>State</span><span>Session</span><span>Maintenance</span><span>Issue</span><span>Collected</span></div>';
            foreach ($poolMachines as $machineIndex => $machine) {
                $drawerRef = $poolRef . '-' . $machineIndex;
                $hasSession = (int) ($machine['has_session'] ?? 0) === 1;
                $maintenance = (int) ($machine['maintenance'] ?? 0) === 1;
                $isIssue = (int) ($machine['issue'] ?? (($machine['issue_reason'] ?? 'none') !== 'none' ? 1 : 0)) === 1;
                // Group by the collector's own placement decision so a row can never
                // disagree with the filter counters beside it. Fall back to the old
                // local derivation only for data collected before placement existed.
                $placement = strtolower((string) ($machine['placement'] ?? ''));
                if ($placement === '') {
                    $placement = $hasSession
                        ? 'none'
                        : (! $maintenance && strtoupper((string) ($machine['state'] ?? '')) === 'AVAILABLE' ? 'ready' : 'occupied');
                }
                $sessionKind = strtolower((string) ($machine['session_kind'] ?? ''));
                if ($sessionKind === '' || $sessionKind === 'none') {
                    $sessionLabel = $hasSession ? 'Present' : 'None';
                } else {
                    $sessionLabel = ['connected' => 'Connected', 'disconnected' => 'Disconnected'][$sessionKind] ?? 'Present';
                }
                // Intentionally withheld (maintenance, disabled) is unavailable but
                // not a problem. It gets its own muted marker, distinct from both the
                // yellow issue flag and a plain row, so "unavailable on purpose" reads
                // at a glance without being mistaken for a fault.
                $withheld = ! $isIssue && ($placement === 'held' || $maintenance);
                // Row colour follows the collector's per-machine severity, decoupled
                // from the problem-machine flag: critical (red) = broken, warning
                // (yellow) = out of service on purpose, otherwise unflagged. A
                // disconnected-but-reconnectable machine is healthy and stays plain.
                $rowSeverity = strtolower((string) ($machine['severity'] ?? ''));
                if ($rowSeverity === '' && $isIssue) {
                    $rowSeverity = 'critical';
                } elseif ($rowSeverity === '' && $withheld) {
                    $rowSeverity = 'warning';
                }
                $categories = ['all'];
                if ($isIssue) $categories[] = 'issues';
                if ($placement === 'none') $categories[] = 'sessions';
                elseif ($placement === 'ready') $categories[] = 'ready';
                else $categories[] = 'unavailable';
                $reason = $isIssue ? $humanize_horizon_reason($machine['issue_reason'] ?? 'unknown') : 'None';
                $next = match ((string) ($machine['issue_reason'] ?? 'none')) {
                    'agent_unreachable' => 'Verify the Horizon Agent service and machine network connectivity.',
                    'maintenance_mode' => 'Confirm that maintenance mode is intentional and restore capacity when ready.',
                    'provisioning_error' => 'Review image, provisioning, and clone-operation evidence.',
                    'none' => 'No action required.',
                    default => $isIssue ? 'Review the machine state and related Horizon evidence.' : 'No action required.',
                };
                // A stuck disconnected session gets a plain-language, duration-aware
                // message: how long since the user was last connected, and what it means.
                $disconnectedSeconds = max(0, (int) ($machine['disconnected_seconds'] ?? 0));
                $disconnectedHuman = $disconnectedSeconds >= 3600
                    ? intdiv($disconnectedSeconds, 3600) . 'h ' . intdiv($disconnectedSeconds % 3600, 60) . 'm'
                    : intdiv($disconnectedSeconds, 60) . 'm';
                $stuckMessage = '';
                if ((string) ($machine['issue_reason'] ?? '') === 'session_disconnected_stuck') {
                    $reason = 'Not reconnected in ' . $disconnectedHuman;
                    $stuckMessage = 'User has not reconnected in ' . $disconnectedHuman . '. The machine is unavailable for other users.';
                    $next = $stuckMessage;
                }
                $rowClass = 'windows-agent-horizon-machine-row';
                $rowMarker = '';
                if ($rowSeverity === 'critical') {
                    $rowClass .= ' windows-agent-horizon-machine-critical';
                    $rowMarker = '<span class="glyphicon glyphicon-exclamation-sign" title="Down" aria-hidden="true"></span> ';
                } elseif ($rowSeverity === 'warning') {
                    $rowClass .= ' windows-agent-horizon-machine-warning';
                    $rowMarker = '<span class="glyphicon glyphicon-pause" title="Out of service" aria-hidden="true"></span> ';
                }
                $horizon_details .= '<button type="button" class="' . $rowClass . '" data-machine-category="' . $esc(implode(' ', $categories)) . '" data-machine-drawer="' . $esc($drawerRef) . '" aria-controls="windows-agent-horizon-machine-drawer-' . $esc($drawerRef) . '"><span>' . $rowMarker . '<strong>' . $esc($machine['name'] ?? $machine['id'] ?? 'unknown') . '</strong></span><span>' . $esc($humanize_horizon_reason($machine['state'] ?? 'unknown')) . '</span><span>' . $esc($sessionLabel) . '</span><span>' . ($maintenance ? 'Yes' : 'No') . '</span><span>' . $esc($reason) . '</span><span>' . $esc($machine['collected_utc'] ?? 'unknown') . ' <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span></span></button>';
                $horizon_details .= '<aside id="windows-agent-horizon-machine-drawer-' . $esc($drawerRef) . '" class="windows-agent-horizon-detail-drawer" data-horizon-drawer-panel="' . $esc($drawerRef) . '" hidden><div class="windows-agent-horizon-drawer-header"><h4>Machine details</h4><button type="button" class="close" data-horizon-drawer-close aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
                $drawerTextClass = $rowSeverity === 'critical' ? 'text-danger' : ($rowSeverity === 'warning' ? 'text-warning' : 'text-success');
                $drawerIcon = $rowSeverity === 'critical' ? 'glyphicon-exclamation-sign' : ($rowSeverity === 'warning' ? 'glyphicon-pause' : 'glyphicon-ok-sign');
                $horizon_details .= '<h3>' . $esc($machine['name'] ?? $machine['id'] ?? 'unknown') . '</h3><p class="' . $drawerTextClass . '"><span class="glyphicon ' . $drawerIcon . '" aria-hidden="true"></span> ' . $esc($humanize_horizon_reason($machine['state'] ?? 'unknown')) . '</p>';
                if ($stuckMessage !== '') {
                    $horizon_details .= '<p class="' . $drawerTextClass . '"><strong>' . $esc($stuckMessage) . '</strong></p>';
                }
                $horizon_details .= '<dl>';
                foreach ([
                    'Pool' => $machine['pool_display_name'] ?? $machine['pool'] ?? '',
                    'Issue' => $reason,
                    'Session' => $sessionLabel,
                    'Maintenance mode' => $maintenance ? 'Yes' : 'No',
                    'Last known state' => $machine['state'] ?? 'unknown',
                    'Collected' => $machine['collected_utc'] ?? 'unknown',
                ] as $label => $value) {
                    $horizon_details .= '<dt>' . $esc($label) . '</dt><dd>' . $esc($value) . '</dd>';
                }
                $capacityRole = match ($placement) {
                    'none' => 'Hosting an active session',
                    'ready' => 'Ready for placement',
                    'occupied' => 'Occupied; unavailable for placement',
                    'pending' => 'Becoming ready',
                    'held' => 'Withheld; unavailable for placement',
                    'faulted' => 'Faulted; unavailable for placement',
                    default => 'Not ready for placement',
                };
                $horizon_details .= '</dl><div class="windows-agent-horizon-drawer-evidence"><h4>Capacity role</h4><p><strong>' . $esc($capacityRole) . '</strong></p><p class="text-muted">' . ($isIssue ? 'This machine needs review in Horizon.' : 'No machine issue is reported in this snapshot.') . '</p></div><div class="windows-agent-horizon-drawer-next"><h4>Next action</h4><p>' . $esc($next) . '</p></div></aside>';
            }
            $horizon_details .= '<div class="windows-agent-horizon-machine-empty" data-machine-empty hidden>No machines match this filter.</div>';
            if ($poolMachines === []) {
                $horizon_details .= '<div class="windows-agent-horizon-machine-empty windows-agent-horizon-machine-empty-static">Per-machine inventory is not available in this snapshot. Aggregate counts remain authoritative.</div>';
            }
            if ((int) ($horizon_api_summary['machine_details_truncated'] ?? 0) === 1) {
                $horizon_details .= '<p class="text-warning windows-agent-horizon-truncation"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Machine detail is truncated; aggregate counts remain authoritative.</p>';
            }
            if ((int) ($horizon_api_summary['machine_issues_truncated'] ?? 0) === 1) {
                $horizon_details .= '<p class="text-warning windows-agent-horizon-truncation"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Issue-machine detail is truncated; aggregate counts remain authoritative.</p>';
            }
            $horizon_details .= '</div></div>';
        }
        $horizon_details .= '</section>';

        $horizon_details .= $render_horizon_range_graph((int) $app_id);

        $horizon_details .= '<div class="row windows-agent-horizon-evidence-row"><section class="col-md-7"><div class="windows-agent-horizon-section"><div class="windows-agent-horizon-section-heading"><h4>Platform health</h4><span class="text-muted">' . $esc($horizon_pod_summary['members_total'] ?? 0) . ' Connection Servers</span></div>';
        $horizon_details .= '<div class="table-responsive"><table class="table table-condensed windows-agent-horizon-platform-table"><thead><tr><th>Connection Server</th><th>State</th><th>Connections</th><th>Evidence</th></tr></thead><tbody>';
        foreach ($issue_first($horizon_pod_members, static fn (array $row): int => (int) ($row['services_unhealthy'] ?? 0) + (int) ($row['configuration_replications_unhealthy'] ?? 0), 'name') as $member) {
            $services = [];
            foreach (is_array($member['unhealthy_services'] ?? null) ? $member['unhealthy_services'] : [] as $service) {
                $services[] = (string) ($service['name'] ?? 'Unknown service') . ' ' . (string) ($service['status'] ?? 'UNKNOWN');
            }
            $evidence = $services !== [] ? implode(', ', $services) : ((int) ($member['configuration_replications_unhealthy'] ?? 0) > 0 ? (string) $member['configuration_replications_unhealthy'] . ' replication issue(s)' : 'No reported issues');
            $memberState = strtolower((string) ($member['health_state'] ?? ''));
            $memberHealthy = $memberState !== ''
                ? in_array($memberState, ['ok', 'info'], true)
                : ($services === [] && (int) ($member['configuration_replications_unhealthy'] ?? 0) === 0 && (int) ($member['certificate_valid'] ?? 1) === 1);
            $memberRef = substr(hash('sha256', strtolower((string) ($member['name'] ?? 'Connection Server'))), 0, 12);
            $horizon_details .= '<tr><td><button type="button" class="windows-agent-horizon-table-target" data-member-drawer="' . $esc($memberRef) . '"><strong>' . $esc($member['name'] ?? 'unknown') . '</strong><span class="sr-only"> details</span></button></td><td>' . ($memberHealthy ? '<span class="text-success">Healthy</span>' : '<span class="text-warning">Attention</span>') . '</td><td>' . $esc($member['connections'] ?? 0) . '</td><td>' . $esc($evidence) . '</td></tr>';
        }
        $gatewaySummary = (int) ($horizon_pod_summary['gateways_total'] ?? 0) === 0
            ? 'No standalone gateways configured'
            : ((int) ($horizon_pod_summary['gateways_total'] ?? 0) - (int) ($horizon_pod_summary['gateways_unhealthy'] ?? 0)) . ' of ' . (int) ($horizon_pod_summary['gateways_total'] ?? 0) . ' healthy';
        $horizon_details .= '</tbody></table></div><div class="windows-agent-horizon-platform-summary"><span>Configuration replication <strong>' . $esc(((int) ($horizon_pod_summary['configuration_replications_total'] ?? 0) - (int) ($horizon_pod_summary['configuration_replications_unhealthy'] ?? 0))) . ' of ' . $esc($horizon_pod_summary['configuration_replications_total'] ?? 0) . ' healthy</strong></span><span>AD domain access <strong>' . $esc(((int) ($horizon_directory_summary['member_links_total'] ?? 0) - (int) ($horizon_directory_summary['member_links_unhealthy'] ?? 0))) . ' of ' . $esc($horizon_directory_summary['member_links_total'] ?? 0) . ' healthy</strong></span><span>Standalone gateways <strong>' . $esc($gatewaySummary) . '</strong></span></div></div></section>';
        $horizon_details .= '<section class="col-md-5"><div class="windows-agent-horizon-section"><div class="windows-agent-horizon-section-heading"><h4>Collector reliability</h4><span class="' . ($horizon_api_stale ? 'text-warning' : 'text-success') . '">' . ($horizon_api_stale ? 'Stale' : 'Fresh') . '</span></div><dl class="windows-agent-horizon-collector">';
        foreach ([
            'Last success' => $horizon_central_meta['last_success_utc'] ?? 'unknown',
            'Duration' => (string) ($horizon_central_meta['collection_duration_ms'] ?? 0) . ' ms',
            'Source endpoint' => $horizon_central_meta['source_endpoint'] ?? 'unknown',
            'Endpoints attempted' => $horizon_central_meta['endpoints_attempted'] ?? 0,
            'Requests' => $horizon_central_meta['requests_total'] ?? 0,
            'Pages' => $horizon_central_meta['pages_total'] ?? 0,
            'Snapshot coverage' => $coverage,
            'Current attempt' => (int) ($horizon_central_meta['inventory_complete'] ?? 0) === 1 ? 'Complete' : 'Incomplete',
            'Truncation' => ((int) ($horizon_api_summary['sessions_truncated'] ?? 0) + (int) ($horizon_api_summary['machines_truncated'] ?? 0) + (int) ($horizon_api_summary['machine_details_truncated'] ?? 0) + (int) ($horizon_api_summary['machine_issues_truncated'] ?? 0) + (int) ($horizon_api_summary['service_details_truncated'] ?? 0)) > 0 ? 'Present' : 'None',
            'Outcome' => $horizon_central_meta['outcome'] ?? ($horizon_api_stale ? 'stale' : 'fresh'),
        ] as $label => $value) {
            $horizon_details .= '<dt>' . $esc($label) . '</dt><dd>' . $esc($value) . '</dd>';
        }
        $horizon_details .= '</dl></div></section></div>';

        $podDetails = '';
        if (! empty($horizon_directory_domains)) {
            $podDetails .= '<h4>Horizon Domain Access</h4>' . $table(['Domain', 'Type', 'Member links', 'Unhealthy links', 'Active service accounts', 'Service-account issues'], $horizon_directory_domains, static function ($row) use ($esc): string {
                return '<td>' . $esc($row['dns_name'] ?? $row['netbios_name'] ?? '') . '</td><td>' . $esc($row['domain_type'] ?? '') . '</td><td>' . $esc($row['member_links_total'] ?? 0) . '</td><td>' . $esc($row['member_links_unhealthy'] ?? 0) . '</td><td>' . $esc($row['service_accounts_active'] ?? 0) . '</td><td>' . $esc($row['service_accounts_unhealthy'] ?? 0) . '</td>';
            });
        }
        if (! empty($horizon_configuration_replications)) {
            $podDetails .= '<h4>Configuration Replication (AD LDS)</h4>' . $table(['Source', 'Target', 'Status'], $horizon_configuration_replications, static function ($row) use ($esc, $state_label): string {
                return '<td>' . $esc($row['source'] ?? '') . '</td><td>' . $esc($row['target'] ?? '') . '</td><td>' . $state_label($row['status'] ?? 'unknown', ['ok']) . '</td>';
            });
        }
        if (! empty($horizon_gateways)) {
            $podDetails .= '<h4>Gateways</h4>' . $table(['Gateway', 'Type', 'Status', 'Version', 'Active connections'], $horizon_gateways, static function ($row) use ($esc, $state_label): string {
                return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['type'] ?? '') . '</td><td>' . $state_label($row['status'] ?? 'unknown', ['ok']) . '</td><td>' . $esc($row['version'] ?? '') . '</td><td>' . $esc($row['active_connections'] ?? 0) . '</td>';
            });
        }
        if (empty($horizon_gateways)) {
            $podDetails .= '<h4>Standalone Gateways</h4><p class="text-muted">No standalone gateways configured. Embedded gateway roles, when enabled, are shown on their Connection Server members.</p>';
        }
        $placement_label = static function (string $placement): string {
            return [
                'ready' => 'Ready for placement',
                'occupied' => 'Unavailable, machine occupied',
                'pending' => 'Becoming ready',
                'held' => 'Withheld intentionally',
                'faulted' => 'Faulted',
                'none' => 'Not placement capacity',
            ][strtolower($placement)] ?? 'Not scored';
        };
        $machineStateDetails = $table(['Pool', 'Clone type', 'Machine state', 'Count', 'Capacity treatment', 'Severity', 'Counts as issue'], $horizon_pool_machine_states, static function ($row) use ($esc, $state_label, $placement_label): string {
            $recognized = (int) ($row['recognized'] ?? 1) === 1;
            $treatment = $recognized
                ? $esc($placement_label((string) ($row['placement'] ?? 'none')))
                : '<span class="text-muted">Unrecognized state, not scored</span>';
            return '<td>' . $esc($row['pool'] ?? '') . '</td><td>' . $esc($row['clone_type'] ?? $row['source'] ?? '') . '</td><td>' . $esc($row['machine_state'] ?? $row['state'] ?? '') . '</td><td>' . $esc($row['count'] ?? $row['machines'] ?? 0) . '</td><td>' . $treatment . '</td><td>' . $state_label($row['severity'] ?? 'incomplete', ['ok', 'info']) . '</td><td>' . $esc((int) ($row['issue'] ?? 0) === 1 ? 'yes' : 'no') . '</td>';
        });
        $connectionServerDetails = $table(['Member', 'Status', 'Type', 'API target', 'Version', 'Connections', 'Unhealthy services', 'Replication issues'], $horizon_pod_members, static function ($row) use ($esc, $state_label): string {
            $services = [];
            foreach (is_array($row['unhealthy_services'] ?? null) ? $row['unhealthy_services'] : [] as $service) {
                $services[] = (string) ($service['name'] ?? 'unknown') . ' (' . (string) ($service['status'] ?? 'UNKNOWN') . ')';
            }
            if ((int) ($row['unhealthy_services_truncated'] ?? 0) === 1) $services[] = 'additional services truncated';

            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $state_label($row['status'] ?? 'unknown', ['ok', 'up', 'running']) . '</td><td>' . $esc(str_replace('_', ' ', (string) ($row['server_type'] ?? ''))) . '</td><td>' . $esc(((int) ($row['local_api_target'] ?? 0) === 1) ? 'Local' : 'Peer') . '</td><td>' . $esc($row['version'] ?? '') . '</td><td>' . $esc($row['connections'] ?? 0) . '</td><td>' . $esc($services === [] ? 'None' : implode(', ', $services)) . '</td><td>' . $esc($row['configuration_replications_unhealthy'] ?? 0) . '</td>';
        });
        $gatewayDetails = $horizon_gateways === []
            ? '<p class="text-muted">No standalone gateways configured. Embedded gateway roles are listed with Connection Servers.</p>'
            : $table(['Gateway', 'Type', 'Status', 'Version', 'Active connections'], $horizon_gateways, static function ($row) use ($esc, $state_label): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['type'] ?? '') . '</td><td>' . $state_label($row['status'] ?? 'unknown', ['ok']) . '</td><td>' . $esc($row['version'] ?? '') . '</td><td>' . $esc($row['active_connections'] ?? 0) . '</td>';
        });
        $rawDetails = $render_horizon_local_diagnostics();
        $horizon_details .= '<div class="windows-agent-horizon-diagnostics">';
        $horizon_details .= $render_disclosure('windows-agent-horizon-connection-servers', 'Connection Servers & services', $connectionServerDetails, count($horizon_pod_members) . ' servers • ' . (int) ($horizon_api_summary['services_unhealthy'] ?? 0) . ' unhealthy services');
        $horizon_details .= $render_disclosure('windows-agent-horizon-pod-details', 'Directory and replication', $podDetails, count($horizon_directory_domains) . ' domains • ' . count($horizon_configuration_replications) . ' replication links');
        $horizon_details .= $render_disclosure('windows-agent-horizon-gateways', 'Gateways', $gatewayDetails, count($horizon_gateways) . ' gateways');
        $horizon_details .= $render_disclosure('windows-agent-horizon-machine-states', 'Machine-state inventory', $machineStateDetails, count($horizon_pool_machine_states) . ' aggregate rows');
        $horizon_details .= $render_disclosure('windows-agent-horizon-raw', 'Raw diagnostics', $rawDetails, count($horizon_services) . ' services • ' . count($horizon_processes) . ' processes • ' . count($horizon_api_session_protocols) . ' protocol rows');
        $horizon_details .= $render_disclosure('windows-agent-horizon-collector-trend', 'Collector performance trend', $render_graph_html('windows-agent_horizon_collector_health'), 'Duration, requests, pages, endpoints, and completeness');
        $horizon_details .= '</div>';
    } else {
        $horizon_details .= '<div class="alert alert-info">Central Horizon API collection is ' . $esc($horizon_api_enabled ? 'unavailable' : 'not configured') . '. Local host evidence remains available on this tab.</div>';
        $rawDetails = $render_horizon_local_diagnostics();
        if ($rawDetails !== '') {
            $horizon_details .= '<div class="windows-agent-horizon-diagnostics">';
            $horizon_details .= $render_disclosure('windows-agent-horizon-raw', 'Raw diagnostics', $rawDetails, count($horizon_services) . ' services • ' . count($horizon_processes) . ' processes');
            $horizon_details .= '</div>';
        }
    }
    $horizon_details .= '<p class="windows-agent-horizon-visibility-note"><span class="glyphicon glyphicon-info-sign" aria-hidden="true"></span> Visibility only — LibreNMS notification rules are not enabled.</p></div>';
}

$factorytalk_details = '';
if ($factorytalk_detected) {
    $factorytalk_status_class = [
        'success' => 'success',
        'warning' => 'warning',
        'danger' => 'danger',
    ][$factorytalk_section_state['class'] ?? ''] ?? 'info';
    $factorytalk_status_text = $factorytalk_health_issue_count === 0
        ? 'No FactoryTalk health issues were reported.'
        : $factorytalk_health_issue_count . ' FactoryTalk health issue(s) were reported.';
    $factorytalk_next_action = $factorytalk_health_issue_count === 0
        ? ''
        : ($factorytalk_reported_next_action !== '' ? $factorytalk_reported_next_action : (string) ($factorytalk_attention[0]['action'] ?? 'Review the service inventory.'));
    if (empty($factorytalk_native_summary) || (int) ($factorytalk_native_summary['available'] ?? 0) !== 1) {
        $native_display_state = 'Unavailable';
    } elseif ((int) ($factorytalk_native_summary['enabled'] ?? 0) !== 1) {
        $native_display_state = 'Disabled';
    } else {
        $native_display_state = $section_state($factorytalk_native_summary['state'] ?? 'unknown')['text'] ?? 'Unknown';
    }
    $native_snapshot_age = (int) ($factorytalk_native_summary['snapshot_age_seconds'] ?? -1);
    $native_snapshot_detail = empty($factorytalk_native_summary)
        ? 'No snapshot data'
        : ($native_snapshot_age >= 0 ? $native_snapshot_age . 's old' : (string) ($factorytalk_native_summary['last_error'] ?? 'No completed snapshot'));
    $transaction_display = $factorytalk_transaction_utilization === null
        ? 'N/A'
        : number_format($factorytalk_transaction_utilization, 1) . '%';

    $factorytalk_details .= '<div class="windows-agent-role-dashboard">';
    $factorytalk_details .= '<div class="windows-agent-role-status windows-agent-role-status-' . $esc($factorytalk_status_class) . '">';
    $factorytalk_details .= '<span class="label label-' . $esc($factorytalk_status_class) . '">' . $esc($factorytalk_section_state['text'] ?? 'Unknown') . '</span> ';
    $factorytalk_details .= '<strong>' . $esc($factorytalk_status_text) . '</strong>';
    if ($factorytalk_next_action !== '') {
        $factorytalk_details .= ' <span class="windows-agent-role-action"><strong>Next:</strong> ' . $esc($factorytalk_next_action) . '</span>';
    }
    $factorytalk_details .= '<span class="text-muted windows-agent-role-collected">Collected ' . $esc($data['last_agent_utc'] ?? 'unknown') . '</span></div>';

    $factorytalk_stats = [
        ['Core services down', $factorytalk_summary['core_services_not_running'] ?? '0', 'Service health'],
        ['Runtime CPU', empty($factorytalk_runtime_summary) ? 'Unavailable' : $format_percent($factorytalk_runtime_summary['cpu_percent'] ?? 0), (string) ($factorytalk_runtime_summary['processes_total'] ?? '0') . ' processes'],
        ['Runtime memory', empty($factorytalk_runtime_summary) ? 'Unavailable' : $format_bytes($factorytalk_runtime_summary['working_set_bytes'] ?? 0), 'Working set'],
        ['Active connections', $factorytalk_active_connections, 'FactoryTalk Linx'],
        ['Transactions', $transaction_display, $factorytalk_transactions_in_use . ' of ' . $factorytalk_transaction_pool_size],
        ['Native snapshot', $native_display_state, $native_snapshot_detail],
    ];
    $factorytalk_details .= '<div class="row windows-agent-role-stats">';
    foreach ($factorytalk_stats as [$label, $value, $detail]) {
        $factorytalk_details .= '<div class="col-sm-4 col-lg-2 windows-agent-role-stat"><div class="text-muted windows-agent-role-stat-label">' . $esc($label) . '</div><div class="windows-agent-role-stat-value">' . $esc($value) . '</div><div class="text-muted windows-agent-role-stat-detail">' . $esc($detail) . '</div></div>';
    }
    $factorytalk_details .= '</div>';

    if (! empty($factorytalk_attention)) {
        $factorytalk_details .= '<div class="windows-agent-role-attention"><h4>Reported Health Issues <small>' . $factorytalk_health_issue_count . '</small></h4><ul>';
        foreach ($factorytalk_attention as $attention) {
            $factorytalk_details .= '<li><strong>' . $esc($attention['title'] ?? 'FactoryTalk health issue') . '</strong> ';
            $factorytalk_details .= '<span class="text-muted">' . $esc($attention['detail'] ?? '') . '</span>';
            $factorytalk_details .= '<div class="text-muted windows-agent-role-attention-action"><strong>Next:</strong> ' . $esc($attention['action'] ?? 'Review the service inventory.') . '</div></li>';
        }
        $factorytalk_details .= '</ul></div>';
    }

    $factorytalk_top_processes = $factorytalk_runtime_processes;
    usort($factorytalk_top_processes, static function (array $left, array $right): int {
        $cpu_order = (float) ($right['cpu_percent'] ?? 0) <=> (float) ($left['cpu_percent'] ?? 0);
        if ($cpu_order !== 0) {
            return $cpu_order;
        }

        return (int) ($right['working_set_bytes'] ?? 0) <=> (int) ($left['working_set_bytes'] ?? 0);
    });
    $factorytalk_top_processes = array_slice($factorytalk_top_processes, 0, 5);
    if (! empty($factorytalk_top_processes)) {
        $factorytalk_details .= '<h4>Top FactoryTalk Processes <small>by CPU, then memory</small></h4>';
        $factorytalk_details .= $table(['Process', 'Role', 'CPU', 'Working set', 'Uptime'], $factorytalk_top_processes, static function ($row) use ($esc, $format_bytes, $format_percent, $format_duration): string {
            return '<td><strong>' . $esc($row['name'] ?? '') . '</strong></td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($format_percent($row['cpu_percent'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['working_set_bytes'] ?? 0)) . '</td><td>' . $esc($format_duration($row['uptime_seconds'] ?? 0)) . '</td>';
        });
    }

    $factorytalk_all_processes = '';
    if (! empty($factorytalk_runtime_processes)) {
        $factorytalk_all_processes = $table(['Process', 'PID', 'Role', 'CPU', 'Working set', 'Private bytes', 'Handles', 'Threads', 'Read/s', 'Write/s', 'Uptime (s)'], $factorytalk_runtime_processes, static function ($row) use ($esc, $format_bytes, $format_percent): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['pid'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($format_percent($row['cpu_percent'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['working_set_bytes'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['private_bytes'] ?? 0)) . '</td><td>' . $esc($row['handle_count'] ?? '0') . '</td><td>' . $esc($row['thread_count'] ?? '0') . '</td><td>' . $esc($format_bytes($row['io_read_bytes_per_sec'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['io_write_bytes_per_sec'] ?? 0)) . '</td><td>' . $esc($row['uptime_seconds'] ?? '0') . '</td>';
        });
        $factorytalk_details .= $render_disclosure('windows-agent-factorytalk-all-processes', 'Show all process metrics', $factorytalk_all_processes, count($factorytalk_runtime_processes) . ' processes');
    }

    $factorytalk_raw_details = '';
    if (! empty($factorytalk_runtime_summary)) {
        $runtime_state = $section_state($factorytalk_runtime_summary['state'] ?? 'unknown');
        $factorytalk_raw_details .= '<h4>FactoryTalk Runtime Metrics</h4><div class="well well-sm">' .
            $runtime_state['html'] . ' ' .
            $metric('Processes', $factorytalk_runtime_summary['processes_total'] ?? '0') . ' ' .
            $metric('CPU', $format_percent($factorytalk_runtime_summary['cpu_percent'] ?? 0)) . ' ' .
            $metric('Working set', $format_bytes($factorytalk_runtime_summary['working_set_bytes'] ?? 0)) . ' ' .
            $metric('Private bytes', $format_bytes($factorytalk_runtime_summary['private_bytes'] ?? 0)) .
            '</div>';
    }
    if ($has_role_details($factorytalk_summary, $factorytalk_products)) {
        $factorytalk_raw_details .= '<h4>Installed Products</h4>' . $table(['Product', 'Version', 'Publisher', 'Role', 'Install location'], $factorytalk_products, static function ($row) use ($esc): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['version'] ?? '') . '</td><td>' . $esc($row['publisher'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($row['install_location'] ?? '') . '</td>';
        });
    }
    if ($has_role_details($factorytalk_summary, $factorytalk_services)) {
        $factorytalk_raw_details .= '<h4>Service Inventory</h4>' . $table(['Service', 'Display', 'Role', 'Core', 'State', 'Start mode', 'Path'], $issue_first($factorytalk_services, static fn (array $row): int => strtolower((string) ($row['state'] ?? '')) === 'running' ? 0 : (1 + ((int) ($row['core'] ?? 0) * 10))), static function ($row) use ($esc, $state_label): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($row['core'] ?? '0') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td>';
        });
    }
    if ($has_role_details($factorytalk_summary, $factorytalk_processes)) {
        $factorytalk_raw_details .= '<h4>Process Inventory</h4>' . $table(['Process', 'PID', 'Role', 'Path'], $factorytalk_processes, static function ($row) use ($esc): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['pid'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td>';
        });
    }
    if ($has_role_details($factorytalk_summary, $factorytalk_ports)) {
        $factorytalk_raw_details .= '<h4>Port Inventory</h4>' . $table(['Name', 'Port', 'Listening', 'Addresses'], $factorytalk_ports, static function ($row) use ($esc, $state_label): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['port'] ?? '') . '</td><td>' . $state_label($row['listening'] ?? '0') . '</td><td>' . $esc($row['addresses'] ?? '') . '</td>';
        });
    }
    if (! empty($factorytalk_native_summary)) {
        $native_state = $section_state($factorytalk_native_summary['state'] ?? 'unknown');
        $factorytalk_raw_details .= '<h4>Native Counter Snapshot</h4><div class="well well-sm">' .
            $native_state['html'] . ' ' .
            $metric('Mode', $factorytalk_native_summary['mode'] ?? 'disabled') . ' ' .
            $metric('Available', $factorytalk_native_summary['available'] ?? '0') . ' ' .
            $metric('Signed', $factorytalk_native_summary['signature_valid'] ?? '0') . ' ' .
            $metric('Version', $factorytalk_native_summary['version'] ?? '') . ' ' .
            $metric('Age (s)', $factorytalk_native_summary['snapshot_age_seconds'] ?? '-1') . ' ' .
            $metric('Duration (ms)', $factorytalk_native_summary['snapshot_duration_ms'] ?? '0') . ' ' .
            $metric('Last result', $factorytalk_native_summary['last_error'] ?? 'none') .
            '</div>';
    }
    if (! empty($factorytalk_linx_connections)) {
        $factorytalk_raw_details .= '<h4>FactoryTalk Linx Connections</h4>' . $table(['Instance', 'Driver', 'Direction', 'Active', 'Accepted', 'Attempted', 'Closed'], $factorytalk_linx_connections, static function ($row) use ($esc): string {
            return '<td>' . $esc($row['instance'] ?? '') . '</td><td>' . $esc($row['driver'] ?? '') . '</td><td>' . $esc($row['direction'] ?? '') . '</td><td>' . $esc($row['active'] ?? '0') . '</td><td>' . $esc($row['accepted'] ?? '0') . '</td><td>' . $esc($row['attempted'] ?? '0') . '</td><td>' . $esc($row['closed'] ?? '0') . '</td>';
        });
    }
    if (! empty($factorytalk_linx_backplane)) {
        $factorytalk_raw_details .= '<h4>FactoryTalk Linx Backplane</h4>' . $table(['Instance', 'Slot', 'Packets received', 'Packets sent', 'Send failures'], $factorytalk_linx_backplane, static function ($row) use ($esc): string {
            return '<td>' . $esc($row['instance'] ?? '') . '</td><td>' . $esc($row['slot'] ?? '') . '</td><td>' . $esc($row['packets_received'] ?? '0') . '</td><td>' . $esc($row['packets_sent'] ?? '0') . '</td><td>' . $esc($row['send_failures'] ?? '0') . '</td>';
        });
    }
    if (! empty($factorytalk_linx_transactions)) {
        $factorytalk_raw_details .= '<h4>FactoryTalk Linx Transactions</h4>' . $table(['Instance', 'In use', 'Pool size', 'Utilization'], $factorytalk_linx_transactions, static function ($row) use ($esc): string {
            $pool_size = (int) ($row['pool_size'] ?? 0);
            $in_use = (int) ($row['in_use'] ?? 0);
            $utilization = $pool_size > 0 ? number_format(($in_use / $pool_size) * 100, 1) . '%' : 'N/A';
            return '<td>' . $esc($row['instance'] ?? '') . '</td><td>' . $esc($in_use) . '</td><td>' . $esc($pool_size) . '</td><td>' . $esc($utilization) . '</td>';
        });
    }
    if (! empty($factorytalk_livedata)) {
        $factorytalk_raw_details .= '<h4>FactoryTalk Live Data</h4><div class="well well-sm">' . $metric('Clients', $factorytalk_livedata['clients'] ?? '0') . ' ' . $metric('Sources', $factorytalk_livedata['sources'] ?? '0') . '</div>';
    }
    $factorytalk_details .= $render_disclosure('windows-agent-factorytalk-raw', 'Inventory and raw diagnostics', $factorytalk_raw_details, (string) count($factorytalk_products) . ' products, ' . count($factorytalk_services) . ' services');
    $factorytalk_details .= '</div>';
}

$tls_details = '';
if ($has_role_details($tls_certificates_summary, $tls_certificates)) {
    $tls_details = $table(['Store', 'Subject', 'Health', 'DNS names', 'Expires UTC', 'Days', 'Chain', 'Key', 'Bound'], $issue_first($tls_certificates, static fn (array $row): int => ((strtolower((string) ($row['health'] ?? '')) === 'ok' ? 0 : 10000) + ((int) ($row['expired'] ?? 0) * 5000) + ((int) ($row['expiring_critical'] ?? 0) * 1000) + ((int) ($row['expiring_warning'] ?? 0) * 500) + max(0, 3650 - (int) ($row['days_remaining'] ?? 3650))), 'subject'), static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['store'] ?? '') . '</td><td>' . $esc($row['subject'] ?? '') . '</td><td>' . $state_label($row['health'] ?? 'unknown', ['ok']) . '</td><td>' . $esc($row['dns_names'] ?? '') . '</td><td>' . $esc($row['not_after_utc'] ?? '') . '</td><td>' . $esc($row['days_remaining'] ?? '') . '</td><td>' . $esc($row['chain_status'] ?? '') . '</td><td>' . $esc($row['key_bits'] ?? '') . ' bits / private=' . $esc($row['has_private_key'] ?? '0') . '</td><td>' . $esc($row['bound'] ?? '0') . ' ' . $esc($row['binding_sources'] ?? '') . '</td>';
    });
} elseif ($tls_summary_state === 'ok' && $tls_certificate_count === 0) {
    $tls_details = $kv_table([
        'State' => $sections['tls']['state']['html'],
        'Stores scanned' => $esc($tls_certificates_summary['store_count'] ?? '0'),
        'Certificates found' => $esc($tls_certificates_summary['certificate_count'] ?? '0'),
        'Result' => 'No LocalMachine certificates found in configured stores.',
    ]);
}

$backup_details = '';
if ($has_role_details($backup_storage_summary, $vss_writers)) {
    $backup_details .= $table(['Writer', 'State', 'Last error'], $issue_first($vss_writers, static fn (array $row): int => strtolower((string) ($row['state'] ?? '')) === 'stable' ? 0 : 1), static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown', ['stable']) . '</td><td>' . $esc($row['last_error'] ?? '') . '</td>';
    });
}
if ($has_role_details($backup_storage_summary, $backup_services)) {
    $backup_details .= $table(['Service', 'Display', 'State', 'Start mode', 'Source'], $issue_first($backup_services, static fn (array $row): int => strtolower((string) ($row['state'] ?? '')) === 'running' ? 0 : 1), static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
    });
}

$datto_details = '';
$datto_service_score = static function (array $row): int {
    $role = strtolower((string) ($row['role'] ?? ''));
    $state = strtolower((string) ($row['state'] ?? ''));
    $state_issue = $role === 'provider' ? 0 : ($state === 'running' ? 0 : 1);
    $path_issue = (int) ($row['path_exists'] ?? 0) === 1 ? 0 : 1;

    return $state_issue + $path_issue;
};
if ($has_role_details($datto_backup_summary, $datto_backup_services)) {
    $datto_details .= $table(['Service', 'Role', 'State', 'Start mode', 'Path exists', 'Version'], $issue_first($datto_backup_services, $datto_service_score), static function ($row) use ($esc, $state_label): string {
        $healthy_states = strtolower((string) ($row['role'] ?? '')) === 'provider' ? ['running', 'stopped'] : ['running'];
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown', $healthy_states) . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['path_exists'] ?? '0') . '</td><td>' . $esc($row['version'] ?? '') . '</td>';
    });
}
if ($has_role_details($datto_backup_summary, $datto_backup_processes)) {
    $datto_details .= $table(['Process', 'Matched count'], $datto_backup_processes, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['matched_count'] ?? '0') . '</td>';
    });
}
if ($has_role_details($datto_backup_summary, $datto_backup_evidence)) {
    $datto_details .= $table(['Type', 'State', 'Source', 'Timestamp UTC', 'Age', 'Recent errors', 'Critical failures'], $issue_first($datto_backup_evidence, static fn (array $row): int => (strtolower((string) ($row['state'] ?? '')) === 'critical' ? 10000 : (strtolower((string) ($row['state'] ?? '')) === 'warning' ? 5000 : 0)) + ((int) ($row['recent_critical_failures'] ?? 0) * 100) + (int) ($row['recent_errors'] ?? 0), 'type'), static function ($row) use ($esc): string {
        return '<td>' . $esc($row['type'] ?? '') . '</td><td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td><td>' . $esc($row['timestamp_utc'] ?? '') . '</td><td>' . $esc($row['age_hours'] ?? '') . '</td><td>' . $esc($row['recent_errors'] ?? '') . '</td><td>' . $esc($row['recent_critical_failures'] ?? '') . '</td>';
    });
}

$role_details = $table(['Role', 'Detected', 'Confidence', 'Source'], $roles, static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['role'] ?? '') . '</td><td>' . $state_label($row['detected'] ?? '0') . '</td><td>' . $esc($row['confidence'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
});
$ad_details = $kv_table([
    'Domain' => $esc($ad_summary['domain'] ?? ''),
    'Domain role' => $esc($ad_summary['domain_role_name'] ?? '') . ' (' . $esc($ad_summary['domain_role'] ?? '') . ')',
    'Replication state' => $esc($ad_summary['replication_state'] ?? ''),
    'Replication failures' => $esc($ad_summary['replication_failures'] ?? '0'),
    'DFSR state' => $esc($ad_summary['dfsr_state'] ?? ''),
    'DFSR unhealthy' => $esc($ad_summary['dfsr_unhealthy'] ?? '0'),
    'FSMO state' => $esc($ad_summary['fsmo_state'] ?? ''),
]);
$ad_dc_details = $kv_table([
    'Core services down' => $esc($ad_dc_health_summary['core_services_not_running'] ?? '0'),
    'DNS service running' => $esc($ad_dc_health_summary['dns_service_running'] ?? '0'),
    'SYSVOL / NETLOGON published' => $esc($ad_dc_health_summary['sysvol_share_present'] ?? '0') . ' / ' . $esc($ad_dc_health_summary['netlogon_share_present'] ?? '0'),
    'Time state' => $esc($ad_dc_health_summary['time_state'] ?? ''),
    'Health issues' => $esc($ad_dc_health_summary['health_issues'] ?? '0'),
]);
if ($has_role_details($ad_dc_health_summary, $ad_dc_dns)) {
    $ad_dc_details .= $table(['DNS state', 'Present', 'Running', 'Reason'], $ad_dc_dns, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['service_present'] ?? '0') . '</td><td>' . $esc($row['service_running'] ?? '0') . '</td><td>' . $esc($row['reason'] ?? '') . '</td>';
    });
}
if ($has_role_details($ad_dc_health_summary, $ad_dc_services)) {
    $ad_dc_details .= $table(['Name', 'Role', 'Core', 'Present', 'State', 'Start mode', 'Display'], $issue_first($ad_dc_services, static fn (array $row): int => strtolower((string) ($row['state'] ?? '')) === 'running' ? 0 : (1 + ((int) ($row['core'] ?? 0) * 10))), static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($row['core'] ?? '0') . '</td><td>' . $esc($row['present'] ?? '0') . '</td><td>' . $state_label($row['state'] ?? 'unknown', ['running']) . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td>';
    });
}
if ($has_role_details($ad_dc_health_summary, $ad_dc_shares)) {
    $ad_dc_details .= $table(['Share', 'Present', 'Path'], $issue_first($ad_dc_shares, static fn (array $row): int => (int) ($row['present'] ?? 0) === 1 ? 0 : 1), static function ($row) use ($esc): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['present'] ?? '0') . '</td><td>' . $esc($row['path'] ?? '') . '</td>';
    });
}
if ($has_role_details($ad_dc_health_summary, $ad_dc_time)) {
    $ad_dc_details .= $table(['State', 'Source', 'Stratum', 'Leap', 'Last sync', 'Reason'], $ad_dc_time, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td><td>' . $esc($row['stratum'] ?? '') . '</td><td>' . $esc($row['leap_indicator'] ?? '') . '</td><td>' . $esc($row['last_successful_sync_time'] ?? '') . '</td><td>' . $esc($row['reason'] ?? '') . '</td>';
    });
}
if ($has_role_details($ad_dc_health_summary, $ad_dc_security_events)) {
    $ad_dc_details .= $table(['Security category', 'Count', 'Event IDs', 'Window', 'State', 'Source'], $issue_first($ad_dc_security_events, static fn (array $row): int => (int) ($row['count'] ?? 0), 'category'), static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['category'] ?? '') . '</td><td>' . $esc($row['count'] ?? '0') . '</td><td>' . $esc($row['event_ids'] ?? '') . '</td><td>' . $esc($row['since_hours'] ?? '') . 'h</td><td>' . $state_label($row['state'] ?? 'inventory', ['inventory', 'ok']) . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
    });
}
$ad_replication_details = $table(['State', 'Source', 'Target', 'Naming context', 'Failures', 'Last success', 'Last failure', 'Status'], $issue_first($ad_replication, static fn (array $row): int => (strtolower((string) ($row['state'] ?? '')) === 'ok' ? 0 : 1000) + (int) ($row['failure_count'] ?? $row['failures'] ?? 0), 'target'), static function ($row) use ($esc): string {
    return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td><td>' . $esc($row['target'] ?? '') . '</td><td>' . $esc($row['naming_context'] ?? '') . '</td><td>' . $esc($row['failure_count'] ?? '0') . '</td><td>' . $esc($row['last_success'] ?? '') . '</td><td>' . $esc($row['last_failure'] ?? '') . '</td><td>' . $esc($row['last_failure_status'] ?? ($row['reason'] ?? '')) . '</td>';
});
$dfsr_details = $table(['State', 'Replication group', 'Folder', 'Member', 'Source', 'Reason'], $issue_first($ad_dfsr, static fn (array $row): int => strtolower((string) ($row['state'] ?? '')) === 'ok' ? 0 : 1, 'replication_group'), static function ($row) use ($esc): string {
    return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['replication_group'] ?? '') . '</td><td>' . $esc($row['replicated_folder'] ?? '') . '</td><td>' . $esc($row['member'] ?? '') . '</td><td>' . $esc($row['source'] ?? ($row['tool'] ?? '')) . '</td><td>' . $esc($row['reason'] ?? '') . '</td>';
});
$fsmo_details = $table(['State', 'Role', 'Owner', 'Reason'], $issue_first($ad_fsmo, static fn (array $row): int => strtolower((string) ($row['state'] ?? '')) === 'ok' ? 0 : 1, 'role'), static function ($row) use ($esc): string {
    return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($row['owner'] ?? '') . '</td><td>' . $esc($row['reason'] ?? '') . '</td>';
});

$ad_dc_detected = (int) ($ad_dc_health_summary['dc_detected'] ?? 0) === 1;
$ad_reported_next_action = trim((string) ($ad_dc_health_summary['next_action'] ?? ''));
$ad_core_services_total = (int) ($ad_dc_health_summary['core_services_total'] ?? 0);
$ad_core_services_down = (int) ($ad_dc_health_summary['core_services_not_running'] ?? 0);
$ad_shares_missing = (int) ($ad_dc_health_summary['shares_missing'] ?? 0);
$ad_replication_failures = (int) ($ad_summary['replication_failures'] ?? 0);

$dfsr_has_issue = false;
foreach ($ad_dfsr as $dfsr_row) {
    if (strtolower((string) ($dfsr_row['state'] ?? '')) !== 'ok') {
        $dfsr_has_issue = true;
        break;
    }
}

$ad_attention = [];
foreach ($ad_dc_services as $service) {
    if ((int) ($service['core'] ?? 0) !== 1 || strtolower((string) ($service['state'] ?? '')) === 'running') {
        continue;
    }

    $ad_attention[] = [
        'title' => 'Core domain-controller service is not running: ' . (string) ($service['display'] ?? $service['name'] ?? 'unknown'),
        'detail' => 'Current state: ' . (string) ($service['state'] ?? 'unknown') . '; startup: ' . (string) ($service['start_mode'] ?? 'unknown'),
        'action' => $ad_reported_next_action !== '' ? $ad_reported_next_action : 'Check the service and its Active Directory dependencies.',
    ];
}
foreach ($ad_dc_shares as $share) {
    if ((int) ($share['present'] ?? 0) === 1) {
        continue;
    }

    $ad_attention[] = [
        'title' => 'Published share is missing: ' . (string) ($share['name'] ?? 'unknown'),
        'detail' => 'Expected path: ' . (string) ($share['path'] ?? 'unknown'),
        'action' => 'Confirm SYSVOL and NETLOGON are published on this domain controller.',
    ];
}
foreach ($ad_replication as $replication_row) {
    if (strtolower((string) ($replication_row['state'] ?? '')) === 'ok') {
        continue;
    }

    $ad_attention[] = [
        'title' => 'Replication is unhealthy for target: ' . (string) ($replication_row['target'] ?? 'unknown'),
        'detail' => 'Failures: ' . (string) ($replication_row['failure_count'] ?? '0') . '; last failure: ' . (string) ($replication_row['last_failure_status'] ?? ($replication_row['reason'] ?? 'unknown')),
        'action' => 'Review Active Directory replication for this partner.',
    ];
}
foreach ($ad_fsmo as $fsmo_row) {
    if (strtolower((string) ($fsmo_row['state'] ?? '')) === 'ok') {
        continue;
    }

    $ad_attention[] = [
        'title' => 'FSMO role is unhealthy: ' . (string) ($fsmo_row['role'] ?? 'unknown'),
        'detail' => 'Owner: ' . (string) ($fsmo_row['owner'] ?? 'unknown') . '; reason: ' . (string) ($fsmo_row['reason'] ?? 'unknown'),
        'action' => 'Confirm the reported FSMO role owner is reachable.',
    ];
}

$ad_health_issue_count = max(
    (int) ($ad_dc_health_summary['health_issues'] ?? 0),
    $ad_core_services_down,
    $ad_shares_missing,
    count($ad_attention)
);

$ad_dashboard = '';
if ($ad_dc_detected) {
    $ad_status_class = [
        'success' => 'success',
        'warning' => 'warning',
        'danger' => 'danger',
    ][$sections['ad_dc']['state']['class'] ?? ''] ?? 'info';
    $ad_status_text = $ad_health_issue_count === 0
        ? 'No domain-controller health issues were reported.'
        : $ad_health_issue_count . ' domain-controller health issue(s) were reported.';
    $ad_next_action = $ad_health_issue_count === 0
        ? ''
        : ($ad_reported_next_action !== '' ? $ad_reported_next_action : (string) ($ad_attention[0]['action'] ?? 'Review the domain-controller evidence below.'));

    $ad_dashboard .= '<div class="windows-agent-role-dashboard">';
    $ad_dashboard .= '<div class="windows-agent-role-status windows-agent-role-status-' . $esc($ad_status_class) . '">';
    $ad_dashboard .= '<span class="label label-' . $esc($ad_status_class) . '">' . $esc($sections['ad_dc']['state']['text'] ?? 'Unknown') . '</span> ';
    $ad_dashboard .= '<strong>' . $esc($ad_status_text) . '</strong>';
    if ($ad_next_action !== '') {
        $ad_dashboard .= ' <span class="windows-agent-role-action"><strong>Next:</strong> ' . $esc($ad_next_action) . '</span>';
    }
    $ad_dashboard .= '<span class="text-muted windows-agent-role-collected">Collected ' . $esc($data['last_agent_utc'] ?? 'unknown') . '</span></div>';

    $ad_stats = [
        ['Health issues', $ad_health_issue_count, 'Local domain-controller evidence'],
        ['Core services down', $ad_core_services_down, $ad_core_services_total . ' expected'],
        ['SYSVOL / NETLOGON', ((int) ($ad_dc_health_summary['sysvol_share_present'] ?? 0) === 1 ? 'Published' : 'Missing') . ' / ' . ((int) ($ad_dc_health_summary['netlogon_share_present'] ?? 0) === 1 ? 'Published' : 'Missing'), $ad_shares_missing . ' missing'],
        ['Replication failures', $ad_replication_failures, 'State: ' . (string) ($ad_summary['replication_state'] ?? 'unknown')],
        ['FSMO', (string) ($ad_summary['fsmo_state'] ?? 'unknown'), count($ad_fsmo) . ' role(s) reported'],
        ['Time sync', (string) ($ad_dc_health_summary['time_state'] ?? 'unknown'), (int) ($ad_dc_health_summary['time_service_running'] ?? 0) === 1 ? 'Service running' : 'Service not running'],
    ];
    $ad_dashboard .= '<div class="row windows-agent-role-stats">';
    foreach ($ad_stats as [$ad_stat_label, $ad_stat_value, $ad_stat_detail]) {
        $ad_dashboard .= '<div class="col-sm-4 col-lg-2 windows-agent-role-stat"><div class="text-muted windows-agent-role-stat-label">' . $esc($ad_stat_label) . '</div><div class="windows-agent-role-stat-value">' . $esc($ad_stat_value) . '</div><div class="text-muted windows-agent-role-stat-detail">' . $esc($ad_stat_detail) . '</div></div>';
    }
    $ad_dashboard .= '</div>';

    if (! empty($ad_attention)) {
        $ad_dashboard .= '<div class="windows-agent-role-attention"><h4>Reported Health Issues <small>' . $ad_health_issue_count . '</small></h4><ul>';
        foreach ($ad_attention as $attention) {
            $ad_dashboard .= '<li><strong>' . $esc($attention['title'] ?? 'Active Directory health issue') . '</strong> ';
            $ad_dashboard .= '<span class="text-muted">' . $esc($attention['detail'] ?? '') . '</span>';
            $ad_dashboard .= '<div class="text-muted windows-agent-role-attention-action"><strong>Next:</strong> ' . $esc($attention['action'] ?? 'Review the domain-controller evidence below.') . '</div></li>';
        }
        $ad_dashboard .= '</ul></div>';
    }
    $ad_dashboard .= '</div>';
}
$users_details = $table(['User', 'Domain', 'Session', 'ID', 'State', 'Idle time', 'Logon time', 'Current', 'Source'], $logged_on_user_sessions, static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['user'] ?? '') . '</td><td>' . $esc($row['domain'] ?? '') . '</td><td>' . $esc($row['session_name'] ?? '') . '</td><td>' . $esc($row['session_id'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown', ['active']) . '</td><td>' . $esc($row['idle_time'] ?? '') . '</td><td>' . $esc($row['logon_time'] ?? '') . '</td><td>' . $esc($row['current'] ?? '0') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
});

$reboot_details = $kv_table([
    'Pending reboot' => $state_label($pending_reboot['pending'] ?? '0', ['0']) . ' ' . $esc($pending_reboot['sources'] ?? ''),
    'Windows Update reboot required' => $state_label($windows_update['reboot_required'] ?? '0', ['0']),
    'Windows Update service' => $esc($windows_update['service_state'] ?? 'unknown') . ' / ' . $esc($windows_update['start_mode'] ?? 'unknown'),
]);
$service_details = '';
if (empty($classified_service_groups)) {
    $service_details .= $table(['Name', 'Display name', 'State'], $issue_first($watched_services, static fn (array $row): int => strtolower((string) ($row['state'] ?? '')) === 'running' ? 0 : 1), static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td>';
    });
} else {
    foreach ($classified_service_groups as $group_key => $services_in_group) {
        if (empty($services_in_group)) {
            continue;
        }

        $summary = $service_group_summaries[$group_key] ?? [];
        $service_details .= '<h4>' . $esc($group_key) . ' <small>Total ' . $esc($summary['total'] ?? count($services_in_group)) . ', not running ' . $esc($summary['not_running'] ?? '0') . '</small></h4>';
        $service_details .= $table(['Name', 'Display name', 'State', 'Start mode', 'Account', 'Path', 'Source'], $services_in_group, static function ($row) use ($esc, $state_label): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['account'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
        });
    }
}
if (! empty($excluded_services)) {
    $service_details .= '<h4>Excluded / Low Value Services</h4>';
    $service_details .= $table(['Name', 'Display name', 'State', 'Start mode', 'Account', 'Path', 'Source'], $excluded_services, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['account'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
    });
}
$event_details = $table(['Log', 'Scanned', 'Critical', 'Error', 'Warning', 'Latest critical/error UTC'], $issue_first($event_logs, static fn (array $row): int => ((int) ($row['critical_count'] ?? 0) * 1000) + ((int) ($row['error_count'] ?? 0) * 100) + (int) ($row['warning_count'] ?? 0), 'log'), static function ($row) use ($esc): string {
    return '<td>' . $esc($row['log'] ?? '') . '</td><td>' . $esc($row['scanned_events'] ?? '0') . '</td><td>' . $esc($row['critical_count'] ?? '0') . '</td><td>' . $esc($row['error_count'] ?? '0') . '</td><td>' . $esc($row['warning_count'] ?? '0') . '</td><td>' . $esc($row['latest_critical_or_error_utc'] ?? '') . '</td>';
});
if (! empty($event_log_high_value)) {
    $event_details .= '<h4>High-value Event Samples <small>groups ' . $esc($event_log_high_value_summary['signatures_total'] ?? count($event_log_high_value)) . ', events ' . $esc($event_log_high_value_summary['events_total'] ?? '0') . ', samples ' . $esc($event_log_high_value_summary['samples_total'] ?? count($event_log_high_value)) . ', truncated ' . $esc($event_log_high_value_summary['truncated'] ?? '0') . '</small></h4>';
    $event_details .= $table(['Log', 'Provider', 'Event ID', 'Level', 'Count', 'Last seen UTC', 'Sample UTC', 'Message excerpt'], $issue_first($event_log_high_value, static fn (array $row): int => ((int) ($row['level_code'] ?? 9) === 1 ? 10000 : 0) + ((int) ($row['level_code'] ?? 9) === 2 ? 5000 : 0) + (int) ($row['count'] ?? 0), 'provider'), static function ($row) use ($esc): string {
        return '<td>' . $esc($row['log'] ?? '') . '</td><td>' . $esc($row['provider'] ?? '') . '</td><td>' . $esc($row['event_id'] ?? '') . '</td><td>' . $esc($row['level'] ?? '') . '</td><td>' . $esc($row['count'] ?? '0') . '</td><td>' . $esc($row['last_seen_utc'] ?? '') . '</td><td>' . $esc($row['sample_time_utc'] ?? '') . '</td><td>' . $esc($row['message_excerpt'] ?? '') . '</td>';
    });
}
$process_details = $table(['Name', 'Matched', 'Working set', 'Private bytes', 'CPU seconds'], $issue_first($watched_processes, static fn (array $row): int => (int) ($row['matched_count'] ?? 0) === 0 ? 1 : 0), static function ($row) use ($esc, $format_bytes): string {
    return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['matched_count'] ?? '0') . '</td><td>' . $esc($format_bytes($row['working_set_bytes'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['private_bytes'] ?? 0)) . '</td><td>' . $esc($row['processor_seconds'] ?? '0') . '</td>';
});
$tcp_details = $table(['Name', 'Address', 'Port', 'Listening'], $issue_first($watched_tcp_ports, static fn (array $row): int => (int) ($row['listening'] ?? 0) === 1 ? 0 : 1), static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['address'] ?? '*') . '</td><td>' . $esc($row['port'] ?? '') . '</td><td>' . $state_label($row['listening'] ?? '0') . '</td>';
});

$performance_tab = '';
$performance_tab .= $render_section_summary('collector-impact', 'Collector Resource Impact', $sections['collector_impact']['state'], $sections['collector_impact']['summary'], $agent_resource_details, $agent_resource_known ? [
    ['label' => 'Collector CPU Impact', 'key' => 'windows-agent_agent_resource_cpu'],
    ['label' => 'Collector Memory Footprint', 'key' => 'windows-agent_agent_resource_memory'],
    ['label' => 'Collector Disk I/O', 'key' => 'windows-agent_agent_resource_io'],
] : []);
$performance_tab .= $render_section_summary('agent-performance', 'Agent Performance', $sections['agent']['state'], $sections['agent']['summary'], $agent_perf_details, [
    ['label' => 'Collection Duration', 'key' => 'windows-agent_agent_collection_duration'],
    ['label' => 'Payload Size', 'key' => 'windows-agent_agent_payload_size'],
    ['label' => 'Collector Issues', 'key' => 'windows-agent_agent_collector_issues'],
]);
$performance_tab .= $render_section_summary('vm-resources', 'VM Resources', $sections['vm']['state'], $sections['vm']['summary'], $vm_details, [
    ['label' => 'VM Resource Utilization', 'key' => 'windows-agent_vm_resources'],
]);
$performance_tab .= $render_section_summary('performance-depth', 'Windows Performance Depth', $sections['performance']['state'], $sections['performance']['summary'], $perf_details, [
    ['label' => 'CPU Queue', 'key' => 'windows-agent_perf_cpu_queue'],
    ['label' => 'Memory Committed', 'key' => 'windows-agent_perf_memory_committed'],
    ['label' => 'Paging Rate', 'key' => 'windows-agent_perf_paging'],
    ['label' => 'Disk Latency', 'key' => 'windows-agent_perf_disk_latency'],
    ['label' => 'Disk Queue', 'key' => 'windows-agent_perf_disk_queue'],
    ['label' => 'Pressure Issues', 'key' => 'windows-agent_perf_pressure_issues'],
]);

$render_graph_list = static function (array $graphs, string $id_prefix) use ($esc, $render_graph_html, $render_disclosure): string {
    $primary = '';
    $secondary = '';
    foreach ($graphs as $graph) {
        $graph_key = $graph['key'] ?? '';
        if ($graph_key === '') {
            continue;
        }

        $graph_html = '<div class="windows-agent-graph-view"><h4>' . $esc($graph['label'] ?? 'Graph') . '</h4>' . $render_graph_html($graph_key) . '</div>';
        if ((bool) ($graph['secondary'] ?? false)) {
            $secondary .= $graph_html;
        } else {
            $primary .= $graph_html;
        }
    }

    if ($secondary !== '') {
        $primary .= $render_disclosure($id_prefix . '-additional-graphs', 'Additional graphs', $secondary);
    }

    return $primary;
};

$horizon_graphs = [
    ['label' => 'Horizon State and Issues', 'key' => 'windows-agent_horizon_state_health'],
    ['label' => 'Horizon Listeners and Certificates', 'key' => 'windows-agent_horizon_edges'],
];
if ($horizon_runtime_available) {
    $horizon_graphs[] = ['label' => 'Horizon Runtime CPU', 'key' => 'windows-agent_horizon_runtime_cpu'];
    $horizon_graphs[] = ['label' => 'Horizon Runtime Memory', 'key' => 'windows-agent_horizon_runtime_memory'];
    $horizon_graphs[] = ['label' => 'Horizon Runtime Processes', 'key' => 'windows-agent_horizon_runtime_processes', 'secondary' => true];
    $horizon_graphs[] = ['label' => 'Horizon Runtime I/O', 'key' => 'windows-agent_horizon_runtime_io', 'secondary' => true];
}
if ($horizon_api_available) {
    $horizon_graphs[] = ['label' => 'Horizon Health Contract', 'key' => 'windows-agent_horizon_health_contract'];
    $horizon_graphs[] = ['label' => 'Horizon API Health', 'key' => 'windows-agent_horizon_api_health'];
    $horizon_graphs[] = ['label' => 'Horizon API Sessions', 'key' => 'windows-agent_horizon_api_sessions'];
    $horizon_graphs[] = ['label' => 'Horizon Pod Health', 'key' => 'windows-agent_horizon_pod_health'];
    $horizon_graphs[] = ['label' => 'Horizon Clone Pool Health', 'key' => 'windows-agent_horizon_pool_health'];
}
$factorytalk_graphs = [
    ['label' => 'FactoryTalk State and Issues', 'key' => 'windows-agent_factorytalk_state_health'],
];
if (! empty($factorytalk_runtime_summary) && ! in_array(strtolower((string) ($factorytalk_runtime_summary['state'] ?? '')), ['disabled', 'not_detected', 'unsupported'], true)) {
    $factorytalk_graphs[] = ['label' => 'FactoryTalk Runtime CPU', 'key' => 'windows-agent_factorytalk_runtime_cpu'];
    $factorytalk_graphs[] = ['label' => 'FactoryTalk Runtime Memory', 'key' => 'windows-agent_factorytalk_runtime_memory'];
    $factorytalk_graphs[] = ['label' => 'FactoryTalk Runtime Processes', 'key' => 'windows-agent_factorytalk_runtime_processes', 'secondary' => true];
    $factorytalk_graphs[] = ['label' => 'FactoryTalk Runtime I/O', 'key' => 'windows-agent_factorytalk_runtime_io', 'secondary' => true];
}
if (! empty($factorytalk_linx_connections) || ! empty($factorytalk_linx_backplane) || ! empty($factorytalk_linx_transactions) || ! empty($factorytalk_livedata)) {
    $factorytalk_graphs[] = ['label' => 'FactoryTalk Linx Active Connections', 'key' => 'windows-agent_factorytalk_linx_connections_active'];
    $factorytalk_graphs[] = ['label' => 'FactoryTalk Linx Connection Churn', 'key' => 'windows-agent_factorytalk_linx_connections_churn', 'secondary' => true];
    $factorytalk_graphs[] = ['label' => 'FactoryTalk Linx Backplane Traffic', 'key' => 'windows-agent_factorytalk_linx_traffic'];
    $factorytalk_graphs[] = ['label' => 'FactoryTalk Linx Transactions', 'key' => 'windows-agent_factorytalk_linx_transactions', 'secondary' => true];
    $factorytalk_graphs[] = ['label' => 'FactoryTalk Live Data Clients', 'key' => 'windows-agent_factorytalk_livedata_clients', 'secondary' => true];
}
$dfsr_section = $render_section_summary('dfsr', 'DFSR Replication Health', $section_state(empty($ad_dfsr) ? 'not_applicable' : 'ok'), $metric('Rows', count($ad_dfsr)), $dfsr_details);

$active_directory_tab = '';
if ($ad_dc_detected) {
    $active_directory_tab .= $ad_dashboard;
    $active_directory_tab .= $render_section_summary('ad', 'Active Directory Summary', $section_state($ad_summary['state'] ?? 'not_applicable'), $metric('Domain', $ad_summary['domain'] ?? '') . ' ' . $metric('Failures', $ad_summary['replication_failures'] ?? '0'), $ad_details);
    $active_directory_tab .= $render_section_summary('ad-dc', 'AD/DC Local Health', $sections['ad_dc']['state'], $sections['ad_dc']['summary'], $ad_dc_details);
    $active_directory_tab .= $render_section_summary('ad-replication', 'AD Replication Targets', $section_state(empty($ad_replication) ? 'not_applicable' : 'ok'), $metric('Targets', count($ad_replication)), $ad_replication_details);
    $active_directory_tab .= $render_section_summary('fsmo', 'FSMO Roles', $section_state(empty($ad_fsmo) ? 'not_applicable' : 'ok'), $metric('Roles', count($ad_fsmo)), $fsmo_details);
    $active_directory_tab .= $dfsr_section;
    $active_directory_tab .= $render_disclosure('windows-agent-active-directory-trends', 'Trends', $render_graph_list([
        ['label' => 'AD/DC Local Health Issues', 'key' => 'windows-agent_ad_dc_health'],
    ], 'windows-agent-active-directory'), 'Local domain-controller health issues');
    if (trim($active_directory_tab) === '') {
        $active_directory_tab = '<div class="alert alert-info">A domain controller was detected, but the agent reported no Active Directory detail.</div>';
    }
}

$factorytalk_tab = '';
if ($factorytalk_detected) {
    $factorytalk_tab .= $factorytalk_details;
    $factorytalk_tab .= $render_disclosure('windows-agent-factorytalk-trends', 'Trends', $render_graph_list($factorytalk_graphs, 'windows-agent-factorytalk'), count($factorytalk_graphs) . ' graph(s)');
    if (trim($factorytalk_tab) === '') {
        $factorytalk_tab = '<div class="alert alert-info">FactoryTalk was detected, but the agent reported no FactoryTalk detail.</div>';
    }
}

$horizon_tab = '';
if ($horizon_surface_available) {
    $horizon_tab .= $horizon_details;
    $horizon_tab .= $render_disclosure('windows-agent-horizon-trends', 'Trends', $render_graph_list($horizon_graphs, 'windows-agent-horizon'), count($horizon_graphs) . ' graph(s)');
    if (trim($horizon_tab) === '') {
        $horizon_tab = '<div class="alert alert-info">Horizon was detected, but the agent reported no Horizon detail.</div>';
    }
}

$sql_tab = $sql_promoted ? require __DIR__ . '/windows-agent/sql-server-tab.inc.php' : '';

// A promoted role owns its state and attention. Generic inventory keeps a pointer.
$iis_detected = ! in_array(strtolower((string) ($iis_summary['state'] ?? 'not_detected')), ['not_detected', 'disabled', 'unsupported', 'not_applicable'], true);
$iis_stopped = (int) ($iis_summary['sites_stopped'] ?? 0) + (int) ($iis_summary['app_pools_stopped'] ?? 0);
$roles_detected_count = count(array_filter($roles, static fn (array $r): bool => (int) ($r['detected'] ?? 0) === 1));
$roles_attention = $sql_promoted ? [] : array_map(static function (array $item): array {
    $item['title'] = $item['instance'] . ' — ' . $item['title'];
    return $item;
}, $sql_view['issues']);
if ($iis_detected && $iis_stopped > 0) {
    $roles_attention[] = ['title' => $iis_stopped . ' IIS site(s) or app pool(s) stopped', 'detail' => (string) ($iis_summary['sites_total'] ?? '0') . ' site(s), ' . (string) ($iis_summary['app_pools_total'] ?? '0') . ' pool(s).', 'action' => 'Review the IIS inventory below.'];
}
$roles_states = $iis_detected ? [$sections['iis']['state']] : [];
if (! $sql_promoted && ($sql_view['failure'] !== '' || $state_has_issue($sections['sql']['state']) || $sql_view['state'] === 'unknown')) {
    $roles_states[] = $sections['sql']['state'];
}
$roles_tab_state = $worst_section_state($roles_states);
$roles_verdict = empty($roles_attention) ? 'No issues observed in the workloads shown here.' : count($roles_attention) . ' workload condition(s) need attention.';
if (! $sql_promoted && $sql_view['failure'] !== '') {
    $roles_verdict = 'SQL collection failed; SQL state is unknown. Other workloads are listed below.';
}
$roles_tab = $render_tab_summary([
    'state' => $roles_tab_state,
    'verdict' => $roles_verdict,
    'next' => $roles_attention[0]['action'] ?? '',
    'collected' => (string) ($data['last_agent_utc'] ?? ''),
    'tiles' => [
        ['SQL Server', $sql_promoted ? 'Own tab' : ($sql_view['failure'] !== '' ? 'Unknown' : (count($sql_server_components) > 0 ? 'Components only' : ucfirst(str_replace('_', ' ', $sql_view['state'])))), $sql_promoted ? 'Instance health and evidence' : 'Local collection evidence'],
        ['IIS', $iis_detected ? 'Detected' : 'Not detected', $iis_detected ? ((string) ($iis_summary['sites_total'] ?? '0') . ' site(s), ' . $iis_stopped . ' stopped') : 'No web server'],
        ['Detected roles', $roles_detected_count, count($roles) . ' evaluated'],
        ['Logged-on sessions', count($logged_on_user_sessions), 'Interactive and remote'],
    ],
    'attention' => $roles_attention,
]);
if ($sql_promoted) {
    $roles_tab .= '<p><a href="#windows-agent-sql-server" data-windows-agent-open-sql>Open SQL Server tab</a> for instance health, attention and trends.</p>';
} else {
    $roles_tab .= $render_section_summary('sql', 'SQL components and collection', $sections['sql']['state'], $sections['sql']['summary'], $sql_component_details);
}
$roles_tab .= $render_section_summary('iis', 'IIS', $sections['iis']['state'], $sections['iis']['summary'], $iis_details);
$roles_tab .= $render_section_summary('roles', 'Detected Roles', $section_state(empty($roles) ? 'not_detected' : 'ok'), $metric('Rows', count($roles)), $role_details);
if (! $ad_dc_detected) {
    $roles_tab .= $dfsr_section;
}
$roles_tab .= $render_section_summary('users', 'Logged-On Users', $section_state(empty($logged_on_user_sessions) ? 'not_detected' : 'ok'), $metric('Sessions', count($logged_on_user_sessions)), $users_details);

// Security & Certificates tab: TLS certificate health.
$tls_expired = (int) ($tls_certificates_summary['expired_count'] ?? 0);
$tls_expiring = (int) ($tls_certificates_summary['expiring_count'] ?? $tls_certificates_summary['expiring_warning_count'] ?? 0);
$tls_attention = [];
if ($tls_expired > 0) {
    $tls_attention[] = ['title' => $tls_expired . ' certificate(s) expired', 'detail' => 'An expired certificate in a configured store may break TLS for a dependent service.', 'action' => 'Review the certificate inventory below.'];
}
if ($tls_unhealthy_count > 0 && $tls_expired === 0) {
    $tls_attention[] = ['title' => $tls_unhealthy_count . ' certificate(s) unhealthy', 'detail' => 'One or more certificates reported a chain, key, or binding problem.', 'action' => 'Review the certificate health column below.'];
}
$security_verdict = empty($tls_attention)
    ? 'No certificate issues in the configured stores.'
    : count($tls_attention) . ' certificate condition(s) need attention.';
$security_tab = $render_tab_summary([
    'state' => $sections['tls']['state'],
    'verdict' => $security_verdict,
    'next' => $tls_attention[0]['action'] ?? '',
    'collected' => (string) ($data['last_agent_utc'] ?? ''),
    'tiles' => [
        ['Certificates', (string) ($tls_certificates_summary['certificate_count'] ?? '0'), (string) ($tls_certificates_summary['store_count'] ?? '0') . ' store(s) scanned'],
        ['Expired', $tls_expired, $tls_expired > 0 ? 'Action needed' : 'None'],
        ['Expiring soon', $tls_expiring, 'Within warning window'],
        ['Unhealthy', $tls_unhealthy_count, 'Chain, key, or binding'],
    ],
    'attention' => $tls_attention,
]);
$security_tab .= $render_section_summary('tls', 'TLS Certificate Visibility', $sections['tls']['state'], $sections['tls']['summary'], $tls_details, $tls_graphs);

// Backup tab: leads with the shared summary header built from the VSS/backup and
// Datto sections, then the existing detail panels as evidence beneath it.
$backup_vss_failed = (int) ($backup_storage_summary['vss_writers_failed'] ?? 0);
$backup_services_down = (int) ($backup_storage_summary['backup_services_not_running'] ?? 0);
$datto_detected = (int) ($datto_backup_summary['detected'] ?? 0) === 1;
$datto_issues = (int) ($datto_backup_summary['health_issues'] ?? 0);
$backup_tab_state = $worst_section_state([$sections['backup']['state'], $sections['datto']['state']]);
$backup_attention = [];
if ($backup_vss_failed > 0) {
    $backup_attention[] = ['title' => $backup_vss_failed . ' VSS writer(s) failed', 'detail' => 'Volume Shadow Copy writers in a failed state can block backups.', 'action' => 'Review the VSS writer inventory below.'];
}
if ($backup_services_down > 0) {
    $backup_attention[] = ['title' => $backup_services_down . ' backup service(s) not running', 'detail' => 'A stopped backup service prevents scheduled protection.', 'action' => 'Review the backup service inventory below.'];
}
if ($datto_detected && $datto_issues > 0) {
    $backup_attention[] = ['title' => $datto_issues . ' Datto backup issue(s) reported', 'detail' => (string) ($datto_backup_summary['evidence'] ?? 'The Datto backup collector reported one or more issues.'), 'action' => (string) ($datto_backup_summary['next_action'] ?? 'Review the Datto backup evidence below.')];
}
$backup_verdict = empty($backup_attention)
    ? 'No backup or storage issues were reported.'
    : count($backup_attention) . ' backup condition(s) need attention.';
$backup_tab = $render_tab_summary([
    'state' => $backup_tab_state,
    'verdict' => $backup_verdict,
    'next' => $backup_attention[0]['action'] ?? '',
    'collected' => (string) ($data['last_agent_utc'] ?? ''),
    'tiles' => [
        ['VSS writers failed', $backup_vss_failed, (string) ($backup_storage_summary['vss_writers_total'] ?? '0') . ' total'],
        ['Backup services down', $backup_services_down, (string) ($backup_storage_summary['backup_services_total'] ?? '0') . ' watched'],
        ['Datto', $datto_detected ? 'Detected' : 'Not detected', $datto_detected ? ((int) ($datto_backup_summary['service_running'] ?? 0) === 1 ? 'Service running' : 'Service not running') : 'No Datto agent'],
        ['Datto issues', $datto_detected ? $datto_issues : 'N/A', $datto_detected ? (string) ($datto_backup_summary['state'] ?? 'unknown') : 'Not applicable'],
    ],
    'attention' => $backup_attention,
]);
$backup_tab .= $render_section_summary('backup-storage', 'Backup / Storage Visibility', $sections['backup']['state'], $sections['backup']['summary'], $backup_details, [
    ['label' => 'VSS Writer Failures', 'key' => 'windows-agent_backup_vss_failures'],
    ['label' => 'Backup Services Down', 'key' => 'windows-agent_backup_services_down'],
]);
$backup_tab .= $render_section_summary('datto', 'Datto Backup Health', $sections['datto']['state'], $sections['datto']['summary'], $datto_details, [
    ['label' => 'Datto State Flags', 'key' => 'windows-agent_datto_state_flags'],
    ['label' => 'Datto Issue Counts', 'key' => 'windows-agent_datto_issue_counts'],
]);

// Services & Events tab: watched services, event logs, processes, TCP ports, and
// reboot state.
$reboot_pending = (int) ($pending_reboot['pending'] ?? 0) === 1 || (int) ($windows_update['reboot_required'] ?? 0) === 1;
$services_attention = [];
if ($watched_service_issues > 0) {
    $services_attention[] = ['title' => $watched_service_issues . ' watched service(s) down', 'detail' => 'A watched service is not running.', 'action' => 'Review the service inventory below.'];
}
if ($process_issues > 0) {
    $services_attention[] = ['title' => $process_issues . ' watched process(es) missing', 'detail' => 'A watched process was not found.', 'action' => 'Review the watched process list below.'];
}
if ($tcp_issues > 0) {
    $services_attention[] = ['title' => $tcp_issues . ' watched TCP port(s) not listening', 'detail' => 'A watched listener is not accepting connections.', 'action' => 'Review the watched TCP port list below.'];
}
if ($reboot_pending) {
    $services_attention[] = ['title' => 'Reboot pending', 'detail' => 'Windows reports a pending reboot, which can leave updates or services in a partial state.', 'action' => 'Schedule a reboot when convenient.'];
}
$services_tab_state = $worst_section_state([
    $sections['services']['state'], $sections['processes']['state'], $sections['tcp']['state'],
    $section_state($reboot_pending ? 'warning' : 'ok'),
]);
$services_verdict = empty($services_attention)
    ? 'Watched services, processes, ports, and reboot state are all healthy.'
    : count($services_attention) . ' condition(s) need attention.';
$services_tab = $render_tab_summary([
    'state' => $services_tab_state,
    'verdict' => $services_verdict,
    'next' => $services_attention[0]['action'] ?? '',
    'collected' => (string) ($data['last_agent_utc'] ?? ''),
    'tiles' => [
        ['Watched services down', $watched_service_issues, $classified_services_stopped . ' classified stopped'],
        ['Watched processes missing', $process_issues, count($watched_processes) . ' watched'],
        ['TCP ports not listening', $tcp_issues, count($watched_tcp_ports) . ' watched'],
        ['Event criticals/errors', $event_evidence_count, (string) ($event_log_high_value_summary['signatures_total'] ?? '0') . ' high-value groups'],
        ['Reboot', $reboot_pending ? 'Pending' : 'Not pending', $reboot_pending ? 'Action needed' : 'Clean'],
    ],
    'attention' => $services_attention,
]);
$services_tab .= $render_section_summary('reboot', 'Reboot and Windows Update', $section_state(((int) ($pending_reboot['pending'] ?? 0) || (int) ($windows_update['reboot_required'] ?? 0)) ? 'warning' : 'ok'), $metric('Pending reboot', $pending_reboot['pending'] ?? '0') . ' ' . $metric('Update reboot', $windows_update['reboot_required'] ?? '0'), $reboot_details, [
    ['label' => 'Reboot Required State', 'key' => 'windows-agent_reboot_state'],
]);
$services_tab .= $render_section_summary('services', 'Services', $sections['services']['state'], $sections['services']['summary'], $service_details);
$services_tab .= $render_section_summary('events', 'Event Logs', $sections['events']['state'], $sections['events']['summary'], $event_details, [
    ['label' => 'Event Counts', 'key' => 'windows-agent_event_logs'],
]);
$services_tab .= $render_section_summary('processes', 'Watched Processes', $sections['processes']['state'], $sections['processes']['summary'], $process_details);
$services_tab .= $render_section_summary('tcp', 'Watched TCP Ports', $sections['tcp']['state'], $sections['tcp']['summary'], $tcp_details);

// Agent Performance tab: the agent's own health and resource impact, VM resources,
// and Windows performance depth.
$perf_pressure = (int) ($performance_summary['pressure_issues'] ?? 0);
$agent_perf_attention = [];
if ($agent_issues > 0) {
    $agent_perf_attention[] = ['title' => $agent_issues . ' collector(s) failed or timed out', 'detail' => 'A collector that fails or times out leaves its section stale.', 'action' => 'Review collector timings below.'];
}
if ($perf_pressure > 0) {
    $agent_perf_attention[] = ['title' => $perf_pressure . ' Windows performance pressure issue(s)', 'detail' => 'CPU queue, memory commit, paging, or disk latency crossed a pressure threshold.', 'action' => 'Review Windows performance depth below.'];
}
$agent_perf_tab_state = $worst_section_state([$sections['agent']['state'], $sections['vm']['state'], $sections['performance']['state'], $sections['collector_impact']['state']]);
$agent_perf_verdict = empty($agent_perf_attention)
    ? 'The agent is collecting cleanly with no host pressure reported.'
    : count($agent_perf_attention) . ' agent or performance condition(s) need attention.';
$agent_performance_tab = $render_tab_summary([
    'state' => $agent_perf_tab_state,
    'verdict' => $agent_perf_verdict,
    'next' => $agent_perf_attention[0]['action'] ?? '',
    'collected' => (string) ($data['last_agent_utc'] ?? ''),
    'tiles' => [
        ['Agent version', (string) ($agent['version'] ?? 'unknown'), 'Collector issues: ' . $agent_issues],
        ['Collector CPU', $format_percent($agent_resource_cpu_percent), 'Duration ' . $agent_resource_duration_ms . ' ms'],
        ['Collector memory', $format_bytes($agent_resource_memory_bytes), 'Agent working set'],
        ['VM CPU / memory', ((string) ($vm_resource_summary['cpu_load_percent'] ?? '0')) . '% / ' . ((string) ($vm_resource_summary['memory_used_percent'] ?? '0')) . '%', 'Max disk ' . ((string) ($vm_resource_summary['disk_used_percent_max'] ?? '0')) . '%'],
        ['Pressure issues', $perf_pressure, 'Windows performance depth'],
    ],
    'attention' => $agent_perf_attention,
]);
$agent_performance_tab .= $render_section_summary('agent-os', 'Agent and OS', $sections['agent']['state'], $sections['agent']['summary'], $agent_details);
$agent_performance_tab .= $performance_tab;
$agent_performance_tab .= $render_section_summary('collector-timings', 'Collector Timings', $sections['agent']['state'], $metric('Collectors run', $agent_performance['collectors_run'] ?? '0') . ' ' . $metric('Failed/timed out', $agent_issues), $collector_details);

echo '<style>
.windows-agent-collapse-toggle .windows-agent-collapse-arrow { margin-left: 4px; }
.windows-agent-collapse-toggle .windows-agent-collapse-arrow-down { display: none; }
.windows-agent-collapse-toggle .windows-agent-collapse-arrow-up { display: inline-block; }
.windows-agent-collapse-toggle.collapsed .windows-agent-collapse-arrow-down { display: inline-block; }
.windows-agent-collapse-toggle.collapsed .windows-agent-collapse-arrow-up { display: none; }
.windows-agent-graph-view { margin-bottom: 12px; }
.windows-agent-graph-view h4 { margin-top: 0; margin-bottom: 6px; font-size: 13px; font-weight: 600; }
.windows-agent-overview-title { margin: 0 0 12px; padding-bottom: 8px; border-bottom: 1px solid rgba(127, 127, 127, 0.35); font-size: 16px; font-weight: 600; }
.windows-agent-data-table th,
.windows-agent-data-table td { vertical-align: middle !important; }
.windows-agent-tab-alert { margin-left: 5px; }
.windows-agent-subsection { margin-top: 14px; padding-top: 12px; border-top: 1px solid rgba(127, 127, 127, 0.25); }
.windows-agent-subsection-body { margin-top: 12px; }
.windows-agent-disclosure-summary { margin-left: 6px; }
.windows-agent-tab-summary { margin-bottom: 18px; }
.windows-agent-tab-summary .windows-agent-role-stats:last-child { margin-bottom: 0; border-bottom: 0; }
.windows-agent-role-status { margin-bottom: 0; padding: 8px 10px; border-left: 3px solid #999; border-bottom: 1px solid rgba(127, 127, 127, 0.2); background: transparent; }
.windows-agent-role-status-success { border-left-color: #5cb85c; }
.windows-agent-role-status-warning { border-left-color: #f0ad4e; }
.windows-agent-role-status-danger { border-left-color: #d9534f; }
.windows-agent-role-action { margin-left: 10px; font-weight: normal; }
.windows-agent-role-collected { float: right; margin-left: 10px; font-size: 11px; font-weight: normal; }
.windows-agent-role-stats { margin: 0 0 18px; border-bottom: 1px solid rgba(127, 127, 127, 0.25); }
.windows-agent-role-stat { min-height: 78px; padding-top: 12px; padding-bottom: 10px; border-right: 1px solid rgba(127, 127, 127, 0.2); }
.windows-agent-role-stat:last-child { border-right: 0; }
.windows-agent-role-stat-label { font-size: 12px; }
.windows-agent-role-stat-value { margin: 2px 0; font-size: 18px; font-weight: 600; line-height: 1.2; }
.windows-agent-role-stat-detail { font-size: 11px; }
.windows-agent-role-attention { margin: 0 0 14px; }
.windows-agent-role-attention h4 { margin: 0 0 4px; font-size: 14px; font-weight: 600; }
.windows-agent-role-attention ul { margin: 0; padding: 0; list-style: none; }
.windows-agent-role-attention li { padding: 6px 0; border-top: 1px solid rgba(127, 127, 127, 0.2); }
.windows-agent-role-attention-action { margin-top: 2px; }
.windows-agent-sql {
    --sql-text: #202630;
    --sql-muted: #626d7a;
    --sql-border: #cfd6df;
    --sql-surface: #fff;
    --sql-subtle: #f5f8fc;
    --sql-link: #1769d2;
    color: var(--sql-text);
    overflow-wrap: anywhere;
}
.dark .windows-agent-sql {
    --sql-text: #e6edf3;
    --sql-muted: #a7b2bf;
    --sql-border: #4b5563;
    --sql-surface: #2d333a;
    --sql-subtle: #343b43;
    --sql-link: #79b8ff;
}

.windows-agent-sql [hidden] { display: none !important; }
.windows-agent-sql-filters { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 10px; padding: 12px; background: var(--sql-subtle); border: 1px solid var(--sql-border); }
.windows-agent-sql-filters > div { flex: 1 1 190px; }
.windows-agent-sql-filters label { display: block; margin-bottom: 5px; }
.windows-agent-sql-filters .form-control { background: var(--sql-surface); color: var(--sql-text); border-color: var(--sql-border); }
.windows-agent-sql-filter-status { margin: 10px 0; }
.windows-agent-sql-section { border: 1px solid var(--sql-border); margin-bottom: 10px; }
.windows-agent-sql-section > summary { cursor: pointer; padding: 10px 12px; background: var(--sql-subtle); }
.windows-agent-sql-section > summary > span { margin-left: 10px; font-size: 12px; }
.windows-agent-sql-section > summary:focus-visible { outline: 2px solid var(--sql-link); }
.windows-agent-sql-section-body { padding: 12px; }
@media (max-width: 767px) {
    .windows-agent-sql-filters > div { flex-basis: 100%; }
    .windows-agent-sql-section > summary > span { display: block; margin: 4px 0 0; }
}

.windows-agent-sql .text-muted { color: var(--sql-muted) !important; }
.windows-agent-sql small { color: var(--sql-muted); }
.windows-agent-sql a { color: var(--sql-link); }
.windows-agent-sql .label-warning { color: #332200; }
.windows-agent-sql .label-success { background: #357a38; }
.windows-agent-sql .label-danger { background: #a94442; }
.windows-agent-sql .label-info { background: #31708f; }
.windows-agent-sql .label-default { background: #666; }
.windows-agent-sql .windows-agent-role-status-info .label-info { background: #666; }
.windows-agent-sql .windows-agent-role-status { padding: 12px; background: var(--sql-subtle); }
.windows-agent-sql .windows-agent-role-collected { float: none; display: block; margin: 6px 0 0; }
.windows-agent-sql .windows-agent-role-action { display: block; margin: 6px 0 0; }
.windows-agent-sql .windows-agent-role-coverage { margin-top: 8px; font-size: 12px; }
.windows-agent-sql .windows-agent-role-stats { display: grid; grid-template-columns: repeat(5, minmax(0, 1fr)); margin: 0 0 14px; }
.windows-agent-sql .windows-agent-role-stats::before,
.windows-agent-sql .windows-agent-role-stats::after { display: none; }
.windows-agent-sql .windows-agent-role-stat { float: none; width: auto; min-width: 0; min-height: 108px; padding: 12px; overflow-wrap: anywhere; }
.windows-agent-sql .windows-agent-role-stat-value { font-size: 19px; }
.windows-agent-sql .windows-agent-role-attention { margin: 14px 0 0; }
.windows-agent-sql .windows-agent-role-attention li { padding: 9px 0; }
.windows-agent-sql-coverage { margin-bottom: 16px; padding: 10px 12px; border: 1px solid var(--sql-border); background: var(--sql-subtle); }
.windows-agent-sql-coverage ul { margin: 6px 0 0; padding-left: 18px; }
.windows-agent-sql-instance { margin-bottom: 8px; border: 1px solid var(--sql-border); background: var(--sql-surface); }
.windows-agent-sql-instance > summary { position: relative; display: grid; grid-template-columns: minmax(150px, 1fr) minmax(0, 3fr); gap: 6px 18px; padding: 12px 14px 12px 32px; list-style: none; cursor: pointer; overflow-wrap: anywhere; }
.windows-agent-sql-instance > summary::-webkit-details-marker { display: none; }
.windows-agent-sql-instance > summary::before { content: "›"; position: absolute; left: 12px; top: 8px; font-size: 22px; color: var(--sql-link); }
.windows-agent-sql-instance[open] > summary::before { transform: rotate(90deg); }
.windows-agent-sql-instance > summary:hover { background: var(--sql-subtle); }
.windows-agent-sql-instance > summary:focus-visible { outline: 2px solid var(--sql-link); outline-offset: -2px; }
.windows-agent-sql-instance-name .label { display: inline-block; margin-left: 4px; }
.windows-agent-sql-instance-facts { display: flex; flex-wrap: wrap; gap: 4px 16px; font-size: 12px; }
.windows-agent-sql-instance-reason { grid-column: 1 / -1; font-size: 12px; }
.windows-agent-sql-expand { float: right; color: var(--sql-link); }
.windows-agent-sql-instance-body { padding: 14px; border-top: 1px solid var(--sql-border); }
.windows-agent-sql-evidence { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px 24px; margin: 0 0 16px; }
.windows-agent-sql-evidence > div { min-width: 0; overflow-wrap: anywhere; }
.windows-agent-sql-evidence dt { color: var(--sql-muted); font-size: 12px; font-weight: 400; }
.windows-agent-sql-evidence dd { margin: 3px 0 0; }
.windows-agent-sql .table { color: var(--sql-text); background: var(--sql-surface); }
.windows-agent-sql .table > tbody > tr > td,
.windows-agent-sql .table > tbody > tr > th { border-color: var(--sql-border); }
.windows-agent-sql .table-striped > tbody > tr:nth-of-type(odd) { background: var(--sql-subtle); }
.dark .windows-agent-sql .btn-default { color: var(--sql-text); border-color: var(--sql-border); background: var(--sql-surface); }
@media (max-width: 991px) {
    .windows-agent-sql .windows-agent-role-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .windows-agent-sql .windows-agent-role-stat:nth-child(3) { grid-column: 1 / -1; }
    .windows-agent-sql .windows-agent-role-stat { min-height: 84px; border-bottom: 1px solid var(--sql-border); }
}
@media (max-width: 767px) {
    .windows-agent-sql-instance > summary { display: block; }
    .windows-agent-sql-instance-name,
    .windows-agent-sql-instance-reason { display: block; }
    .windows-agent-sql-instance-facts { display: grid; gap: 4px; margin: 8px 0; }
    .windows-agent-sql-evidence { grid-template-columns: minmax(0, 1fr); }
    .windows-agent-sql-expand { float: none; margin-left: 8px; }
}
.windows-agent-horizon-operations {
    --horizon-blue: #1769d2;
    --horizon-link: #1769d2;
    --horizon-border: #cfd6df;
    --horizon-muted: #66717f;
    --horizon-text: #202630;
    --horizon-surface: #fff;
    --horizon-surface-raised: #fff;
    --horizon-surface-subtle: #f5f8fc;
    --horizon-progress-track: #eef1f4;
    --horizon-progress-border: #c7ced8;
    --horizon-shadow: rgba(20, 31, 45, 0.18);
    color: var(--horizon-text);
}
.dark .windows-agent-horizon-operations {
    --horizon-blue: #4d9cff;
    --horizon-link: #79b8ff;
    --horizon-border: #4b5563;
    --horizon-muted: #a7b2bf;
    --horizon-text: #e6edf3;
    --horizon-surface: #2d333a;
    --horizon-surface-raised: #343b43;
    --horizon-surface-subtle: #39424c;
    --horizon-progress-track: #242a30;
    --horizon-progress-border: #5b6673;
    --horizon-shadow: rgba(0, 0, 0, 0.45);
}
.windows-agent-horizon-operations a,
.windows-agent-horizon-condition-target,
.windows-agent-horizon-table-target { color: var(--horizon-link); }
.windows-agent-horizon-operations .text-muted { color: var(--horizon-muted) !important; }
.windows-agent-horizon-operations .table > thead > tr > th,
.windows-agent-horizon-operations .table > tbody > tr > td { border-color: var(--horizon-border); color: var(--horizon-text); }
.dark .windows-agent-horizon-operations .btn-default { border-color: var(--horizon-border); background: var(--horizon-surface-raised); color: var(--horizon-text); }
.dark .windows-agent-horizon-operations .btn-default:hover,
.dark .windows-agent-horizon-operations .btn-default:focus { border-color: #6b7785; background: var(--horizon-surface-subtle); color: #fff; }
.windows-agent-horizon-title-row,
.windows-agent-horizon-section-heading,
.windows-agent-horizon-trend-header { display: flex; align-items: center; justify-content: space-between; gap: 16px; }
.windows-agent-horizon-title-row { margin-bottom: 12px; }
.windows-agent-horizon-title-row h3 { margin: 0 0 2px; font-size: 24px; font-weight: 600; }
.windows-agent-horizon-title-row p { margin: 0; }
.windows-agent-horizon-freshness { color: var(--horizon-muted); font-size: 12px; white-space: nowrap; }
.windows-agent-horizon-health-scopes { display: grid; grid-template-columns: repeat(5, minmax(120px, 1fr)); gap: 8px; margin: 12px 0; }
.windows-agent-horizon-health-scope { display: flex; justify-content: space-between; align-items: baseline; gap: 10px; min-height: 46px; padding: 11px 12px; border: 1px solid var(--horizon-border); border-left: 4px solid #8b96a5; border-radius: 4px; background: var(--horizon-surface); color: var(--horizon-text); }
.windows-agent-horizon-health-scope > span { color: var(--horizon-muted); font-size: 12px; text-transform: uppercase; letter-spacing: .03em; }
.windows-agent-horizon-health-scope-ok { border-left-color: #5cb85c; }
.windows-agent-horizon-health-scope-info { border-left-color: #337ab7; }
.windows-agent-horizon-health-scope-warning,
.windows-agent-horizon-health-scope-incomplete { border-left-color: #f0ad4e; }
.windows-agent-horizon-health-scope-critical { border-left-color: #d9534f; }
.windows-agent-horizon-section,
.windows-agent-horizon-trend { margin-bottom: 12px; border: 1px solid var(--horizon-border); border-radius: 3px; background: var(--horizon-surface); }
.windows-agent-horizon-section-heading,
.windows-agent-horizon-trend-header { min-height: 40px; padding: 8px 12px; border-bottom: 1px solid var(--horizon-border); }
.windows-agent-horizon-section-heading h4,
.windows-agent-horizon-trend-header h4 { margin: 0; font-size: 16px; font-weight: 600; }
.windows-agent-horizon-condition { display: grid; grid-template-columns: 24px 92px minmax(150px, 1fr) minmax(240px, 2fr) minmax(220px, 1.4fr); gap: 10px; align-items: center; min-height: 54px; padding: 8px 12px; border-bottom: 1px solid var(--horizon-border); border-left: 4px solid #8b96a5; }
.windows-agent-horizon-condition:last-child { border-bottom: 0; }
.windows-agent-horizon-condition-critical { border-left-color: #d9534f; }
.windows-agent-horizon-condition-warning,
.windows-agent-horizon-condition-incomplete { border-left-color: #f0ad4e; }
.windows-agent-horizon-condition-info { border-left-color: #337ab7; }
.windows-agent-horizon-condition-ok { grid-template-columns: 24px 1fr; border-left-color: #5cb85c; }
.windows-agent-horizon-condition-critical > .glyphicon { color: #d9534f; }
.windows-agent-horizon-condition-warning > .glyphicon,
.windows-agent-horizon-condition-incomplete > .glyphicon { color: #d58512; }
.windows-agent-horizon-condition-info > .glyphicon { color: #337ab7; }
.windows-agent-horizon-condition-ok > .glyphicon { color: #3c9a3c; }
.windows-agent-horizon-observation { display: flex; gap: 10px; align-items: flex-start; padding: 10px 12px; border-top: 1px solid var(--horizon-border); color: var(--horizon-text); }
.windows-agent-horizon-observation:first-of-type { border-top: 0; }
.windows-agent-horizon-observation > .glyphicon { color: #337ab7; margin-top: 2px; }
.windows-agent-horizon-condition-target,
.windows-agent-horizon-table-target { padding: 0; border: 0; background: transparent; font: inherit; text-align: left; text-decoration: underline; text-decoration-thickness: 1px; text-underline-offset: 2px; }
.windows-agent-horizon-condition-target:hover,
.windows-agent-horizon-condition-target:focus,
.windows-agent-horizon-table-target:hover,
.windows-agent-horizon-table-target:focus { color: var(--horizon-link); outline: 2px solid rgba(77, 156, 255, 0.55); outline-offset: 3px; }
.windows-agent-horizon-policy { color: var(--horizon-muted); font-size: 11px; }
.windows-agent-horizon-dot { display: inline-block; width: 7px; height: 7px; margin: 0 4px 0 10px; border-radius: 50%; }
.windows-agent-horizon-dot-info { background: #337ab7; }
.windows-agent-horizon-dot-warning { background: #f0ad4e; }
.windows-agent-horizon-dot-critical { background: #d9534f; }
.windows-agent-horizon-pool-head,
.windows-agent-horizon-pool-summary { display: grid; grid-template-columns: minmax(230px, 2fr) minmax(120px, 1fr) 72px 90px 68px 88px minmax(150px, 1.2fr) 76px; gap: 8px; align-items: center; }
.windows-agent-horizon-pool-head { min-height: 30px; padding: 5px 12px 5px 36px; border-bottom: 1px solid var(--horizon-border); color: var(--horizon-muted); font-size: 11px; font-weight: 600; }
.windows-agent-horizon-pool { border-bottom: 1px solid var(--horizon-border); border-left: 4px solid transparent; }
.windows-agent-horizon-pool:last-child { border-bottom: 0; }
.windows-agent-horizon-pool-critical { border-left-color: #d9534f; }
.windows-agent-horizon-pool-warning,
.windows-agent-horizon-pool-incomplete { border-left-color: #f0ad4e; }
.windows-agent-horizon-pool-info { border-left-color: #337ab7; }
.windows-agent-horizon-pool-summary { min-height: 58px; padding: 0 12px 0 0; background: var(--horizon-surface); }
.windows-agent-horizon-pool-toggle { position: relative; width: 100%; min-height: 58px; padding: 8px 8px 8px 32px; border: 0; background: transparent; color: inherit; text-align: left; }
.windows-agent-horizon-pool-toggle:hover,
.windows-agent-horizon-pool-toggle:focus,
.windows-agent-horizon-pool-count:hover,
.windows-agent-horizon-pool-count:focus { background: var(--horizon-surface-subtle); outline: 2px solid transparent; box-shadow: inset 0 0 0 2px rgba(77, 156, 255, 0.5); }
.windows-agent-horizon-pool-count { min-width: 36px; min-height: 34px; padding: 4px 7px; border: 1px solid transparent; border-radius: 3px; background: transparent; color: var(--horizon-link); font-weight: 600; text-align: center; }
.windows-agent-horizon-pool-summary [data-metric-label]::before { display: none; content: attr(data-metric-label); }
.windows-agent-horizon-pool-state,
.windows-agent-horizon-demand { color: var(--horizon-text); }
.windows-agent-horizon-pool-chevron { position: absolute; left: 10px; top: 22px; color: #4e5968; transition: transform 140ms ease; }
.windows-agent-horizon-pool-toggle[aria-expanded="true"] .windows-agent-horizon-pool-chevron { transform: rotate(90deg); }
.windows-agent-horizon-pool-name small { display: block; margin-top: 2px; color: var(--horizon-muted); font-weight: 400; }
.windows-agent-horizon-headroom i { display: block; height: 6px; margin-top: 5px; overflow: hidden; border: 1px solid var(--horizon-progress-border); border-radius: 3px; background: var(--horizon-progress-track); }
.windows-agent-horizon-headroom b { display: block; height: 100%; background: #4cae4c; }
.windows-agent-horizon-machine-region { margin: 0 8px 8px; border: 1px solid #5793df; border-radius: 3px; background: var(--horizon-surface-raised); }
.windows-agent-horizon-machine-toolbar { display: flex; align-items: center; justify-content: space-between; gap: 10px; min-height: 40px; padding: 6px 10px; border-bottom: 1px solid var(--horizon-border); }
.windows-agent-horizon-machine-toolbar > div:first-child .text-muted { margin-left: 4px; font-size: 11px; }
.windows-agent-horizon-machine-head,
.windows-agent-horizon-machine-row { display: grid; grid-template-columns: minmax(190px, 1.4fr) 110px 95px 110px minmax(170px, 1.2fr) minmax(160px, 1fr); gap: 8px; align-items: center; }
.windows-agent-horizon-machine-head { min-height: 30px; padding: 5px 12px; border-bottom: 1px solid var(--horizon-border); color: var(--horizon-muted); font-size: 11px; font-weight: 600; }
.windows-agent-horizon-machine-row { width: 100%; min-height: 42px; padding: 7px 12px; border: 0; border-bottom: 1px solid var(--horizon-border); background: var(--horizon-surface-raised); color: inherit; text-align: left; }
.windows-agent-horizon-machine-row[hidden] { display: none !important; }
.windows-agent-horizon-machine-row:hover,
.windows-agent-horizon-machine-row:focus { background: var(--horizon-surface-subtle); box-shadow: inset 0 0 0 2px rgba(77, 156, 255, 0.5); outline: 0; }
.windows-agent-horizon-machine-critical { border-left: 4px solid #d9534f; }
.windows-agent-horizon-machine-critical .glyphicon-exclamation-sign { color: #d9534f; font-size: 11px; }
.windows-agent-horizon-machine-warning { border-left: 4px solid #f0ad4e; }
.windows-agent-horizon-machine-warning .glyphicon-pause { color: #f0ad4e; font-size: 11px; }
.windows-agent-horizon-machine-empty { padding: 18px 12px; color: var(--horizon-muted); text-align: center; }
.windows-agent-horizon-machine-empty-static { border-top: 1px solid var(--horizon-border); }
.windows-agent-horizon-truncation { margin: 8px 12px; }
.windows-agent-horizon-detail-drawer { position: fixed; z-index: 1061; top: 50px; right: 0; bottom: 0; width: min(420px, 100vw); overflow-y: auto; padding: 16px 22px; border-left: 1px solid var(--horizon-border); background: var(--horizon-surface-raised); color: var(--horizon-text); box-shadow: -8px 0 24px var(--horizon-shadow); }
.windows-agent-horizon-drawer-backdrop { position: fixed; z-index: 1060; inset: 0; border: 0; background: rgba(0, 0, 0, 0.35); }
.windows-agent-horizon-drawer-header { display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--horizon-border); }
.windows-agent-horizon-drawer-header h4 { margin: 0 0 12px; font-size: 16px; font-weight: 600; }
.windows-agent-horizon-detail-drawer h3 { margin: 18px 0 4px; }
.windows-agent-horizon-detail-drawer dl { display: grid; grid-template-columns: 140px 1fr; gap: 10px; margin-top: 24px; }
.windows-agent-horizon-detail-drawer dt,
.windows-agent-horizon-detail-drawer dd { margin: 0; }
.windows-agent-horizon-detail-drawer .close { color: var(--horizon-text); opacity: 0.8; text-shadow: none; }
.windows-agent-horizon-drawer-evidence,
.windows-agent-horizon-drawer-next { margin-top: 24px; padding-top: 16px; border-top: 1px solid var(--horizon-border); }
.windows-agent-horizon-service-list { margin: 0; padding: 0; list-style: none; }
.windows-agent-horizon-service-list li { display: flex; justify-content: space-between; gap: 12px; padding: 8px 0; border-bottom: 1px solid var(--horizon-border); }
.windows-agent-horizon-trend { padding-bottom: 8px; }
.windows-agent-horizon-trend-header .btn.active,
.windows-agent-horizon-machine-toolbar .btn.active { color: #fff; background: var(--horizon-blue); border-color: #0f57b6; }
.windows-agent-horizon-trend-image { width: 100%; min-height: 180px; object-fit: contain; }
.windows-agent-horizon-evidence-row { margin-left: -6px; margin-right: -6px; }
.windows-agent-horizon-evidence-row > section { padding-left: 6px; padding-right: 6px; }
.windows-agent-horizon-platform-table { margin-bottom: 0; }
.windows-agent-horizon-platform-table > thead > tr > th { background: var(--horizon-surface-subtle); }
.windows-agent-horizon-platform-summary { display: flex; flex-wrap: wrap; gap: 8px 20px; padding: 10px 12px; border-top: 1px solid var(--horizon-border); }
.windows-agent-horizon-collector { display: grid; grid-template-columns: minmax(135px, 1fr) 1fr; gap: 7px 12px; padding: 12px; }
.windows-agent-horizon-collector dt,
.windows-agent-horizon-collector dd { margin: 0; }
.windows-agent-horizon-visibility-note { margin: 12px 4px 0; color: var(--horizon-muted); }
@media (max-width: 767px) {
    .windows-agent-horizon-health-scopes { grid-template-columns: 1fr; }
    .windows-agent-role-stat { min-height: 0; border-right: 0; border-bottom: 1px solid rgba(127, 127, 127, 0.15); }
    .windows-agent-role-action,
    .windows-agent-role-collected { display: block; float: none; margin: 4px 0 0; }
    .windows-agent-disclosure-summary { display: block; margin: 6px 0 0; }
    .windows-agent-horizon-title-row,
    .windows-agent-horizon-section-heading,
    .windows-agent-horizon-trend-header,
    .windows-agent-horizon-machine-toolbar { align-items: flex-start; flex-direction: column; }
    .windows-agent-horizon-freshness { white-space: normal; }
    .windows-agent-horizon-condition { grid-template-columns: 24px 1fr; }
    .windows-agent-horizon-condition > div:nth-child(n+3) { grid-column: 2; }
    .windows-agent-horizon-pool-head { display: none; }
    .windows-agent-horizon-pool-summary { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 6px; padding: 6px 8px; }
    .windows-agent-horizon-pool-toggle { grid-column: 1 / -1; min-height: 50px; }
    .windows-agent-horizon-pool-state,
    .windows-agent-horizon-headroom,
    .windows-agent-horizon-demand { grid-column: span 1; padding: 4px 7px; }
    .windows-agent-horizon-pool-summary [data-metric-label] { display: flex; align-items: center; justify-content: space-between; gap: 8px; min-height: 34px; text-align: right; }
    .windows-agent-horizon-pool-summary [data-metric-label]::before { display: inline; color: var(--horizon-muted); font-size: 10px; font-weight: 600; text-align: left; text-transform: uppercase; }
    .windows-agent-horizon-headroom { flex-wrap: wrap; }
    .windows-agent-horizon-headroom i { flex-basis: 100%; }
    .windows-agent-horizon-machine-head { display: none; }
    .windows-agent-horizon-machine-row { grid-template-columns: 1fr 1fr; }
    .windows-agent-horizon-machine-row > span:nth-child(n+3) { font-size: 11px; }
    .windows-agent-horizon-machine-toolbar .btn-group { display: flex; flex-wrap: wrap; }
}
</style>';
// Detected first-order roles are promoted to their own tab, in a fixed order so
// a host carrying more than one role always renders the same layout. Each role
// tab appears only while that role is detected, and the first tab in the built
// list is the landing tab.
$tab_definitions = [];
if ($ad_dc_detected) {
    $tab_definitions['windows-agent-active-directory'] = [
        'title' => 'Active Directory',
        'body' => $active_directory_tab,
        'issue' => $state_has_issue($sections['ad_dc']['state']) || $dfsr_has_issue,
    ];
}
if ($factorytalk_detected) {
    $tab_definitions['windows-agent-factorytalk'] = [
        'title' => 'FactoryTalk',
        'body' => $factorytalk_tab,
        'issue' => $state_has_issue($sections['factorytalk']['state']),
    ];
}
if ($horizon_surface_available) {
    $tab_definitions['windows-agent-horizon'] = [
        'title' => 'Horizon',
        'body' => $horizon_tab,
        'issue' => $state_has_issue($sections['horizon']['state']),
    ];
}
if ($sql_promoted) {
    $tab_definitions['windows-agent-sql-server'] = [
        'title' => 'SQL Server',
        'body' => $sql_tab,
        'issue' => $state_has_issue($sections['sql']['state']),
    ];
}
$tab_definitions += [
    'windows-agent-overview' => [
        'title' => 'Overview',
        'body' => $overview,
        'issue' => false,
    ],
    'windows-agent-roles' => [
        'title' => 'Roles & Workloads',
        'body' => $roles_tab,
        'issue' => $state_has_issue($roles_tab_state) || (! $ad_dc_detected && $dfsr_has_issue),
    ],
    'windows-agent-security' => [
        'title' => 'Security & Certificates',
        'body' => $security_tab,
        'issue' => $state_has_issue($sections['tls']['state']),
    ],
    'windows-agent-backup' => [
        'title' => 'Backup',
        'body' => $backup_tab,
        'issue' => $state_has_issue($sections['backup']['state']) || $state_has_issue($sections['datto']['state']),
    ],
    'windows-agent-services' => [
        'title' => 'Services & Events',
        'body' => $services_tab,
        'issue' => $state_has_issue($sections['services']['state']) || $state_has_issue($sections['events']['state']) || $state_has_issue($sections['processes']['state']) || $state_has_issue($sections['tcp']['state']) || ((int) ($pending_reboot['pending'] ?? 0) || (int) ($windows_update['reboot_required'] ?? 0)),
    ],
    'windows-agent-agent-performance' => [
        'title' => 'Agent Performance',
        'body' => $agent_performance_tab,
        'issue' => $state_has_issue($sections['agent']['state']) || $state_has_issue($sections['vm']['state']) || $state_has_issue($sections['performance']['state']),
    ],
];
$active_tab_id = $sql_promoted && ($sql_has_scope ?? false) ? 'windows-agent-sql-server' : (string) array_key_first($tab_definitions);
$issue_icon = '<span class="windows-agent-tab-alert glyphicon glyphicon-exclamation-sign text-danger" title="This tab has one or more issues" aria-label="issues present"></span>';
echo '<ul class="nav nav-tabs" role="tablist">';
foreach ($tab_definitions as $id => $tab) {
    echo '<li role="presentation" class="' . ($id === $active_tab_id ? 'active' : '') . '"><a href="#' . $esc($id) . '" aria-controls="' . $esc($id) . '" role="tab" data-toggle="tab">' . $esc($tab['title'] ?? '') . (($tab['issue'] ?? false) ? ' ' . $issue_icon : '') . '</a></li>';
}
echo '</ul>';
echo '<div class="tab-content" style="padding-top: 15px;">';
foreach ($tab_definitions as $id => $tab) {
    $render_tab($id, $id === $active_tab_id, (string) ($tab['body'] ?? ''));
}
echo '</div>';
echo '<script>
(function () {
    "use strict";
    var lastDrawerTrigger = null;
    var sqlRoot = document.querySelector(".windows-agent-sql");
    var sqlForm = sqlRoot && sqlRoot.querySelector("[data-sql-filters]");
    function sqlScope(writeUrl) {
        if (!sqlForm) return;
        var selected = sqlForm.elements.sql_instance.value;
        var show = sqlForm.elements.sql_show.value;
        var shown = 0, outside = 0, total = 0;
        sqlRoot.querySelectorAll("[data-sql-instance]").forEach(function (card) {
            var visible = (selected === "all" || selected === card.dataset.sqlInstance) && (show === "all" || card.dataset.sqlState !== "ok");
            card.hidden = !visible;
            total++;
            if (visible) shown++; else outside += Number(card.dataset.sqlIssues || 0);
        });
        sqlRoot.querySelector("[data-sql-filter-status]").textContent = "Showing " + shown + " of " + total + " instances; " + outside + " instance condition(s) outside this filter. Summary and attention remain global.";
        sqlRoot.querySelector("[data-sql-empty]").hidden = shown > 0;
        if (writeUrl) {
            var url = new URL(sqlForm.action);
            url.searchParams.set("sql_instance", selected);
            url.searchParams.set("sql_show", show);
            if (url.origin === location.origin) history.replaceState(null, "", url);
        }
    }
    if (sqlForm) {
        sqlForm.addEventListener("submit", function (event) {
            if (new URL(sqlForm.action).origin !== location.origin) return;
            event.preventDefault(); sqlScope(true);
        });
        sqlForm.addEventListener("change", function () { sqlScope(true); });
        sqlRoot.querySelector("[data-sql-clear]").addEventListener("click", function (event) {
            event.preventDefault();
            sqlForm.elements.sql_instance.value = "all";
            sqlForm.elements.sql_show.value = "all";
            sqlScope(true);
        });
        sqlScope(false);
    }
    document.addEventListener("click", function (event) {
        var evidence = event.target.closest("[data-sql-evidence-link]");
        if (evidence && sqlForm) {
            var target = new URL(evidence.href);
            if (target.origin !== location.origin) return;
            var id = target.searchParams.get("sql_open");
            var card = document.getElementById("windows-agent-sql-instance-" + id);
            if (!card) return;
            event.preventDefault();
            sqlForm.elements.sql_instance.value = id;
            sqlForm.elements.sql_show.value = "all";
            sqlScope(false);
            var sqlTab = document.querySelector("a[role=tab][aria-controls=windows-agent-sql-server]");
            if (sqlTab) sqlTab.click();
            card.open = true;
            var section = document.getElementById("windows-agent-sql-" + id + "-" + target.searchParams.get("sql_section"));
            if (section) section.open = true;
            history.replaceState(null, "", target);
            var summary = (section || card).querySelector("summary");
            summary.focus();
            summary.scrollIntoView({block: "nearest"});
            return;
        }
        if (!event.target.closest("[data-windows-agent-open-sql]")) return;
        var tab = document.querySelector("a[role=tab][aria-controls=windows-agent-sql-server]");
        if (tab) { event.preventDefault(); tab.click(); tab.focus(); }
    });
    function setPoolOpen(poolRef, open) {
        var toggle = document.querySelector("[data-pool-toggle=\"" + poolRef + "\"]");
        var region = document.querySelector("[data-pool-region=\"" + poolRef + "\"]");
        if (!toggle || !region) return null;
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
        region.hidden = !open;
        return region;
    }
    function applyMachineFilter(poolRef, category) {
        var region = document.querySelector("[data-pool-region=\"" + poolRef + "\"]");
        if (!region) return;
        region.querySelectorAll("[data-machine-filter]").forEach(function (button) {
            var active = button.getAttribute("data-machine-filter") === category;
            button.classList.toggle("active", active);
            button.setAttribute("aria-pressed", active ? "true" : "false");
        });
        var shown = 0;
        region.querySelectorAll("[data-machine-category]").forEach(function (row) {
            var categories = (row.getAttribute("data-machine-category") || "").split(/\s+/);
            var visible = category === "all" || categories.indexOf(category) !== -1;
            row.hidden = !visible;
            if (visible) shown++;
        });
        var empty = region.querySelector("[data-machine-empty]");
        if (empty) {
            empty.hidden = shown !== 0;
            empty.textContent = shown === 0 ? "No " + (category === "all" ? "" : category + " ") + "machines match this filter." : "";
        }
    }
    function closeDrawers(restoreFocus) {
        document.querySelectorAll("[data-horizon-drawer-panel]").forEach(function (panel) { panel.hidden = true; });
        var backdrop = document.querySelector("[data-horizon-drawer-backdrop]");
        if (backdrop) backdrop.hidden = true;
        if (restoreFocus && lastDrawerTrigger) lastDrawerTrigger.focus();
        lastDrawerTrigger = null;
    }
    function openDrawer(ref, trigger) {
        var drawer = document.querySelector("[data-horizon-drawer-panel=\"" + ref + "\"]");
        if (!drawer) return;
        closeDrawers(false);
        lastDrawerTrigger = trigger;
        drawer.hidden = false;
        var backdrop = document.querySelector("[data-horizon-drawer-backdrop]");
        if (backdrop) backdrop.hidden = false;
        var close = drawer.querySelector("[data-horizon-drawer-close]");
        if (close) close.focus();
    }
    document.addEventListener("click", function (event) {
        var poolToggle = event.target.closest("[data-pool-toggle]");
        if (poolToggle) {
            var poolRef = poolToggle.getAttribute("data-pool-toggle");
            var open = poolToggle.getAttribute("aria-expanded") === "true";
            setPoolOpen(poolRef, !open);
            return;
        }
        var poolCount = event.target.closest("[data-pool-open-filter]");
        if (poolCount) {
            var countPool = poolCount.getAttribute("data-pool");
            var countFilter = poolCount.getAttribute("data-pool-open-filter") || "all";
            var countRegion = setPoolOpen(countPool, true);
            applyMachineFilter(countPool, countFilter);
            if (countRegion) countRegion.scrollIntoView({block: "nearest"});
            return;
        }
        var filter = event.target.closest("[data-machine-filter]");
        if (filter) {
            var pool = filter.getAttribute("data-pool");
            var category = filter.getAttribute("data-machine-filter");
            applyMachineFilter(pool, category);
            return;
        }
        var drawerTrigger = event.target.closest("[data-machine-drawer]");
        if (drawerTrigger) {
            openDrawer(drawerTrigger.getAttribute("data-machine-drawer"), drawerTrigger);
            return;
        }
        var memberTrigger = event.target.closest("[data-member-drawer]");
        if (memberTrigger) {
            openDrawer(memberTrigger.getAttribute("data-member-drawer"), memberTrigger);
            return;
        }
        if (event.target.closest("[data-horizon-drawer-close]") || event.target.closest("[data-horizon-drawer-backdrop]")) {
            closeDrawers(true);
            return;
        }
        var range = event.target.closest("[data-range]");
        if (range) {
            var selected = range.getAttribute("data-range");
            var trend = range.closest(".windows-agent-horizon-trend");
            trend.querySelectorAll("[data-range]").forEach(function (button) {
                var active = button === range;
                button.classList.toggle("active", active);
                button.setAttribute("aria-pressed", active ? "true" : "false");
            });
            trend.querySelectorAll("[data-range-panel]").forEach(function (panel) {
                panel.hidden = panel.getAttribute("data-range-panel") !== selected;
            });
        }
    });
    document.addEventListener("keydown", function (event) {
        if (event.key === "Escape") {
            closeDrawers(true);
        }
    });
}());
</script>';
