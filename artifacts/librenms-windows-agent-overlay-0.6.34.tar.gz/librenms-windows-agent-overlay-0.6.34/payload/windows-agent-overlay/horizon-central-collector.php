#!/usr/bin/env php
<?php

declare(strict_types=1);

use App\Models\Application;
use App\Models\ApplicationMetric;
use App\Models\Device;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Support\Facades\DB;
use LibreNMS\RRD\RrdDefinition;
use WindowsAgentOverlay\Horizon\HorizonFailure;
use WindowsAgentOverlay\Horizon\HorizonCollectionCoordinator;
use WindowsAgentOverlay\Horizon\HorizonCoordination;
use WindowsAgentOverlay\Horizon\PodCollector;
use WindowsAgentOverlay\Horizon\RedisHorizonCoordination;

require_once __DIR__ . '/../includes/windows-agent/horizon-projection.inc.php';
require_once __DIR__ . '/../includes/windows-agent/horizon-pool-reporter.inc.php';
require_once __DIR__ . '/horizon-central-lib.php';
require_once __DIR__ . '/horizon-central-coordination.php';

final class HorizonCentralRuntime
{
    private static bool $booted = false;

    /** @var list<string> */
    private const DATA_KEYS = \WindowsAgentOverlay\HorizonProjection::DATA_KEYS;

    /** @param array<string,mixed> $options */
    public static function run(
        array $options,
        ?HorizonCoordination $coordination = null,
        ?PodCollector $collector = null
    ): int
    {
        $root = rtrim((string) ($options['librenms-root'] ?? getenv('LIBRENMS_ROOT') ?: '/opt/librenms'), '/');
        $configPath = (string) ($options['config'] ?? $root . '/.horizon-pods.json');
        $stateDir = (string) ($options['state-dir'] ?? $root . '/storage/app/windows-agent-horizon');
        $siteFilter = strtolower((string) ($options['site'] ?? ''));
        $dryRun = isset($options['dry-run']);
        $force = isset($options['force']);
        $cooldownSeconds = max(30, min(300, (int) ($options['cooldown-seconds'] ?? 240)));

        if (! is_file($configPath)) {
            return 0; // Overlay may be installed everywhere; collection is opt-in per node.
        }
        $config = self::readJson($configPath);
        $pods = is_array($config['pods'] ?? null) ? $config['pods'] : [];
        if ($pods === []) {
            return 0;
        }
        $credential = self::credential($root);
        if (! $dryRun && ($credential['username'] === '' || $credential['password'] === '')) {
            self::log('configuration_error', 'credentials_missing');

            return 2;
        }

        if (! $dryRun) {
            self::bootLibreNms($root);
            $coordination ??= new RedisHorizonCoordination();
            $collector ??= new PodCollector();
        }
        if (! is_dir($stateDir) && ! mkdir($stateDir, 0700, true) && ! is_dir($stateDir)) {
            self::log('state_error', 'state_directory_unavailable');

            return 2;
        }
        $failed = 0;
        $matched = false;
        foreach ($pods as $pod) {
            if (! is_array($pod) || ! ($pod['enabled'] ?? true)) continue;
            $pod = \WindowsAgentOverlay\HorizonPoolReporter::withTemplate($pod, $config);
            $site = strtolower((string) ($pod['site'] ?? ''));
            if ($siteFilter !== '' && $site !== $siteFilter) continue;
            $matched = true;
            try {
                PodCollector::validateConfig($pod);
                if ($dryRun) {
                    self::log($site, 'configuration_valid');
                    continue;
                }
                self::registerPod($pod, $coordination);
                $coordinator = new HorizonCollectionCoordinator(
                    $coordination,
                    max(60, (int) ($pod['lock_seconds'] ?? 240)),
                    $cooldownSeconds,
                    30
                );
                $result = $coordinator->collect(
                    $site,
                    $force,
                    static function () use ($stateDir, $site, $pod, $credential, $collector): array {
                    $statePath = $stateDir . '/' . $site . '.json';
                    $previous = is_file($statePath) ? self::readJson($statePath) : [];
                    $snapshot = $collector->collect($pod, $credential, $previous);
                    $snapshot = self::withPoolReporters($pod, $snapshot);
                    // Servers dropped from the list stay queued here (never published)
                    // until one delivery tells them they no longer report.
                    $cleanup = self::reporterCleanup($previous, $pod);
                    $snapshot[self::REPORTER_CLEANUP_KEY] = $cleanup;
                    self::atomicJson($statePath, $snapshot, 0600);
                    $failed = self::publish($pod, $snapshot, $cleanup);
                    $pending = self::stillPending($cleanup, $failed);
                    if ($pending !== $cleanup) {
                        $snapshot[self::REPORTER_CLEANUP_KEY] = $pending;
                        self::atomicJson($statePath, $snapshot, 0600);
                    }
                    $meta = $snapshot['horizon_central_meta'];
                    self::log($site, ((int) ($meta['stale'] ?? 0) === 1 ? 'stale' : 'ok') . ' source=' . ($meta['source_endpoint'] ?? 'none'));

                    return ['fresh' => (int) ($meta['stale'] ?? 0) === 0];
                }
                );
                if (in_array($result, ['locked', 'cooldown'], true)) {
                    self::log($site, 'skipped_' . $result);
                }
            } catch (HorizonFailure $failure) {
                $failed++;
                self::log($site !== '' ? $site : 'configuration_error', $failure->reason);
            } catch (Throwable) {
                $failed++;
                self::log($site !== '' ? $site : 'runtime_error', 'internal_error');
            }
        }
        if ($siteFilter !== '' && ! $matched) {
            self::log($siteFilter, 'requested_site_not_configured');
        }

        return $failed === 0 ? 0 : 1;
    }

    public static function bootLibreNms(string $root): void
    {
        if (self::$booted) {
            return;
        }
        $autoload = $root . '/vendor/autoload.php';
        $bootstrap = $root . '/bootstrap/app.php';
        if (! is_file($autoload) || ! is_file($bootstrap)) {
            throw new HorizonFailure('librenms_bootstrap_missing');
        }
        require_once $autoload;
        if (! defined('LARAVEL_START')) define('LARAVEL_START', microtime(true));
        $app = require $bootstrap;
        $app->make(Kernel::class)->bootstrap();
        self::$booted = true;
    }

    /** @param array<string,mixed> $pod */
    public static function registerPod(array $pod, HorizonCoordination $coordination): void
    {
        $device = Device::findByHostname((string) ($pod['display_device'] ?? ''));
        if (! $device) {
            throw new HorizonFailure('display_device_not_found');
        }
        $app = Application::query()
            ->where('device_id', $device->device_id)
            ->where('app_type', 'windows-agent')
            ->where('app_instance', '')
            ->whereNull('deleted_at')
            ->first();
        if (! $app) {
            throw new HorizonFailure('windows_agent_application_not_found');
        }
        $coordination->register([
            'site' => strtolower((string) $pod['site']),
            'display_device' => strtolower((string) $pod['display_device']),
            'device_id' => (int) $device->device_id,
        ]);
    }

    /** @return array{username:string,password:string,domain:string} */
    private static function credential(string $root): array
    {
        $fileValues = self::readEnvFile($root . '/.env');
        $read = static function (string $key): string {
            $value = getenv($key);
            if ($value === false) $value = $_ENV[$key] ?? $_SERVER[$key] ?? '';

            return (string) $value;
        };

        return [
            'username' => $read('WINDOWS_AGENT_HORIZON_API_USERNAME') ?: ($fileValues['WINDOWS_AGENT_HORIZON_API_USERNAME'] ?? ''),
            'password' => $read('WINDOWS_AGENT_HORIZON_API_PASSWORD') ?: ($fileValues['WINDOWS_AGENT_HORIZON_API_PASSWORD'] ?? ''),
            'domain' => $read('WINDOWS_AGENT_HORIZON_API_DOMAIN') ?: ($fileValues['WINDOWS_AGENT_HORIZON_API_DOMAIN'] ?? ''),
        ];
    }

    /** @return array<string,string> */
    private static function readEnvFile(string $path): array
    {
        if (! is_file($path)) return [];
        $values = [];
        foreach (file($path, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
            if (! preg_match('/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/', $line, $match)) continue;
            $value = trim($match[2]);
            if (strlen($value) >= 2 && (($value[0] === '"' && substr($value, -1) === '"') || ($value[0] === "'" && substr($value, -1) === "'"))) {
                $value = stripcslashes(substr($value, 1, -1));
            }
            $values[$match[1]] = $value;
        }

        return $values;
    }

    /** @param array<string,mixed> $pod @param array<string,mixed> $snapshot */
    /**
     * Stamp the pod's ordered pool reporter list into the snapshot every member
     * receives, or remove it when the pod has none. Each member's own save then
     * decides from the live device table whether it is the active reporter.
     *
     * @param array<string,mixed> $pod
     * @param array<string,mixed> $snapshot
     * @return array<string,mixed>
     */
    public static function withPoolReporters(array $pod, array $snapshot): array
    {
        $meta = is_array($snapshot['horizon_central_meta'] ?? null) ? $snapshot['horizon_central_meta'] : [];
        $hosts = \WindowsAgentOverlay\HorizonPoolReporter::configured($pod);
        if ($hosts === []) unset($meta[\WindowsAgentOverlay\HorizonPoolReporter::META_KEY]);
        else $meta[\WindowsAgentOverlay\HorizonPoolReporter::META_KEY] = $hosts;
        $snapshot['horizon_central_meta'] = $meta;

        return $snapshot;
    }

    public const REPORTER_CLEANUP_KEY = 'pool_reporter_cleanup';

    /**
     * Servers that were reporters (or still awaiting cleanup) at the previous run
     * and are no longer listed: each must receive the new list once.
     *
     * @param array<string,mixed> $previous the previous run's saved state
     * @param array<string,mixed> $pod
     * @return list<string>
     */
    public static function reporterCleanup(array $previous, array $pod): array
    {
        $meta = is_array($previous['horizon_central_meta'] ?? null) ? $previous['horizon_central_meta'] : [];
        $queued = is_array($previous[self::REPORTER_CLEANUP_KEY] ?? null) ? $previous[self::REPORTER_CLEANUP_KEY] : [];
        $key = \WindowsAgentOverlay\HorizonPoolReporter::META_KEY;
        $candidates = array_merge(
            \WindowsAgentOverlay\HorizonPoolReporter::fromMeta($meta),
            \WindowsAgentOverlay\HorizonPoolReporter::fromMeta([$key => $queued])
        );
        $current = \WindowsAgentOverlay\HorizonPoolReporter::configured($pod);

        return array_values(array_unique(array_diff($candidates, $current)));
    }

    /**
     * @param list<string> $cleanup
     * @param list<string> $failed hosts whose publication threw
     * @return list<string> the cleanup hosts that still need a delivery
     */
    public static function stillPending(array $cleanup, array $failed): array
    {
        return array_values(array_intersect($cleanup, $failed));
    }

    /**
     * @param list<string> $formerReporters servers that must hear the new list
     * @return list<string> member hostnames whose publication failed
     */
    private static function publish(array $pod, array $snapshot, array $formerReporters = []): array
    {
        $primaryHost = strtolower(trim((string) ($pod['display_device'] ?? '')));
        $device = Device::findByHostname($primaryHost);
        if (! $device) throw new HorizonFailure('display_device_not_found');
        $app = self::windowsAgentApp((int) $device->device_id);
        if (! $app) throw new HorizonFailure('windows_agent_application_not_found');

        // The display device is the authoritative target and must succeed.
        self::publishToDevice($device, $app, $snapshot);

        // Fan the same pod-wide snapshot out to every other pod member that runs the
        // agent, so any member's page shows the identical pod view (status, pools,
        // gateways, conditions) and no operator has to know which node is reporting.
        // Members are best-effort: one that is not monitored, has no windows-agent
        // application, or races a delete is skipped without failing the collection.
        // The member's own poll preserves these central keys because the collector
        // stamps horizon_central_meta.source=central, which the parser keys on.
        // A host with no device or application has nothing to clean up; only a
        // publication that throws counts as failed.
        $failed = [];
        foreach (self::publishTargets($pod, $snapshot, $formerReporters) as $hostname) {
            if ($hostname === $primaryHost) continue;
            try {
                $memberDevice = Device::findByHostname($hostname);
                if (! $memberDevice) continue;
                $memberApp = self::windowsAgentApp((int) $memberDevice->device_id);
                if (! $memberApp) continue;
                self::publishToDevice($memberDevice, $memberApp, $snapshot);
            } catch (\Throwable $e) {
                $failed[] = $hostname;
                self::log((string) ($pod['site'] ?? 'pod'), 'member_publish_skipped:' . $hostname);
            }
        }

        return $failed;
    }

    private static function windowsAgentApp(int $deviceId): ?Application
    {
        return Application::query()
            ->where('device_id', $deviceId)
            ->where('app_type', 'windows-agent')
            ->where('app_instance', '')
            ->whereNull('deleted_at')
            ->first();
    }

    /**
     * Deduped lowercase hostnames that should receive the pod-wide snapshot: the
     * display device always, plus every reported pod member resolved to a hostname
     * (member name, suffixed with the pod dns_suffix when it is a short name). A pod
     * may opt out of member fan-out with publish_to_members=false. Listed pool
     * reporters, and those listed by the previous run, always receive it.
     *
     * @param array<string,mixed> $pod
     * @param array<string,mixed> $snapshot
     * @param list<string> $formerReporters
     * @return list<string>
     */
    public static function publishTargets(array $pod, array $snapshot, array $formerReporters = []): array
    {
        $suffix = (string) ($pod['dns_suffix'] ?? '');
        $targets = [];
        $add = static function (string $host) use (&$targets): void {
            $host = strtolower(trim($host));
            if ($host !== '' && ! in_array($host, $targets, true)) $targets[] = $host;
        };
        $add((string) ($pod['display_device'] ?? ''));
        if (($pod['publish_to_members'] ?? true)) {
            foreach ($snapshot['horizon_pod_members'] ?? [] as $member) {
                if (! is_array($member)) continue;
                $name = strtolower(trim((string) ($member['name'] ?? '')));
                if ($name === '') continue;
                $add(\WindowsAgentOverlay\HorizonPoolReporter::hostname($name, $suffix));
            }
        }
        // Every listed reporter must hold the current list to know whether it is
        // the active one, and a server dropped from the list must hear once more
        // that it no longer is, or it would keep its old pool metrics.
        $meta = is_array($snapshot['horizon_central_meta'] ?? null) ? $snapshot['horizon_central_meta'] : [];
        foreach (\WindowsAgentOverlay\HorizonPoolReporter::fromMeta($meta) as $host) $add($host);
        foreach ($formerReporters as $host) $add((string) $host);

        return $targets;
    }

    private static function publishToDevice(Device $device, Application $app, array $snapshot): void
    {
        DB::transaction(static function () use ($app, $snapshot): void {
            /** @var Application|null $locked */
            $locked = Application::query()->whereKey($app->app_id)->lockForUpdate()->first();
            if (! $locked) throw new HorizonFailure('windows_agent_application_not_found');
            $data = is_array($locked->data) ? $locked->data : [];
            foreach (self::DATA_KEYS as $key) {
                if (array_key_exists($key, $snapshot)) $data[$key] = $snapshot[$key];
            }
            $locked->data = $data;
            $locked->save();
            self::updateMetrics($locked->app_id, self::metrics($snapshot));
        });

        self::writeRrds(
            $device->toArray(),
            $app->app_id,
            self::metrics($snapshot),
            (int) ($snapshot['horizon_central_meta']['stale'] ?? 0) === 1
        );
    }

    /** @param array<string,mixed> $snapshot @return array<string,int|float> */
    public static function metrics(array $snapshot): array
    {
        return \WindowsAgentOverlay\HorizonProjection::metrics($snapshot);
    }

    /** @param array<string,int|float> $metrics */
    private static function updateMetrics(int $appId, array $metrics): void
    {
        foreach ($metrics as $name => $value) {
            $metric = ApplicationMetric::query()->where('app_id', $appId)->where('metric', $name)->first();
            if (! $metric) {
                $metric = new ApplicationMetric();
                $metric->app_id = $appId;
                $metric->metric = $name;
            } elseif ((float) $metric->value !== (float) $value) {
                $metric->value_prev = $metric->value;
            }
            $metric->value = $value;
            $metric->save();
        }
    }

    /** @param array<string,mixed> $device @param array<string,int|float> $m */
    private static function writeRrds(array $device, int $appId, array $m, bool $stale): void
    {
        $collectorFields = [
            'duration_ms' => $m['horizon_central_collection_duration_ms'],
            'endpoints' => $m['horizon_central_endpoints_attempted'],
            'requests' => $m['horizon_central_requests_total'],
            'pages' => $m['horizon_central_pages_total'],
            'complete' => $m['horizon_central_inventory_complete'],
        ];
        if ($stale) {
            foreach ($m as $name => $_value) {
                $m[$name] = 'U';
            }
        }
        $write = static function (string $name, RrdDefinition $definition, array $fields) use ($device, $appId): void {
            app('Datastore')->put($device, 'app', ['name' => $name, 'app_id' => $appId, 'rrd_name' => ['app', $name, $appId], 'rrd_def' => $definition], $fields);
        };
        $write('windows-agent-horizon-api', RrdDefinition::make()->addDataset('available', 'GAUGE', 0, 1)->addDataset('cs_total', 'GAUGE', 0)->addDataset('cs_unhealthy', 'GAUGE', 0)->addDataset('services_bad', 'GAUGE', 0)->addDataset('repl_bad', 'GAUGE', 0)->addDataset('cert_invalid', 'GAUGE', 0)->addDataset('sessions', 'GAUGE', 0)->addDataset('connected', 'GAUGE', 0)->addDataset('disconnected', 'GAUGE', 0)->addDataset('other', 'GAUGE', 0)->addDataset('truncated', 'GAUGE', 0, 1), [
            'available' => $m['horizon_api_available'], 'cs_total' => $m['horizon_api_connection_servers_total'], 'cs_unhealthy' => $m['horizon_api_connection_servers_unhealthy'], 'services_bad' => $m['horizon_api_services_unhealthy'], 'repl_bad' => $m['horizon_api_replications_unhealthy'], 'cert_invalid' => $m['horizon_api_certificates_invalid'], 'sessions' => $m['horizon_api_sessions_total'], 'connected' => $m['horizon_api_sessions_connected'], 'disconnected' => $m['horizon_api_sessions_disconnected'], 'other' => $m['horizon_api_sessions_other'], 'truncated' => $m['horizon_api_sessions_truncated'],
        ]);
        $write('windows-agent-horizon-platform', RrdDefinition::make()->addDataset('members', 'GAUGE', 0)->addDataset('members_bad', 'GAUGE', 0)->addDataset('repl_bad', 'GAUGE', 0)->addDataset('domain_bad', 'GAUGE', 0)->addDataset('gateways_bad', 'GAUGE', 0)->addDataset('pools', 'GAUGE', 0)->addDataset('pools_warn', 'GAUGE', 0)->addDataset('pools_crit', 'GAUGE', 0)->addDataset('incomplete', 'GAUGE', 0)->addDataset('spare_total', 'GAUGE', 0)->addDataset('spare_ready', 'GAUGE', 0)->addDataset('spare_unready', 'GAUGE', 0), [
            'members' => $m['horizon_pod_members_total'], 'members_bad' => $m['horizon_pod_members_unhealthy'], 'repl_bad' => $m['horizon_pod_replications_unhealthy'], 'domain_bad' => $m['horizon_directory_links_unhealthy'], 'gateways_bad' => $m['horizon_gateways_unhealthy'], 'pools' => $m['horizon_pools_total'], 'pools_warn' => $m['horizon_pools_warning'], 'pools_crit' => $m['horizon_pools_critical'], 'incomplete' => $m['horizon_pools_incomplete'], 'spare_total' => $m['horizon_spare_total'], 'spare_ready' => $m['horizon_spare_ready'], 'spare_unready' => $m['horizon_spare_unready'],
        ]);
        $write('windows-agent-horizon-collector', RrdDefinition::make()->addDataset('duration_ms', 'GAUGE', 0)->addDataset('endpoints', 'GAUGE', 0)->addDataset('requests', 'GAUGE', 0)->addDataset('pages', 'GAUGE', 0)->addDataset('complete', 'GAUGE', 0, 1), $collectorFields);
        $write('windows-agent-horizon-health', RrdDefinition::make()
            ->addDataset('platform', 'GAUGE', 0, 4)
            ->addDataset('dependency', 'GAUGE', 0, 4)
            ->addDataset('capacity', 'GAUGE', 0, 4)
            ->addDataset('collector', 'GAUGE', 0, 4)
            ->addDataset('overall', 'GAUGE', 0, 4)
            ->addDataset('vendor_warn', 'GAUGE', 0)
            ->addDataset('vendor_error', 'GAUGE', 0)
            ->addDataset('vendor_unknown', 'GAUGE', 0)
            ->addDataset('machine_gap', 'GAUGE', 0), [
                'platform' => $m['horizon_platform_health_state'],
                'dependency' => $m['horizon_dependency_health_state'],
                'capacity' => $m['horizon_capacity_health_state'],
                'collector' => $m['horizon_collector_health_state'],
                'overall' => $m['horizon_overall_health_state'],
                'vendor_warn' => $m['horizon_vendor_warnings_total'],
                'vendor_error' => $m['horizon_vendor_errors_total'],
                'vendor_unknown' => $m['horizon_vendor_unknown_total'],
                'machine_gap' => $m['horizon_vendor_problem_machine_mismatch'],
            ]);
    }

    /** @return array<string,mixed> */
    private static function readJson(string $path): array
    {
        try {
            $value = json_decode((string) file_get_contents($path), true, 128, JSON_THROW_ON_ERROR);
        } catch (Throwable) {
            throw new HorizonFailure('invalid_configuration_json');
        }
        if (! is_array($value)) throw new HorizonFailure('invalid_configuration_json');

        return $value;
    }

    /** @param array<string,mixed> $value */
    private static function atomicJson(string $path, array $value, int $mode): void
    {
        $tmp = $path . '.tmp.' . bin2hex(random_bytes(6));
        $json = json_encode($value, JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL;
        if (file_put_contents($tmp, $json, LOCK_EX) === false) throw new HorizonFailure('state_write_failed');
        chmod($tmp, $mode);
        if (! rename($tmp, $path)) {
            @unlink($tmp);
            throw new HorizonFailure('state_write_failed');
        }
    }

    private static function log(string $site, string $message): void
    {
        fwrite(STDOUT, gmdate('c') . ' horizon-central site=' . preg_replace('/[^a-z0-9_-]/i', '', $site) . ' state=' . preg_replace('/[^a-z0-9_.,:=\/-]/i', '', $message) . PHP_EOL);
    }
}

if (PHP_SAPI === 'cli' && realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === __FILE__) {
    $options = getopt('', ['librenms-root:', 'config:', 'state-dir:', 'site:', 'cooldown-seconds:', 'dry-run', 'fallback', 'force']);
    exit(HorizonCentralRuntime::run(is_array($options) ? $options : []));
}
