<?php

$data = is_array($app->data ?? null) ? $app->data : [];
$agent = $data['agent'] ?? [];
$windows_os = $data['windows_os'] ?? [];
$roles = $data['roles'] ?? [];
$ad_summary = $data['ad_summary'] ?? [];
$ad_replication = $data['ad_replication'] ?? [];
$ad_dfsr = $data['ad_dfsr'] ?? [];
$ad_fsmo = $data['ad_fsmo'] ?? [];
$ad_dc_health_summary = $data['ad_dc_health_summary'] ?? [];
$ad_dc_services = $data['ad_dc_services'] ?? [];
$ad_dc_dns = $data['ad_dc_dns'] ?? [];
$ad_dc_time = $data['ad_dc_time'] ?? [];
$ad_dc_shares = $data['ad_dc_shares'] ?? [];
$logged_on_users = $data['logged_on_users'] ?? [];
$pending_reboot = $data['pending_reboot'] ?? [];
$windows_update = $data['windows_update'] ?? [];
$watched_services = $data['watched_services'] ?? [];
$classified_service_groups = $data['classified_service_groups'] ?? [];
$service_group_summaries = $data['service_group_summaries'] ?? [];
$excluded_services = $data['excluded_services'] ?? [];
$event_logs = $data['event_logs'] ?? [];
$event_log_high_value_summary = $data['event_log_high_value_summary'] ?? [];
$event_log_high_value = $data['event_log_high_value'] ?? [];
$watched_processes = $data['watched_processes'] ?? [];
$watched_tcp_ports = $data['watched_tcp_ports'] ?? [];
$agent_performance = $data['agent_performance'] ?? [];
$collector_timings = $data['collector_timings'] ?? [];
$cpu_details = $data['cpu'] ?? [];
$memory = $data['memory'] ?? [];
$disks = $data['disks'] ?? [];
$vm_resource_summary = $data['vm_resource_summary'] ?? [];
$performance_summary = $data['performance_summary'] ?? [];
$performance_disks = $data['performance_disks'] ?? [];
$performance_network = $data['performance_network'] ?? [];
$performance_processes = $data['performance_processes'] ?? [];
$sql_server_summary = $data['sql_server_summary'] ?? [];
$sql_server_instances = $data['sql_server_instances'] ?? [];
$iis_summary = $data['iis_summary'] ?? [];
$iis_sites = $data['iis_sites'] ?? [];
$iis_app_pools = $data['iis_app_pools'] ?? [];
$iis_bindings = $data['iis_bindings'] ?? [];
$horizon_summary = $data['horizon_summary'] ?? [];
$horizon_services = $data['horizon_services'] ?? [];
$horizon_processes = $data['horizon_processes'] ?? [];
$horizon_ports = $data['horizon_ports'] ?? [];
$horizon_certificates = $data['horizon_certificates'] ?? [];
$tls_certificates_summary = $data['tls_certificates_summary'] ?? [];
$tls_certificates = $data['tls_certificates'] ?? [];
$backup_storage_summary = $data['backup_storage_summary'] ?? [];
$vss_writers = $data['vss_writers'] ?? [];
$backup_services = $data['backup_services'] ?? [];
$datto_backup_summary = $data['datto_backup_summary'] ?? [];
$datto_backup_services = $data['datto_backup_services'] ?? [];
$datto_backup_processes = $data['datto_backup_processes'] ?? [];
$datto_backup_evidence = $data['datto_backup_evidence'] ?? [];
$app_id = is_array($app) ? ($app['app_id'] ?? 0) : ($app->app_id ?? 0);

$esc = static fn ($value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$format_bytes = static function ($value): string {
    $bytes = (float) $value;
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $index = 0;
    while ($bytes >= 1024 && $index < count($units) - 1) {
        $bytes /= 1024;
        $index++;
    }

    return number_format($bytes, $index === 0 ? 0 : 2) . ' ' . $units[$index];
};

$sum_field = static function (array $rows, string $field): int {
    $total = 0;
    foreach ($rows as $row) {
        $total += (int) ($row[$field] ?? 0);
    }

    return $total;
};

$section_state = static function ($raw, int $issues = 0) use ($esc): array {
    $state = strtolower(trim((string) $raw));
    if ($state === '') {
        $state = $issues > 0 ? 'warning' : 'ok';
    }

    if ($issues > 0 && in_array($state, ['ok', 'running', 'stable', 'healthy'], true)) {
        $state = 'warning';
    }

    $labels = [
        'ok' => ['OK', 'success'],
        'running' => ['Running', 'success'],
        'stable' => ['Stable', 'success'],
        'healthy' => ['Healthy', 'success'],
        'warning' => ['Warning', 'warning'],
        'critical' => ['Critical', 'danger'],
        'error' => ['Error', 'danger'],
        'failed' => ['Failed', 'danger'],
        'not_detected' => ['Not detected', 'default'],
        'not_applicable' => ['Not applicable', 'default'],
        'disabled' => ['Disabled', 'default'],
        'unsupported' => ['Unsupported', 'default'],
        'unknown' => ['Unknown', 'default'],
        '1' => ['OK', 'success'],
        '0' => ['Issue', 'danger'],
    ];
    $label = $labels[$state] ?? [ucwords(str_replace('_', ' ', $state)), $issues > 0 ? 'warning' : 'default'];

    return [
        'key' => $state,
        'text' => $label[0],
        'class' => $label[1],
        'html' => '<span class="label label-' . $label[1] . '">' . $esc($label[0]) . '</span>',
    ];
};

$state_label = static function ($value, array $healthy = ['running', 'ok', '1', 'true']) use ($esc): string {
    $text = (string) $value;
    $class = in_array(strtolower($text), $healthy, true) ? 'label-success' : 'label-danger';

    return '<span class="label ' . $class . '">' . $esc($text === '' ? 'unknown' : $text) . '</span>';
};

$has_role_details = static function (array $summary, array $rows): bool {
    $state = strtolower((string) ($summary['state'] ?? ''));
    if (in_array($state, ['not_detected', 'disabled', 'unsupported', 'not_applicable'], true)) {
        return false;
    }

    return ! empty($rows);
};

$table = static function (array $headers, array $rows, callable $row_renderer) use ($esc): string {
    if (empty($rows)) {
        return '';
    }

    $html = '<div class="table-responsive"><table class="table table-condensed table-striped">';
    $html .= '<tr>';
    foreach ($headers as $header) {
        $html .= '<th>' . $esc($header) . '</th>';
    }
    $html .= '</tr>';
    foreach ($rows as $row) {
        $html .= '<tr>' . $row_renderer($row) . '</tr>';
    }
    $html .= '</table></div>';

    return $html;
};

$kv_table = static function (array $rows) use ($esc): string {
    $html = '<div class="table-responsive"><table class="table table-condensed table-striped">';
    foreach ($rows as $label => $value) {
        $html .= '<tr><th>' . $esc($label) . '</th><td>' . $value . '</td></tr>';
    }
    $html .= '</table></div>';

    return $html;
};

$render_graph_html = static function (string $key) use ($app_id): string {
    $graph_type = $key;
    $graph_array = [];
    $graph_array['height'] = '100';
    $graph_array['width'] = '215';
    $graph_array['to'] = \App\Facades\LibrenmsConfig::get('time.now');
    $graph_array['id'] = $app_id;
    $graph_array['type'] = 'application_' . $key;

    ob_start();
    include 'includes/html/print-graphrow.inc.php';
    return (string) ob_get_clean();
};

$state_has_issue = static function (array $state): bool {
    return in_array($state['class'] ?? '', ['warning', 'danger'], true);
};

$render_section_summary = static function (string $id, string $title, array $state, string $summary, string $details = '', ?string $graph_key = null) use ($esc, $render_graph_html): string {
    $arrow = '<span class="windows-agent-collapse-arrow windows-agent-collapse-arrow-down glyphicon glyphicon-chevron-down" aria-hidden="true"></span><span class="windows-agent-collapse-arrow windows-agent-collapse-arrow-up glyphicon glyphicon-chevron-up" aria-hidden="true"></span>';
    $html = '<div class="panel panel-default windows-agent-section" id="windows-agent-section-' . $esc($id) . '">';
    $html .= '<div class="panel-heading">';
    $html .= '<div class="row">';
    $html .= '<div class="col-md-3"><strong>' . $esc($title) . '</strong> ' . $state['html'] . '</div>';
    $html .= '<div class="col-md-6">' . $summary . '</div>';
    $html .= '<div class="col-md-3 text-right">';
    if ($details !== '') {
        $html .= '<a class="btn btn-xs btn-default collapsed windows-agent-collapse-toggle" data-toggle="collapse" href="#windows-agent-details-' . $esc($id) . '" aria-expanded="false">Details ' . $arrow . '</a> ';
    }
    if ($graph_key !== null) {
        $html .= '<a class="btn btn-xs btn-default collapsed windows-agent-collapse-toggle" data-toggle="collapse" href="#windows-agent-graphs-' . $esc($id) . '" aria-expanded="false">Graphs ' . $arrow . '</a>';
    }
    $html .= '</div></div></div>';
    if ($details !== '' || $graph_key !== null) {
        $html .= '<div class="panel-body">';
        if ($details !== '') {
            $html .= '<div id="windows-agent-details-' . $esc($id) . '" class="collapse windows-agent-details-collapse">' . $details . '</div>';
        }
        if ($graph_key !== null) {
            $html .= '<div id="windows-agent-graphs-' . $esc($id) . '" class="collapse windows-agent-graph-collapse">' . $render_graph_html($graph_key) . '</div>';
        }
        $html .= '</div>';
    }
    $html .= '</div>';

    return $html;
};

$render_tab = static function (string $id, bool $active, string $body) use ($esc): void {
    echo '<div role="tabpanel" class="tab-pane' . ($active ? ' active' : '') . '" id="' . $esc($id) . '">';
    echo $body;
    echo '</div>';
};

$metric = static function (string $label, $value) use ($esc): string {
    return '<span class="text-muted">' . $esc($label) . ':</span> <strong>' . $esc($value) . '</strong>';
};

$agent_issues = (int) ($agent_performance['collectors_failed'] ?? 0) + (int) ($agent_performance['collectors_timed_out'] ?? 0);
$vm_state = empty($vm_resource_summary) ? $section_state('unknown') : $section_state('ok');
$classified_services_stopped = $sum_field($service_group_summaries, 'not_running');
$watched_service_issues = 0;
foreach ($watched_services as $service) {
    if (($service['state'] ?? '') !== 'Running') {
        $watched_service_issues++;
    }
}
$event_issues = $sum_field($event_logs, 'critical_count') + $sum_field($event_logs, 'error_count');
$process_issues = 0;
foreach ($watched_processes as $process) {
    if ((int) ($process['matched_count'] ?? 0) === 0) {
        $process_issues++;
    }
}
$tcp_issues = 0;
foreach ($watched_tcp_ports as $tcp_port) {
    if ((int) ($tcp_port['listening'] ?? 0) === 0) {
        $tcp_issues++;
    }
}

$sections = [
    'agent' => [
        'title' => 'Agent',
        'state' => $section_state($agent_issues > 0 ? 'warning' : 'ok', $agent_issues),
        'summary' => $metric('Version', $agent['version'] ?? 'unknown') . ' ' . $metric('Host', $agent['host'] ?? 'unknown') . ' ' . $metric('Collector issues', $agent_issues),
    ],
    'vm' => [
        'title' => 'VM Resources',
        'state' => $vm_state,
        'summary' => $metric('CPU', ($vm_resource_summary['cpu_load_percent'] ?? '0') . '%') . ' ' . $metric('Memory', ($vm_resource_summary['memory_used_percent'] ?? '0') . '%') . ' ' . $metric('Max disk', ($vm_resource_summary['disk_used_percent_max'] ?? '0') . '%'),
    ],
    'performance' => [
        'title' => 'Performance',
        'state' => $section_state($performance_summary['state'] ?? 'not_detected', (int) ($performance_summary['pressure_issues'] ?? 0)),
        'summary' => $metric('Pressure issues', $performance_summary['pressure_issues'] ?? '0') . ' ' . $metric('CPU queue', $performance_summary['cpu_queue_length'] ?? '0') . ' ' . $metric('Committed', ($performance_summary['memory_committed_percent'] ?? '0') . '%'),
    ],
    'ad_dc' => [
        'title' => 'AD/DC',
        'state' => $section_state($ad_dc_health_summary['state'] ?? 'not_applicable', (int) ($ad_dc_health_summary['health_issues'] ?? 0)),
        'summary' => $metric('Issues', $ad_dc_health_summary['health_issues'] ?? '0') . ' ' . $metric('Core down', $ad_dc_health_summary['core_services_not_running'] ?? '0') . ' ' . $metric('Shares missing', $ad_dc_health_summary['shares_missing'] ?? '0'),
    ],
    'sql' => [
        'title' => 'SQL',
        'state' => $section_state($sql_server_summary['state'] ?? 'not_detected', (int) ($sql_server_summary['instances_not_running'] ?? 0)),
        'summary' => $metric('Instances', $sql_server_summary['instances_total'] ?? '0') . ' ' . $metric('Down', $sql_server_summary['instances_not_running'] ?? '0'),
    ],
    'iis' => [
        'title' => 'IIS',
        'state' => $section_state($iis_summary['state'] ?? 'not_detected', (int) ($iis_summary['sites_stopped'] ?? 0) + (int) ($iis_summary['app_pools_stopped'] ?? 0)),
        'summary' => $metric('Sites', $iis_summary['sites_total'] ?? '0') . ' ' . $metric('Pools', $iis_summary['app_pools_total'] ?? '0') . ' ' . $metric('Stopped', ((int) ($iis_summary['sites_stopped'] ?? 0) + (int) ($iis_summary['app_pools_stopped'] ?? 0))),
    ],
    'horizon' => [
        'title' => 'Horizon',
        'state' => $section_state($horizon_summary['state'] ?? 'not_detected', (int) ($horizon_summary['health_issues'] ?? 0)),
        'summary' => $metric('Detected', $horizon_summary['detected'] ?? '0') . ' ' . $metric('Services down', $horizon_summary['services_not_running'] ?? '0') . ' ' . $metric('Issues', $horizon_summary['health_issues'] ?? '0'),
    ],
    'tls' => [
        'title' => 'TLS',
        'state' => $section_state($tls_certificates_summary['state'] ?? 'not_detected', (int) ($tls_certificates_summary['unhealthy_count'] ?? 0)),
        'summary' => $metric('Certs', $tls_certificates_summary['certificate_count'] ?? '0') . ' ' . $metric('Expired', $tls_certificates_summary['expired_count'] ?? '0') . ' ' . $metric('Unhealthy', $tls_certificates_summary['unhealthy_count'] ?? '0'),
    ],
    'backup' => [
        'title' => 'Backup',
        'state' => $section_state($backup_storage_summary['state'] ?? 'not_detected', (int) ($backup_storage_summary['vss_writers_failed'] ?? 0) + (int) ($backup_storage_summary['backup_services_not_running'] ?? 0)),
        'summary' => $metric('VSS failed', $backup_storage_summary['vss_writers_failed'] ?? '0') . ' ' . $metric('Services down', $backup_storage_summary['backup_services_not_running'] ?? '0'),
    ],
    'datto' => [
        'title' => 'Datto',
        'state' => $section_state($datto_backup_summary['state'] ?? 'not_detected', (int) ($datto_backup_summary['health_issues'] ?? 0)),
        'summary' => $metric('Detected', $datto_backup_summary['detected'] ?? '0') . ' ' . $metric('Service running', $datto_backup_summary['service_running'] ?? '0') . ' ' . $metric('Issues', $datto_backup_summary['health_issues'] ?? '0'),
    ],
    'services' => [
        'title' => 'Services',
        'state' => $section_state($watched_service_issues > 0 ? 'warning' : 'ok', $watched_service_issues),
        'summary' => $metric('Watched down', $watched_service_issues) . ' ' . $metric('Classified stopped', $classified_services_stopped) . ' ' . $metric('Groups', count($classified_service_groups)),
    ],
    'events' => [
        'title' => 'Events',
        'state' => $section_state($event_issues > 0 ? 'warning' : 'ok', $event_issues),
        'summary' => $metric('Logs', count($event_logs)) . ' ' . $metric('Critical/errors', $event_issues) . ' ' . $metric('High-value groups', $event_log_high_value_summary['signatures_total'] ?? '0'),
    ],
    'processes' => [
        'title' => 'Processes',
        'state' => $section_state($process_issues > 0 ? 'warning' : 'ok', $process_issues),
        'summary' => $metric('Watched', count($watched_processes)) . ' ' . $metric('Missing', $process_issues),
    ],
    'tcp' => [
        'title' => 'TCP Ports',
        'state' => $section_state($tcp_issues > 0 ? 'warning' : 'ok', $tcp_issues),
        'summary' => $metric('Watched', count($watched_tcp_ports)) . ' ' . $metric('Not listening', $tcp_issues),
    ],
];

$overview = '<div class="panel panel-default"><div class="panel-heading"><h3 class="panel-title">Health Overview</h3></div><div class="panel-body">';
$overview .= '<div class="table-responsive"><table class="table table-condensed table-striped">';
$overview .= '<tr><th>Section</th><th>State</th><th>Summary</th></tr>';
foreach ($sections as $section) {
    $overview .= '<tr><td><strong>' . $esc($section['title']) . '</strong></td><td>' . $section['state']['html'] . '</td><td>' . $section['summary'] . '</td></tr>';
}
$overview .= '</table></div></div></div>';

$agent_details = $kv_table([
    'Agent version' => $esc($agent['version'] ?? 'unknown'),
    'Agent host' => $esc($agent['host'] ?? 'unknown'),
    'Last agent UTC' => $esc($data['last_agent_utc'] ?? ''),
    'Config path' => $esc($agent['config'] ?? ''),
    'Windows OS' => $esc($windows_os['caption'] ?? 'unknown'),
    'Version' => $esc($windows_os['version'] ?? ''),
    'Build' => $esc($windows_os['build'] ?? ''),
    'Architecture' => $esc($windows_os['architecture'] ?? ''),
]);

$collector_details = $table(['Collector', 'State', 'Duration', 'Sections', 'Lines'], $collector_timings, static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['collector'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown', ['ok']) . '</td><td>' . $esc($row['duration_ms'] ?? '0') . ' ms</td><td>' . $esc($row['section_count'] ?? '0') . '</td><td>' . $esc($row['line_count'] ?? '0') . '</td>';
});

$agent_perf_details = $kv_table([
    'Collection duration' => $esc($agent_performance['collect_duration_ms'] ?? '0') . ' ms',
    'Collectors run' => $esc($agent_performance['collectors_run'] ?? '0'),
    'Failed / timed out' => $esc($agent_performance['collectors_failed'] ?? '0') . ' / ' . $esc($agent_performance['collectors_timed_out'] ?? '0'),
    'Payload size' => $esc($format_bytes($agent_performance['payload_bytes'] ?? 0)),
    'Process working set' => $esc($format_bytes($agent_performance['process_working_set_bytes'] ?? 0)),
    'Process private bytes' => $esc($format_bytes($agent_performance['process_private_bytes'] ?? 0)),
]) . $collector_details;

$vm_details = $kv_table([
    'CPU load' => $esc($vm_resource_summary['cpu_load_percent'] ?? '0') . '%',
    'Memory used' => $esc($vm_resource_summary['memory_used_percent'] ?? '0') . '%',
    'Physical memory used/free' => $esc($format_bytes($memory['used_bytes'] ?? 0)) . ' / ' . $esc($format_bytes($memory['physical_free_bytes'] ?? 0)),
    'Max disk used' => $esc($vm_resource_summary['disk_used_percent_max'] ?? '0') . '%',
    'Minimum disk free' => $esc($format_bytes($vm_resource_summary['disk_free_bytes_min'] ?? 0)),
]);
$vm_details .= $table(['CPU', 'Cores', 'Logical', 'Load', 'Max clock'], $cpu_details, static function ($row) use ($esc): string {
    return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['cores'] ?? '') . '</td><td>' . $esc($row['logical_processors'] ?? '') . '</td><td>' . $esc($row['load_percent'] ?? '0') . '%</td><td>' . $esc($row['max_clock_mhz'] ?? '') . ' MHz</td>';
});
$vm_details .= $table(['Disk', 'Volume', 'Filesystem', 'Used', 'Free', 'Used %', 'Free %'], $disks, static function ($row) use ($esc, $format_bytes): string {
    return '<td>' . $esc($row['device'] ?? '') . '</td><td>' . $esc($row['volume'] ?? '') . '</td><td>' . $esc($row['filesystem'] ?? '') . '</td><td>' . $esc($format_bytes($row['used_bytes'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['free_bytes'] ?? 0)) . '</td><td>' . $esc($row['used_percent'] ?? '0') . '%</td><td>' . $esc($row['free_percent'] ?? '0') . '%</td>';
});

$perf_details = $kv_table([
    'Pressure issues' => $esc($performance_summary['pressure_issues'] ?? '0'),
    'CPU queue / pressure' => $esc($performance_summary['cpu_queue_length'] ?? '0') . ' / ' . $esc($performance_summary['cpu_pressure'] ?? '0'),
    'Memory available / committed' => $esc($performance_summary['memory_available_mb'] ?? '0') . ' MB / ' . $esc($performance_summary['memory_committed_percent'] ?? '0') . '%',
    'Paging' => $esc($performance_summary['pages_per_sec'] ?? '0') . ' pages/sec / pressure=' . $esc($performance_summary['paging_pressure'] ?? '0'),
    'Disk read/write max' => $esc($performance_summary['disk_read_ms_max'] ?? '0') . ' / ' . $esc($performance_summary['disk_write_ms_max'] ?? '0') . ' ms',
    'Network throughput / errors' => $esc($format_bytes($performance_summary['network_bytes_per_sec_total'] ?? 0)) . '/s / ' . $esc($performance_summary['network_errors_total'] ?? '0'),
]);
if ($has_role_details($performance_summary, $performance_disks)) {
    $perf_details .= $table(['Disk', 'Read ms', 'Write ms', 'Queue', 'Bytes/sec'], $performance_disks, static function ($row) use ($esc, $format_bytes): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['avg_read_ms'] ?? '0') . '</td><td>' . $esc($row['avg_write_ms'] ?? '0') . '</td><td>' . $esc($row['current_queue_length'] ?? '0') . '</td><td>' . $esc($format_bytes($row['disk_bytes_per_sec'] ?? 0)) . '/s</td>';
    });
}
if ($has_role_details($performance_summary, $performance_network)) {
    $perf_details .= $table(['Interface', 'Bytes/sec', 'Packets/sec', 'Errors/sec', 'Discards/sec'], $performance_network, static function ($row) use ($esc, $format_bytes): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($format_bytes($row['bytes_per_sec'] ?? 0)) . '/s</td><td>' . $esc($row['packets_per_sec'] ?? '0') . '</td><td>' . $esc($row['errors_per_sec'] ?? '0') . '</td><td>' . $esc($row['discards_per_sec'] ?? '0') . '</td>';
    });
}
if ($has_role_details($performance_summary, $performance_processes)) {
    $perf_details .= $table(['Process', 'PID', 'Rank', 'CPU %', 'Working set', 'Private bytes', 'Handles', 'Threads'], $performance_processes, static function ($row) use ($esc, $format_bytes): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['pid'] ?? '') . '</td><td>' . $esc($row['rank_source'] ?? '') . '</td><td>' . $esc($row['cpu_percent'] ?? '0') . '</td><td>' . $esc($format_bytes($row['working_set_bytes'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['private_bytes'] ?? 0)) . '</td><td>' . $esc($row['handle_count'] ?? '0') . '</td><td>' . $esc($row['thread_count'] ?? '0') . '</td>';
    });
}

$sql_details = $has_role_details($sql_server_summary, $sql_server_instances) ? $table(['Instance', 'Service', 'State', 'Start mode', 'Agent', 'Browser', 'Ports'], $sql_server_instances, static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['instance'] ?? '') . '</td><td>' . $esc($row['service'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['agent_state'] ?? '') . '</td><td>' . $esc($row['browser_state'] ?? '') . '</td><td>' . $esc($row['listener_ports'] ?? '') . '</td>';
}) : '';

$iis_details = '';
if ($has_role_details($iis_summary, $iis_sites)) {
    $iis_details .= $table(['Site', 'ID', 'State', 'Bindings', 'Path'], $iis_sites, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['id'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['bindings_count'] ?? '') . '</td><td>' . $esc($row['physical_path'] ?? '') . '</td>';
    });
}
if ($has_role_details($iis_summary, $iis_app_pools)) {
    $iis_details .= $table(['App pool', 'State', 'Runtime', 'Pipeline', 'Identity'], $iis_app_pools, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown', ['started', 'running']) . '</td><td>' . $esc($row['runtime_version'] ?? '') . '</td><td>' . $esc($row['pipeline_mode'] ?? '') . '</td><td>' . $esc($row['identity_type'] ?? '') . '</td>';
    });
}
if ($has_role_details($iis_summary, $iis_bindings)) {
    $iis_details .= $table(['Site', 'Protocol', 'Binding', 'Host', 'Port', 'Certificate'], $iis_bindings, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['site'] ?? '') . '</td><td>' . $esc($row['protocol'] ?? '') . '</td><td>' . $esc($row['binding_information'] ?? '') . '</td><td>' . $esc($row['hostname'] ?? '') . '</td><td>' . $esc($row['port'] ?? '') . '</td><td>' . $esc($row['certificate_thumbprint'] ?? '') . '</td>';
    });
}

$horizon_details = '';
if ($has_role_details($horizon_summary, $horizon_services)) {
    $horizon_details .= $table(['Service', 'Display', 'Role', 'State', 'Start mode', 'Path'], $horizon_services, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td>';
    });
}
if ($has_role_details($horizon_summary, $horizon_processes)) {
    $horizon_details .= $table(['Process', 'PID', 'Path'], $horizon_processes, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['pid'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td>';
    });
}
if ($has_role_details($horizon_summary, $horizon_ports)) {
    $horizon_details .= $table(['Port', 'Listening', 'Addresses'], $horizon_ports, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['port'] ?? '') . '</td><td>' . $state_label($row['listening'] ?? '0') . '</td><td>' . $esc($row['addresses'] ?? '') . '</td>';
    });
}
if ($has_role_details($horizon_summary, $horizon_certificates)) {
    $horizon_details .= $table(['Store', 'Subject', 'Issuer', 'Expires UTC', 'Days', 'Expired', 'Private key', 'Thumbprint'], $horizon_certificates, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['store'] ?? '') . '</td><td>' . $esc($row['subject'] ?? '') . '</td><td>' . $esc($row['issuer'] ?? '') . '</td><td>' . $esc($row['not_after_utc'] ?? '') . '</td><td>' . $esc($row['days_remaining'] ?? '') . '</td><td>' . $state_label($row['expired'] ?? '0', ['0']) . '</td><td>' . $esc($row['has_private_key'] ?? '0') . '</td><td>' . $esc($row['thumbprint'] ?? '') . '</td>';
    });
}

$tls_details = $has_role_details($tls_certificates_summary, $tls_certificates) ? $table(['Store', 'Subject', 'Health', 'DNS names', 'Expires UTC', 'Days', 'Chain', 'Key', 'Bound'], $tls_certificates, static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['store'] ?? '') . '</td><td>' . $esc($row['subject'] ?? '') . '</td><td>' . $state_label($row['health'] ?? 'unknown', ['ok']) . '</td><td>' . $esc($row['dns_names'] ?? '') . '</td><td>' . $esc($row['not_after_utc'] ?? '') . '</td><td>' . $esc($row['days_remaining'] ?? '') . '</td><td>' . $esc($row['chain_status'] ?? '') . '</td><td>' . $esc($row['key_bits'] ?? '') . ' bits / private=' . $esc($row['has_private_key'] ?? '0') . '</td><td>' . $esc($row['bound'] ?? '0') . ' ' . $esc($row['binding_sources'] ?? '') . '</td>';
}) : '';

$backup_details = '';
if ($has_role_details($backup_storage_summary, $vss_writers)) {
    $backup_details .= $table(['Writer', 'State', 'Last error'], $vss_writers, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown', ['stable']) . '</td><td>' . $esc($row['last_error'] ?? '') . '</td>';
    });
}
if ($has_role_details($backup_storage_summary, $backup_services)) {
    $backup_details .= $table(['Service', 'Display', 'State', 'Start mode', 'Source'], $backup_services, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
    });
}

$datto_details = '';
if ($has_role_details($datto_backup_summary, $datto_backup_services)) {
    $datto_details .= $table(['Service', 'Role', 'State', 'Start mode', 'Path exists', 'Version'], $datto_backup_services, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['path_exists'] ?? '0') . '</td><td>' . $esc($row['version'] ?? '') . '</td>';
    });
}
if ($has_role_details($datto_backup_summary, $datto_backup_processes)) {
    $datto_details .= $table(['Process', 'Matched count'], $datto_backup_processes, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['matched_count'] ?? '0') . '</td>';
    });
}
if ($has_role_details($datto_backup_summary, $datto_backup_evidence)) {
    $datto_details .= $table(['Type', 'State', 'Source', 'Timestamp UTC', 'Age', 'Recent errors', 'Critical failures'], $datto_backup_evidence, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['type'] ?? '') . '</td><td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td><td>' . $esc($row['timestamp_utc'] ?? '') . '</td><td>' . $esc($row['age_hours'] ?? '') . '</td><td>' . $esc($row['recent_errors'] ?? '') . '</td><td>' . $esc($row['recent_critical_failures'] ?? '') . '</td>';
    });
}

$role_details = $table(['Role', 'Detected', 'Confidence', 'Source'], $roles, static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['role'] ?? '') . '</td><td>' . $state_label($row['detected'] ?? '0') . '</td><td>' . $esc($row['confidence'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
});
$ad_details = $kv_table([
    'Domain' => $esc($ad_summary['domain'] ?? ''),
    'Domain role' => $esc($ad_summary['domain_role_name'] ?? '') . ' (' . $esc($ad_summary['domain_role'] ?? '') . ')',
    'Replication state' => $esc($ad_summary['replication_state'] ?? ''),
    'Replication failures' => $esc($ad_summary['replication_failures'] ?? '0'),
    'DFSR state' => $esc($ad_summary['dfsr_state'] ?? ''),
    'DFSR unhealthy' => $esc($ad_summary['dfsr_unhealthy'] ?? '0'),
    'FSMO state' => $esc($ad_summary['fsmo_state'] ?? ''),
]);
$ad_dc_details = $kv_table([
    'Core services down' => $esc($ad_dc_health_summary['core_services_not_running'] ?? '0'),
    'DNS service running' => $esc($ad_dc_health_summary['dns_service_running'] ?? '0'),
    'SYSVOL / NETLOGON published' => $esc($ad_dc_health_summary['sysvol_share_present'] ?? '0') . ' / ' . $esc($ad_dc_health_summary['netlogon_share_present'] ?? '0'),
    'Time state' => $esc($ad_dc_health_summary['time_state'] ?? ''),
    'Health issues' => $esc($ad_dc_health_summary['health_issues'] ?? '0'),
]);
if ($has_role_details($ad_dc_health_summary, $ad_dc_dns)) {
    $ad_dc_details .= $table(['DNS state', 'Present', 'Running', 'Reason'], $ad_dc_dns, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['service_present'] ?? '0') . '</td><td>' . $esc($row['service_running'] ?? '0') . '</td><td>' . $esc($row['reason'] ?? '') . '</td>';
    });
}
if ($has_role_details($ad_dc_health_summary, $ad_dc_services)) {
    $ad_dc_details .= $table(['Name', 'Role', 'Core', 'Present', 'State', 'Start mode', 'Display'], $ad_dc_services, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($row['core'] ?? '0') . '</td><td>' . $esc($row['present'] ?? '0') . '</td><td>' . $state_label($row['state'] ?? 'unknown', ['running']) . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td>';
    });
}
if ($has_role_details($ad_dc_health_summary, $ad_dc_shares)) {
    $ad_dc_details .= $table(['Share', 'Present', 'Path'], $ad_dc_shares, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['present'] ?? '0') . '</td><td>' . $esc($row['path'] ?? '') . '</td>';
    });
}
if ($has_role_details($ad_dc_health_summary, $ad_dc_time)) {
    $ad_dc_details .= $table(['State', 'Source', 'Stratum', 'Leap', 'Last sync', 'Reason'], $ad_dc_time, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td><td>' . $esc($row['stratum'] ?? '') . '</td><td>' . $esc($row['leap_indicator'] ?? '') . '</td><td>' . $esc($row['last_successful_sync_time'] ?? '') . '</td><td>' . $esc($row['reason'] ?? '') . '</td>';
    });
}
$ad_replication_details = $table(['State', 'Source', 'Target', 'Naming context', 'Failures', 'Last success', 'Last failure', 'Status'], $ad_replication, static function ($row) use ($esc): string {
    return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td><td>' . $esc($row['target'] ?? '') . '</td><td>' . $esc($row['naming_context'] ?? '') . '</td><td>' . $esc($row['failure_count'] ?? '0') . '</td><td>' . $esc($row['last_success'] ?? '') . '</td><td>' . $esc($row['last_failure'] ?? '') . '</td><td>' . $esc($row['last_failure_status'] ?? ($row['reason'] ?? '')) . '</td>';
});
$dfsr_details = $table(['State', 'Replication group', 'Folder', 'Member', 'Source', 'Reason'], $ad_dfsr, static function ($row) use ($esc): string {
    return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['replication_group'] ?? '') . '</td><td>' . $esc($row['replicated_folder'] ?? '') . '</td><td>' . $esc($row['member'] ?? '') . '</td><td>' . $esc($row['source'] ?? ($row['tool'] ?? '')) . '</td><td>' . $esc($row['reason'] ?? '') . '</td>';
});
$fsmo_details = $table(['State', 'Role', 'Owner', 'Reason'], $ad_fsmo, static function ($row) use ($esc): string {
    return '<td>' . $esc($row['state'] ?? '') . '</td><td>' . $esc($row['role'] ?? '') . '</td><td>' . $esc($row['owner'] ?? '') . '</td><td>' . $esc($row['reason'] ?? '') . '</td>';
});
$users_details = $table(['User', 'Domain', 'Session', 'ID', 'State', 'Idle time', 'Logon time', 'Current', 'Source'], array_filter($logged_on_users, static fn ($row): bool => ! empty($row['user'])), static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['user'] ?? '') . '</td><td>' . $esc($row['domain'] ?? '') . '</td><td>' . $esc($row['session_name'] ?? '') . '</td><td>' . $esc($row['session_id'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown', ['active']) . '</td><td>' . $esc($row['idle_time'] ?? '') . '</td><td>' . $esc($row['logon_time'] ?? '') . '</td><td>' . $esc($row['current'] ?? '0') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
});

$reboot_details = $kv_table([
    'Pending reboot' => $state_label($pending_reboot['pending'] ?? '0', ['0']) . ' ' . $esc($pending_reboot['sources'] ?? ''),
    'Windows Update reboot required' => $state_label($windows_update['reboot_required'] ?? '0', ['0']),
    'Windows Update service' => $esc($windows_update['service_state'] ?? 'unknown') . ' / ' . $esc($windows_update['start_mode'] ?? 'unknown'),
]);
$service_details = '';
if (empty($classified_service_groups)) {
    $service_details .= $table(['Name', 'Display name', 'State'], $watched_services, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td>';
    });
} else {
    foreach ($classified_service_groups as $group_key => $services_in_group) {
        if (empty($services_in_group)) {
            continue;
        }

        $summary = $service_group_summaries[$group_key] ?? [];
        $service_details .= '<h4>' . $esc($group_key) . ' <small>Total ' . $esc($summary['total'] ?? count($services_in_group)) . ', not running ' . $esc($summary['not_running'] ?? '0') . '</small></h4>';
        $service_details .= $table(['Name', 'Display name', 'State', 'Start mode', 'Account', 'Path', 'Source'], $services_in_group, static function ($row) use ($esc, $state_label): string {
            return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['account'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
        });
    }
}
if (! empty($excluded_services)) {
    $service_details .= '<h4>Excluded / Low Value Services</h4>';
    $service_details .= $table(['Name', 'Display name', 'State', 'Start mode', 'Account', 'Path', 'Source'], $excluded_services, static function ($row) use ($esc, $state_label): string {
        return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['display'] ?? '') . '</td><td>' . $state_label($row['state'] ?? 'unknown') . '</td><td>' . $esc($row['start_mode'] ?? '') . '</td><td>' . $esc($row['account'] ?? '') . '</td><td>' . $esc($row['path'] ?? '') . '</td><td>' . $esc($row['source'] ?? '') . '</td>';
    });
}
$event_details = $table(['Log', 'Scanned', 'Critical', 'Error', 'Warning', 'Latest critical/error UTC'], $event_logs, static function ($row) use ($esc): string {
    return '<td>' . $esc($row['log'] ?? '') . '</td><td>' . $esc($row['scanned_events'] ?? '0') . '</td><td>' . $esc($row['critical_count'] ?? '0') . '</td><td>' . $esc($row['error_count'] ?? '0') . '</td><td>' . $esc($row['warning_count'] ?? '0') . '</td><td>' . $esc($row['latest_critical_or_error_utc'] ?? '') . '</td>';
});
if (! empty($event_log_high_value)) {
    $event_details .= '<h4>High-value Event Samples <small>groups ' . $esc($event_log_high_value_summary['signatures_total'] ?? count($event_log_high_value)) . ', events ' . $esc($event_log_high_value_summary['events_total'] ?? '0') . ', samples ' . $esc($event_log_high_value_summary['samples_total'] ?? count($event_log_high_value)) . ', truncated ' . $esc($event_log_high_value_summary['truncated'] ?? '0') . '</small></h4>';
    $event_details .= $table(['Log', 'Provider', 'Event ID', 'Level', 'Count', 'Last seen UTC', 'Sample UTC', 'Message excerpt'], $event_log_high_value, static function ($row) use ($esc): string {
        return '<td>' . $esc($row['log'] ?? '') . '</td><td>' . $esc($row['provider'] ?? '') . '</td><td>' . $esc($row['event_id'] ?? '') . '</td><td>' . $esc($row['level'] ?? '') . '</td><td>' . $esc($row['count'] ?? '0') . '</td><td>' . $esc($row['last_seen_utc'] ?? '') . '</td><td>' . $esc($row['sample_time_utc'] ?? '') . '</td><td>' . $esc($row['message_excerpt'] ?? '') . '</td>';
    });
}
$process_details = $table(['Name', 'Matched', 'Working set', 'Private bytes', 'CPU seconds'], $watched_processes, static function ($row) use ($esc, $format_bytes): string {
    return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['matched_count'] ?? '0') . '</td><td>' . $esc($format_bytes($row['working_set_bytes'] ?? 0)) . '</td><td>' . $esc($format_bytes($row['private_bytes'] ?? 0)) . '</td><td>' . $esc($row['processor_seconds'] ?? '0') . '</td>';
});
$tcp_details = $table(['Name', 'Address', 'Port', 'Listening'], $watched_tcp_ports, static function ($row) use ($esc, $state_label): string {
    return '<td>' . $esc($row['name'] ?? '') . '</td><td>' . $esc($row['address'] ?? '*') . '</td><td>' . $esc($row['port'] ?? '') . '</td><td>' . $state_label($row['listening'] ?? '0') . '</td>';
});

$performance_tab = '';
$performance_tab .= $render_section_summary('agent-performance', 'Agent Performance', $sections['agent']['state'], $sections['agent']['summary'], $agent_perf_details, 'windows-agent_performance');
$performance_tab .= $render_section_summary('vm-resources', 'VM Resources', $sections['vm']['state'], $sections['vm']['summary'], $vm_details, 'windows-agent_vm_resources');
$performance_tab .= $render_section_summary('performance-depth', 'Windows Performance Depth', $sections['performance']['state'], $sections['performance']['summary'], $perf_details, 'windows-agent_performance_depth');

$roles_tab = '';
$roles_tab .= $render_section_summary('sql', 'SQL Server', $sections['sql']['state'], $sections['sql']['summary'], $sql_details, null);
$roles_tab .= $render_section_summary('iis', 'IIS', $sections['iis']['state'], $sections['iis']['summary'], $iis_details, null);
$roles_tab .= $render_section_summary('horizon', 'VMware Horizon', $sections['horizon']['state'], $sections['horizon']['summary'], $horizon_details, 'windows-agent_horizon');
$roles_tab .= $render_section_summary('roles', 'Detected Roles', $section_state(empty($roles) ? 'not_detected' : 'ok'), $metric('Rows', count($roles)), $role_details, null);
$roles_tab .= $render_section_summary('ad', 'Active Directory Summary', $section_state($ad_summary['state'] ?? 'not_applicable'), $metric('Domain', $ad_summary['domain'] ?? '') . ' ' . $metric('Failures', $ad_summary['replication_failures'] ?? '0'), $ad_details, null);
$roles_tab .= $render_section_summary('ad-dc', 'AD/DC Local Health', $sections['ad_dc']['state'], $sections['ad_dc']['summary'], $ad_dc_details, 'windows-agent_ad_dc_health');
$roles_tab .= $render_section_summary('ad-replication', 'AD Replication Targets', $section_state(empty($ad_replication) ? 'not_applicable' : 'ok'), $metric('Targets', count($ad_replication)), $ad_replication_details, null);
$roles_tab .= $render_section_summary('dfsr', 'DFSR Replication Health', $section_state(empty($ad_dfsr) ? 'not_applicable' : 'ok'), $metric('Rows', count($ad_dfsr)), $dfsr_details, null);
$roles_tab .= $render_section_summary('fsmo', 'FSMO Roles', $section_state(empty($ad_fsmo) ? 'not_applicable' : 'ok'), $metric('Roles', count($ad_fsmo)), $fsmo_details, null);
$roles_tab .= $render_section_summary('users', 'Logged-On Users', $section_state(empty($logged_on_users) ? 'not_detected' : 'ok'), $metric('Sessions', count($logged_on_users)), $users_details, null);

$security_tab = '';
$security_tab .= $render_section_summary('tls', 'TLS Certificate Visibility', $sections['tls']['state'], $sections['tls']['summary'], $tls_details, 'windows-agent_tls_health');

$backup_tab = '';
$backup_tab .= $render_section_summary('backup-storage', 'Backup / Storage Visibility', $sections['backup']['state'], $sections['backup']['summary'], $backup_details, 'windows-agent_backup_storage');
$backup_tab .= $render_section_summary('datto', 'Datto Backup Health', $sections['datto']['state'], $sections['datto']['summary'], $datto_details, 'windows-agent_datto_backup');

$services_tab = '';
$services_tab .= $render_section_summary('reboot', 'Reboot and Windows Update', $section_state(((int) ($pending_reboot['pending'] ?? 0) || (int) ($windows_update['reboot_required'] ?? 0)) ? 'warning' : 'ok'), $metric('Pending reboot', $pending_reboot['pending'] ?? '0') . ' ' . $metric('Update reboot', $windows_update['reboot_required'] ?? '0'), $reboot_details, 'windows-agent_reboot_state');
$services_tab .= $render_section_summary('services', 'Services', $sections['services']['state'], $sections['services']['summary'], $service_details, null);
$services_tab .= $render_section_summary('events', 'Event Logs', $sections['events']['state'], $sections['events']['summary'], $event_details, 'windows-agent_event_logs');
$services_tab .= $render_section_summary('processes', 'Watched Processes', $sections['processes']['state'], $sections['processes']['summary'], $process_details, null);
$services_tab .= $render_section_summary('tcp', 'Watched TCP Ports', $sections['tcp']['state'], $sections['tcp']['summary'], $tcp_details, null);

$diagnostics_tab = '';
$diagnostics_tab .= $render_section_summary('agent-os', 'Agent and OS', $sections['agent']['state'], $sections['agent']['summary'], $agent_details, null);
$diagnostics_tab .= $render_section_summary('collector-timings', 'Collector Timings', $sections['agent']['state'], $metric('Collectors run', $agent_performance['collectors_run'] ?? '0') . ' ' . $metric('Failed/timed out', $agent_issues), $collector_details, null);

echo '<style>
.windows-agent-collapse-toggle .windows-agent-collapse-arrow { margin-left: 4px; }
.windows-agent-collapse-toggle .windows-agent-collapse-arrow-down { display: none; }
.windows-agent-collapse-toggle .windows-agent-collapse-arrow-up { display: inline-block; }
.windows-agent-collapse-toggle.collapsed .windows-agent-collapse-arrow-down { display: inline-block; }
.windows-agent-collapse-toggle.collapsed .windows-agent-collapse-arrow-up { display: none; }
.windows-agent-tab-alert { margin-left: 5px; }
</style>';
echo '<ul class="nav nav-tabs" role="tablist">';
$tabs = [
    'windows-agent-overview' => 'Overview',
    'windows-agent-performance' => 'Performance',
    'windows-agent-roles' => 'Roles & Workloads',
    'windows-agent-security' => 'Security & Certificates',
    'windows-agent-backup' => 'Backup',
    'windows-agent-services' => 'Services & Events',
    'windows-agent-diagnostics' => 'Agent Diagnostics',
];
$tab_has_issue = [
    'windows-agent-overview' => false,
    'windows-agent-performance' => $state_has_issue($sections['agent']['state']) || $state_has_issue($sections['vm']['state']) || $state_has_issue($sections['performance']['state']),
    'windows-agent-roles' => $state_has_issue($sections['sql']['state']) || $state_has_issue($sections['iis']['state']) || $state_has_issue($sections['horizon']['state']) || $state_has_issue($sections['ad_dc']['state']),
    'windows-agent-security' => $state_has_issue($sections['tls']['state']),
    'windows-agent-backup' => $state_has_issue($sections['backup']['state']) || $state_has_issue($sections['datto']['state']),
    'windows-agent-services' => $state_has_issue($sections['services']['state']) || $state_has_issue($sections['events']['state']) || $state_has_issue($sections['processes']['state']) || $state_has_issue($sections['tcp']['state']) || ((int) ($pending_reboot['pending'] ?? 0) || (int) ($windows_update['reboot_required'] ?? 0)),
    'windows-agent-diagnostics' => $state_has_issue($sections['agent']['state']),
];
$issue_icon = '<span class="windows-agent-tab-alert glyphicon glyphicon-exclamation-sign text-danger" title="This tab has one or more issues" aria-label="issues present"></span>';
$first = true;
foreach ($tabs as $id => $title) {
    echo '<li role="presentation" class="' . ($first ? 'active' : '') . '"><a href="#' . $esc($id) . '" aria-controls="' . $esc($id) . '" role="tab" data-toggle="tab">' . $esc($title) . (($tab_has_issue[$id] ?? false) ? ' ' . $issue_icon : '') . '</a></li>';
    $first = false;
}
echo '</ul>';
echo '<div class="tab-content" style="padding-top: 15px;">';
$render_tab('windows-agent-overview', true, $overview);
$render_tab('windows-agent-performance', false, $performance_tab);
$render_tab('windows-agent-roles', false, $roles_tab);
$render_tab('windows-agent-security', false, $security_tab);
$render_tab('windows-agent-backup', false, $backup_tab);
$render_tab('windows-agent-services', false, $services_tab);
$render_tab('windows-agent-diagnostics', false, $diagnostics_tab);
echo '</div>';
